package com.manage.project.module.vending.service;

import com.manage.project.module.vending.domain.Vending;
import java.util.List;

/**
 * 售货机的基本，主柜 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IVendingService 
{
	/**
     * 查询售货机的基本，主柜信息
     * 
     * @param logid 售货机的基本，主柜ID
     * @return 售货机的基本，主柜信息
     */
	public Vending selectVendingById(String logid);
	
	/**
     * 查询售货机的基本，主柜列表
     * 
     * @param vending 售货机的基本，主柜信息
     * @return 售货机的基本，主柜集合
     */
	public List<Vending> selectVendingList(Vending vending);
	
	/**
     * 新增售货机的基本，主柜
     * 
     * @param vending 售货机的基本，主柜信息
     * @return 结果
     */
	public int insertVending(Vending vending);
	
	/**
     * 修改售货机的基本，主柜
     * 
     * @param vending 售货机的基本，主柜信息
     * @return 结果
     */
	public int updateVending(Vending vending);
		
	/**
     * 删除售货机的基本，主柜信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteVendingByIds(String ids);
	
}
