package com.manage.project.module.vendingPconfig.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 售货机配货模板表 as_vending_pconfig
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class VendingPconfig extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 模板编号 */
	private String mConfigId;
	/** 模板名称 */
	private String name;
	/** 货柜排列(从左到右) */
	private Integer seqId;
	/** 厂家编号 */
	private String factoryId;
	/** 货柜类型 01:商店机 02:弹簧机 03:格子机 */
	private String cabinetType;
	/** 机型编码 */
	private String deviceId;
	/** 创建时间 */
	private String createTime;
	/** 托管公司编号 */
	private String corpId;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setMConfigId(String mConfigId) 
	{
		this.mConfigId = mConfigId;
	}

	public String getMConfigId() 
	{
		return mConfigId;
	}
	public void setName(String name) 
	{
		this.name = name;
	}

	public String getName() 
	{
		return name;
	}
	public void setSeqId(Integer seqId) 
	{
		this.seqId = seqId;
	}

	public Integer getSeqId() 
	{
		return seqId;
	}
	public void setFactoryId(String factoryId) 
	{
		this.factoryId = factoryId;
	}

	public String getFactoryId() 
	{
		return factoryId;
	}
	public void setCabinetType(String cabinetType) 
	{
		this.cabinetType = cabinetType;
	}

	public String getCabinetType() 
	{
		return cabinetType;
	}
	public void setDeviceId(String deviceId) 
	{
		this.deviceId = deviceId;
	}

	public String getDeviceId() 
	{
		return deviceId;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("mConfigId", getMConfigId())
            .append("name", getName())
            .append("seqId", getSeqId())
            .append("factoryId", getFactoryId())
            .append("cabinetType", getCabinetType())
            .append("deviceId", getDeviceId())
            .append("createTime", getCreateTime())
            .append("corpId", getCorpId())
            .toString();
    }
}
