package com.manage.project.module.orderProduct.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.orderProduct.mapper.OrderProductMapper;
import com.manage.project.module.orderProduct.domain.OrderProduct;
import com.manage.project.module.orderProduct.service.IOrderProductService;
import com.manage.common.support.Convert;

/**
 * 记录客户购买的商品 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class OrderProductServiceImpl implements IOrderProductService 
{
	@Autowired
	private OrderProductMapper orderProductMapper;

	/**
     * 查询记录客户购买的商品信息
     * 
     * @param logid 记录客户购买的商品ID
     * @return 记录客户购买的商品信息
     */
    @Override
	public OrderProduct selectOrderProductById(String logid)
	{
	    return orderProductMapper.selectOrderProductById(logid);
	}
	
	/**
     * 查询记录客户购买的商品列表
     * 
     * @param orderProduct 记录客户购买的商品信息
     * @return 记录客户购买的商品集合
     */
	@Override
	public List<OrderProduct> selectOrderProductList(OrderProduct orderProduct)
	{
	    return orderProductMapper.selectOrderProductList(orderProduct);
	}
	
    /**
     * 新增记录客户购买的商品
     * 
     * @param orderProduct 记录客户购买的商品信息
     * @return 结果
     */
	@Override
	public int insertOrderProduct(OrderProduct orderProduct)
	{
	    return orderProductMapper.insertOrderProduct(orderProduct);
	}
	
	/**
     * 修改记录客户购买的商品
     * 
     * @param orderProduct 记录客户购买的商品信息
     * @return 结果
     */
	@Override
	public int updateOrderProduct(OrderProduct orderProduct)
	{
	    return orderProductMapper.updateOrderProduct(orderProduct);
	}

	/**
     * 删除记录客户购买的商品对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteOrderProductByIds(String ids)
	{
		return orderProductMapper.deleteOrderProductByIds(Convert.toStrArray(ids));
	}
	
}
