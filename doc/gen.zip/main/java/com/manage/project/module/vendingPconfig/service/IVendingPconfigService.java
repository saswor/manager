package com.manage.project.module.vendingPconfig.service;

import com.manage.project.module.vendingPconfig.domain.VendingPconfig;
import java.util.List;

/**
 * 售货机配货模板 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IVendingPconfigService 
{
	/**
     * 查询售货机配货模板信息
     * 
     * @param logid 售货机配货模板ID
     * @return 售货机配货模板信息
     */
	public VendingPconfig selectVendingPconfigById(String logid);
	
	/**
     * 查询售货机配货模板列表
     * 
     * @param vendingPconfig 售货机配货模板信息
     * @return 售货机配货模板集合
     */
	public List<VendingPconfig> selectVendingPconfigList(VendingPconfig vendingPconfig);
	
	/**
     * 新增售货机配货模板
     * 
     * @param vendingPconfig 售货机配货模板信息
     * @return 结果
     */
	public int insertVendingPconfig(VendingPconfig vendingPconfig);
	
	/**
     * 修改售货机配货模板
     * 
     * @param vendingPconfig 售货机配货模板信息
     * @return 结果
     */
	public int updateVendingPconfig(VendingPconfig vendingPconfig);
		
	/**
     * 删除售货机配货模板信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteVendingPconfigByIds(String ids);
	
}
