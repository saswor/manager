package com.manage.project.module.supplyConfig.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.supplyConfig.mapper.SupplyConfigMapper;
import com.manage.project.module.supplyConfig.domain.SupplyConfig;
import com.manage.project.module.supplyConfig.service.ISupplyConfigService;
import com.manage.common.support.Convert;

/**
 * 商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class SupplyConfigServiceImpl implements ISupplyConfigService 
{
	@Autowired
	private SupplyConfigMapper supplyConfigMapper;

	/**
     * 查询商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。信息
     * 
     * @param logid 商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。ID
     * @return 商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。信息
     */
    @Override
	public SupplyConfig selectSupplyConfigById(String logid)
	{
	    return supplyConfigMapper.selectSupplyConfigById(logid);
	}
	
	/**
     * 查询商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。列表
     * 
     * @param supplyConfig 商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。信息
     * @return 商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。集合
     */
	@Override
	public List<SupplyConfig> selectSupplyConfigList(SupplyConfig supplyConfig)
	{
	    return supplyConfigMapper.selectSupplyConfigList(supplyConfig);
	}
	
    /**
     * 新增商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。
     * 
     * @param supplyConfig 商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。信息
     * @return 结果
     */
	@Override
	public int insertSupplyConfig(SupplyConfig supplyConfig)
	{
	    return supplyConfigMapper.insertSupplyConfig(supplyConfig);
	}
	
	/**
     * 修改商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。
     * 
     * @param supplyConfig 商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。信息
     * @return 结果
     */
	@Override
	public int updateSupplyConfig(SupplyConfig supplyConfig)
	{
	    return supplyConfigMapper.updateSupplyConfig(supplyConfig);
	}

	/**
     * 删除商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteSupplyConfigByIds(String ids)
	{
		return supplyConfigMapper.deleteSupplyConfigByIds(Convert.toStrArray(ids));
	}
	
}
