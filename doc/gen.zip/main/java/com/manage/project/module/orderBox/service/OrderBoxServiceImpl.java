package com.manage.project.module.orderBox.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.orderBox.mapper.OrderBoxMapper;
import com.manage.project.module.orderBox.domain.OrderBox;
import com.manage.project.module.orderBox.service.IOrderBoxService;
import com.manage.common.support.Convert;

/**
 * 记录每个商品的货道出库情况 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class OrderBoxServiceImpl implements IOrderBoxService 
{
	@Autowired
	private OrderBoxMapper orderBoxMapper;

	/**
     * 查询记录每个商品的货道出库情况信息
     * 
     * @param logid 记录每个商品的货道出库情况ID
     * @return 记录每个商品的货道出库情况信息
     */
    @Override
	public OrderBox selectOrderBoxById(String logid)
	{
	    return orderBoxMapper.selectOrderBoxById(logid);
	}
	
	/**
     * 查询记录每个商品的货道出库情况列表
     * 
     * @param orderBox 记录每个商品的货道出库情况信息
     * @return 记录每个商品的货道出库情况集合
     */
	@Override
	public List<OrderBox> selectOrderBoxList(OrderBox orderBox)
	{
	    return orderBoxMapper.selectOrderBoxList(orderBox);
	}
	
    /**
     * 新增记录每个商品的货道出库情况
     * 
     * @param orderBox 记录每个商品的货道出库情况信息
     * @return 结果
     */
	@Override
	public int insertOrderBox(OrderBox orderBox)
	{
	    return orderBoxMapper.insertOrderBox(orderBox);
	}
	
	/**
     * 修改记录每个商品的货道出库情况
     * 
     * @param orderBox 记录每个商品的货道出库情况信息
     * @return 结果
     */
	@Override
	public int updateOrderBox(OrderBox orderBox)
	{
	    return orderBoxMapper.updateOrderBox(orderBox);
	}

	/**
     * 删除记录每个商品的货道出库情况对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteOrderBoxByIds(String ids)
	{
		return orderBoxMapper.deleteOrderBoxByIds(Convert.toStrArray(ids));
	}
	
}
