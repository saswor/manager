package com.manage.project.module.productInfo.service;

import com.manage.project.module.productInfo.domain.ProductInfo;
import java.util.List;

/**
 * 记录商品 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IProductInfoService 
{
	/**
     * 查询记录商品信息
     * 
     * @param logid 记录商品ID
     * @return 记录商品信息
     */
	public ProductInfo selectProductInfoById(String logid);
	
	/**
     * 查询记录商品列表
     * 
     * @param productInfo 记录商品信息
     * @return 记录商品集合
     */
	public List<ProductInfo> selectProductInfoList(ProductInfo productInfo);
	
	/**
     * 新增记录商品
     * 
     * @param productInfo 记录商品信息
     * @return 结果
     */
	public int insertProductInfo(ProductInfo productInfo);
	
	/**
     * 修改记录商品
     * 
     * @param productInfo 记录商品信息
     * @return 结果
     */
	public int updateProductInfo(ProductInfo productInfo);
		
	/**
     * 删除记录商品信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteProductInfoByIds(String ids);
	
}
