package com.manage.project.module.orderApply.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.orderApply.mapper.OrderApplyMapper;
import com.manage.project.module.orderApply.domain.OrderApply;
import com.manage.project.module.orderApply.service.IOrderApplyService;
import com.manage.common.support.Convert;

/**
 * 记录客户购买的商品 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class OrderApplyServiceImpl implements IOrderApplyService 
{
	@Autowired
	private OrderApplyMapper orderApplyMapper;

	/**
     * 查询记录客户购买的商品信息
     * 
     * @param logid 记录客户购买的商品ID
     * @return 记录客户购买的商品信息
     */
    @Override
	public OrderApply selectOrderApplyById(String logid)
	{
	    return orderApplyMapper.selectOrderApplyById(logid);
	}
	
	/**
     * 查询记录客户购买的商品列表
     * 
     * @param orderApply 记录客户购买的商品信息
     * @return 记录客户购买的商品集合
     */
	@Override
	public List<OrderApply> selectOrderApplyList(OrderApply orderApply)
	{
	    return orderApplyMapper.selectOrderApplyList(orderApply);
	}
	
    /**
     * 新增记录客户购买的商品
     * 
     * @param orderApply 记录客户购买的商品信息
     * @return 结果
     */
	@Override
	public int insertOrderApply(OrderApply orderApply)
	{
	    return orderApplyMapper.insertOrderApply(orderApply);
	}
	
	/**
     * 修改记录客户购买的商品
     * 
     * @param orderApply 记录客户购买的商品信息
     * @return 结果
     */
	@Override
	public int updateOrderApply(OrderApply orderApply)
	{
	    return orderApplyMapper.updateOrderApply(orderApply);
	}

	/**
     * 删除记录客户购买的商品对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteOrderApplyByIds(String ids)
	{
		return orderApplyMapper.deleteOrderApplyByIds(Convert.toStrArray(ids));
	}
	
}
