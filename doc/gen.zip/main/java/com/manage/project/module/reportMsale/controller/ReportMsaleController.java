package com.manage.project.module.reportMsale.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.reportMsale.domain.ReportMsale;
import com.manage.project.module.reportMsale.service.IReportMsaleService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 仪盘概要统计报 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/reportMsale")
public class ReportMsaleController extends BaseController
{
    private String prefix = "module/reportMsale";
	
	@Autowired
	private IReportMsaleService reportMsaleService;
	
	@RequiresPermissions("module:reportMsale:view")
	@GetMapping()
	public String reportMsale()
	{
	    return prefix + "/reportMsale";
	}
	
	/**
	 * 查询仪盘概要统计报列表
	 */
	@RequiresPermissions("module:reportMsale:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(ReportMsale reportMsale)
	{
		startPage();
        List<ReportMsale> list = reportMsaleService.selectReportMsaleList(reportMsale);
		return getDataTable(list);
	}
	
	/**
	 * 新增仪盘概要统计报
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存仪盘概要统计报
	 */
	@RequiresPermissions("module:reportMsale:add")
	@Log(title = "仪盘概要统计报", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(ReportMsale reportMsale)
	{		
		return toAjax(reportMsaleService.insertReportMsale(reportMsale));
	}

	/**
	 * 修改仪盘概要统计报
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		ReportMsale reportMsale = reportMsaleService.selectReportMsaleById(logid);
		mmap.put("reportMsale", reportMsale);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存仪盘概要统计报
	 */
	@RequiresPermissions("module:reportMsale:edit")
	@Log(title = "仪盘概要统计报", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(ReportMsale reportMsale)
	{		
		return toAjax(reportMsaleService.updateReportMsale(reportMsale));
	}
	
	/**
	 * 删除仪盘概要统计报
	 */
	@RequiresPermissions("module:reportMsale:remove")
	@Log(title = "仪盘概要统计报", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(reportMsaleService.deleteReportMsaleByIds(ids));
	}
	
}
