package com.manage.project.module.reportDsale.service;

import com.manage.project.module.reportDsale.domain.ReportDsale;
import java.util.List;

/**
 * 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IReportDsaleService 
{
	/**
     * 查询每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新信息
     * 
     * @param logid 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新ID
     * @return 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新信息
     */
	public ReportDsale selectReportDsaleById(String logid);
	
	/**
     * 查询每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新列表
     * 
     * @param reportDsale 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新信息
     * @return 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新集合
     */
	public List<ReportDsale> selectReportDsaleList(ReportDsale reportDsale);
	
	/**
     * 新增每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新
     * 
     * @param reportDsale 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新信息
     * @return 结果
     */
	public int insertReportDsale(ReportDsale reportDsale);
	
	/**
     * 修改每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新
     * 
     * @param reportDsale 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新信息
     * @return 结果
     */
	public int updateReportDsale(ReportDsale reportDsale);
		
	/**
     * 删除每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteReportDsaleByIds(String ids);
	
}
