package com.manage.project.module.vendingModel.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.vendingModel.domain.VendingModel;
import com.manage.project.module.vendingModel.service.IVendingModelService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 售货机机型管理，包括主柜和副柜机型 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/vendingModel")
public class VendingModelController extends BaseController
{
    private String prefix = "module/vendingModel";
	
	@Autowired
	private IVendingModelService vendingModelService;
	
	@RequiresPermissions("module:vendingModel:view")
	@GetMapping()
	public String vendingModel()
	{
	    return prefix + "/vendingModel";
	}
	
	/**
	 * 查询售货机机型管理，包括主柜和副柜机型列表
	 */
	@RequiresPermissions("module:vendingModel:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(VendingModel vendingModel)
	{
		startPage();
        List<VendingModel> list = vendingModelService.selectVendingModelList(vendingModel);
		return getDataTable(list);
	}
	
	/**
	 * 新增售货机机型管理，包括主柜和副柜机型
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存售货机机型管理，包括主柜和副柜机型
	 */
	@RequiresPermissions("module:vendingModel:add")
	@Log(title = "售货机机型管理，包括主柜和副柜机型", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(VendingModel vendingModel)
	{		
		return toAjax(vendingModelService.insertVendingModel(vendingModel));
	}

	/**
	 * 修改售货机机型管理，包括主柜和副柜机型
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		VendingModel vendingModel = vendingModelService.selectVendingModelById(logid);
		mmap.put("vendingModel", vendingModel);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存售货机机型管理，包括主柜和副柜机型
	 */
	@RequiresPermissions("module:vendingModel:edit")
	@Log(title = "售货机机型管理，包括主柜和副柜机型", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(VendingModel vendingModel)
	{		
		return toAjax(vendingModelService.updateVendingModel(vendingModel));
	}
	
	/**
	 * 删除售货机机型管理，包括主柜和副柜机型
	 */
	@RequiresPermissions("module:vendingModel:remove")
	@Log(title = "售货机机型管理，包括主柜和副柜机型", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(vendingModelService.deleteVendingModelByIds(ids));
	}
	
}
