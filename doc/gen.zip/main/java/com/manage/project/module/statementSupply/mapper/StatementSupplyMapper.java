package com.manage.project.module.statementSupply.mapper;

import com.manage.project.module.statementSupply.domain.StatementSupply;
import java.util.List;	

/**
 * 对账补货 数据层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface StatementSupplyMapper 
{
	/**
     * 查询对账补货信息
     * 
     * @param logid 对账补货ID
     * @return 对账补货信息
     */
	public StatementSupply selectStatementSupplyById(String logid);
	
	/**
     * 查询对账补货列表
     * 
     * @param statementSupply 对账补货信息
     * @return 对账补货集合
     */
	public List<StatementSupply> selectStatementSupplyList(StatementSupply statementSupply);
	
	/**
     * 新增对账补货
     * 
     * @param statementSupply 对账补货信息
     * @return 结果
     */
	public int insertStatementSupply(StatementSupply statementSupply);
	
	/**
     * 修改对账补货
     * 
     * @param statementSupply 对账补货信息
     * @return 结果
     */
	public int updateStatementSupply(StatementSupply statementSupply);
	
	/**
     * 删除对账补货
     * 
     * @param logid 对账补货ID
     * @return 结果
     */
	public int deleteStatementSupplyById(String logid);
	
	/**
     * 批量删除对账补货
     * 
     * @param logids 需要删除的数据ID
     * @return 结果
     */
	public int deleteStatementSupplyByIds(String[] logids);
	
}