package com.manage.project.module.advertMaterial.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.advertMaterial.mapper.AdvertMaterialMapper;
import com.manage.project.module.advertMaterial.domain.AdvertMaterial;
import com.manage.project.module.advertMaterial.service.IAdvertMaterialService;
import com.manage.common.support.Convert;

/**
 * 广告素材媒体 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class AdvertMaterialServiceImpl implements IAdvertMaterialService 
{
	@Autowired
	private AdvertMaterialMapper advertMaterialMapper;

	/**
     * 查询广告素材媒体信息
     * 
     * @param logid 广告素材媒体ID
     * @return 广告素材媒体信息
     */
    @Override
	public AdvertMaterial selectAdvertMaterialById(String logid)
	{
	    return advertMaterialMapper.selectAdvertMaterialById(logid);
	}
	
	/**
     * 查询广告素材媒体列表
     * 
     * @param advertMaterial 广告素材媒体信息
     * @return 广告素材媒体集合
     */
	@Override
	public List<AdvertMaterial> selectAdvertMaterialList(AdvertMaterial advertMaterial)
	{
	    return advertMaterialMapper.selectAdvertMaterialList(advertMaterial);
	}
	
    /**
     * 新增广告素材媒体
     * 
     * @param advertMaterial 广告素材媒体信息
     * @return 结果
     */
	@Override
	public int insertAdvertMaterial(AdvertMaterial advertMaterial)
	{
	    return advertMaterialMapper.insertAdvertMaterial(advertMaterial);
	}
	
	/**
     * 修改广告素材媒体
     * 
     * @param advertMaterial 广告素材媒体信息
     * @return 结果
     */
	@Override
	public int updateAdvertMaterial(AdvertMaterial advertMaterial)
	{
	    return advertMaterialMapper.updateAdvertMaterial(advertMaterial);
	}

	/**
     * 删除广告素材媒体对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteAdvertMaterialByIds(String ids)
	{
		return advertMaterialMapper.deleteAdvertMaterialByIds(Convert.toStrArray(ids));
	}
	
}
