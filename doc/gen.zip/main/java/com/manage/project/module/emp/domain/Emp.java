package com.manage.project.module.emp.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 系统人员管理表 as_emp
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class Emp extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/**  */
	private String logid;
	/**  */
	private String corpId;
	/**  */
	private String corpName;
	/**  */
	private String loginId;
	/**  */
	private String loginName;
	/**  */
	private String idCard;
	/**  */
	private String empType;
	/**  */
	private String gender;
	/**  */
	private String mobile;
	/**  */
	private String email;
	/**  */
	private String passWord;
	/**  */
	private String encodeType;
	/**  */
	private String salt;
	/**  */
	private String createTime;
	/**  */
	private String descrption;
	/**  */
	private String accessCode;
	/**  */
	private String curState;
	/**  */
	private String unableTime;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setCorpName(String corpName) 
	{
		this.corpName = corpName;
	}

	public String getCorpName() 
	{
		return corpName;
	}
	public void setLoginId(String loginId) 
	{
		this.loginId = loginId;
	}

	public String getLoginId() 
	{
		return loginId;
	}
	public void setLoginName(String loginName) 
	{
		this.loginName = loginName;
	}

	public String getLoginName() 
	{
		return loginName;
	}
	public void setIdCard(String idCard) 
	{
		this.idCard = idCard;
	}

	public String getIdCard() 
	{
		return idCard;
	}
	public void setEmpType(String empType) 
	{
		this.empType = empType;
	}

	public String getEmpType() 
	{
		return empType;
	}
	public void setGender(String gender) 
	{
		this.gender = gender;
	}

	public String getGender() 
	{
		return gender;
	}
	public void setMobile(String mobile) 
	{
		this.mobile = mobile;
	}

	public String getMobile() 
	{
		return mobile;
	}
	public void setEmail(String email) 
	{
		this.email = email;
	}

	public String getEmail() 
	{
		return email;
	}
	public void setPassWord(String passWord) 
	{
		this.passWord = passWord;
	}

	public String getPassWord() 
	{
		return passWord;
	}
	public void setEncodeType(String encodeType) 
	{
		this.encodeType = encodeType;
	}

	public String getEncodeType() 
	{
		return encodeType;
	}
	public void setSalt(String salt) 
	{
		this.salt = salt;
	}

	public String getSalt() 
	{
		return salt;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}
	public void setDescrption(String descrption) 
	{
		this.descrption = descrption;
	}

	public String getDescrption() 
	{
		return descrption;
	}
	public void setAccessCode(String accessCode) 
	{
		this.accessCode = accessCode;
	}

	public String getAccessCode() 
	{
		return accessCode;
	}
	public void setCurState(String curState) 
	{
		this.curState = curState;
	}

	public String getCurState() 
	{
		return curState;
	}
	public void setUnableTime(String unableTime) 
	{
		this.unableTime = unableTime;
	}

	public String getUnableTime() 
	{
		return unableTime;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("corpId", getCorpId())
            .append("corpName", getCorpName())
            .append("loginId", getLoginId())
            .append("loginName", getLoginName())
            .append("idCard", getIdCard())
            .append("empType", getEmpType())
            .append("gender", getGender())
            .append("mobile", getMobile())
            .append("email", getEmail())
            .append("passWord", getPassWord())
            .append("encodeType", getEncodeType())
            .append("salt", getSalt())
            .append("createTime", getCreateTime())
            .append("descrption", getDescrption())
            .append("accessCode", getAccessCode())
            .append("curState", getCurState())
            .append("unableTime", getUnableTime())
            .toString();
    }
}
