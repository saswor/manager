package com.manage.project.module.statementSupply.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.statementSupply.domain.StatementSupply;
import com.manage.project.module.statementSupply.service.IStatementSupplyService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 对账补货 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/statementSupply")
public class StatementSupplyController extends BaseController
{
    private String prefix = "module/statementSupply";
	
	@Autowired
	private IStatementSupplyService statementSupplyService;
	
	@RequiresPermissions("module:statementSupply:view")
	@GetMapping()
	public String statementSupply()
	{
	    return prefix + "/statementSupply";
	}
	
	/**
	 * 查询对账补货列表
	 */
	@RequiresPermissions("module:statementSupply:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(StatementSupply statementSupply)
	{
		startPage();
        List<StatementSupply> list = statementSupplyService.selectStatementSupplyList(statementSupply);
		return getDataTable(list);
	}
	
	/**
	 * 新增对账补货
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存对账补货
	 */
	@RequiresPermissions("module:statementSupply:add")
	@Log(title = "对账补货", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(StatementSupply statementSupply)
	{		
		return toAjax(statementSupplyService.insertStatementSupply(statementSupply));
	}

	/**
	 * 修改对账补货
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		StatementSupply statementSupply = statementSupplyService.selectStatementSupplyById(logid);
		mmap.put("statementSupply", statementSupply);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存对账补货
	 */
	@RequiresPermissions("module:statementSupply:edit")
	@Log(title = "对账补货", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(StatementSupply statementSupply)
	{		
		return toAjax(statementSupplyService.updateStatementSupply(statementSupply));
	}
	
	/**
	 * 删除对账补货
	 */
	@RequiresPermissions("module:statementSupply:remove")
	@Log(title = "对账补货", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(statementSupplyService.deleteStatementSupplyByIds(ids));
	}
	
}
