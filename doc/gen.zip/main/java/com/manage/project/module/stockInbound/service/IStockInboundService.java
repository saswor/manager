package com.manage.project.module.stockInbound.service;

import com.manage.project.module.stockInbound.domain.StockInbound;
import java.util.List;

/**
 * 仓库入库记录 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IStockInboundService 
{
	/**
     * 查询仓库入库记录信息
     * 
     * @param logid 仓库入库记录ID
     * @return 仓库入库记录信息
     */
	public StockInbound selectStockInboundById(String logid);
	
	/**
     * 查询仓库入库记录列表
     * 
     * @param stockInbound 仓库入库记录信息
     * @return 仓库入库记录集合
     */
	public List<StockInbound> selectStockInboundList(StockInbound stockInbound);
	
	/**
     * 新增仓库入库记录
     * 
     * @param stockInbound 仓库入库记录信息
     * @return 结果
     */
	public int insertStockInbound(StockInbound stockInbound);
	
	/**
     * 修改仓库入库记录
     * 
     * @param stockInbound 仓库入库记录信息
     * @return 结果
     */
	public int updateStockInbound(StockInbound stockInbound);
		
	/**
     * 删除仓库入库记录信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteStockInboundByIds(String ids);
	
}
