package com.manage.project.module.reportOsale.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.reportOsale.domain.ReportOsale;
import com.manage.project.module.reportOsale.service.IReportOsaleService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 每天销量排行统计 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/reportOsale")
public class ReportOsaleController extends BaseController
{
    private String prefix = "module/reportOsale";
	
	@Autowired
	private IReportOsaleService reportOsaleService;
	
	@RequiresPermissions("module:reportOsale:view")
	@GetMapping()
	public String reportOsale()
	{
	    return prefix + "/reportOsale";
	}
	
	/**
	 * 查询每天销量排行统计列表
	 */
	@RequiresPermissions("module:reportOsale:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(ReportOsale reportOsale)
	{
		startPage();
        List<ReportOsale> list = reportOsaleService.selectReportOsaleList(reportOsale);
		return getDataTable(list);
	}
	
	/**
	 * 新增每天销量排行统计
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存每天销量排行统计
	 */
	@RequiresPermissions("module:reportOsale:add")
	@Log(title = "每天销量排行统计", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(ReportOsale reportOsale)
	{		
		return toAjax(reportOsaleService.insertReportOsale(reportOsale));
	}

	/**
	 * 修改每天销量排行统计
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		ReportOsale reportOsale = reportOsaleService.selectReportOsaleById(logid);
		mmap.put("reportOsale", reportOsale);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存每天销量排行统计
	 */
	@RequiresPermissions("module:reportOsale:edit")
	@Log(title = "每天销量排行统计", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(ReportOsale reportOsale)
	{		
		return toAjax(reportOsaleService.updateReportOsale(reportOsale));
	}
	
	/**
	 * 删除每天销量排行统计
	 */
	@RequiresPermissions("module:reportOsale:remove")
	@Log(title = "每天销量排行统计", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(reportOsaleService.deleteReportOsaleByIds(ids));
	}
	
}
