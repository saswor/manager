package com.manage.project.module.productUnder.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.productUnder.domain.ProductUnder;
import com.manage.project.module.productUnder.service.IProductUnderService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 商品下架 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/productUnder")
public class ProductUnderController extends BaseController
{
    private String prefix = "module/productUnder";
	
	@Autowired
	private IProductUnderService productUnderService;
	
	@RequiresPermissions("module:productUnder:view")
	@GetMapping()
	public String productUnder()
	{
	    return prefix + "/productUnder";
	}
	
	/**
	 * 查询商品下架列表
	 */
	@RequiresPermissions("module:productUnder:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(ProductUnder productUnder)
	{
		startPage();
        List<ProductUnder> list = productUnderService.selectProductUnderList(productUnder);
		return getDataTable(list);
	}
	
	/**
	 * 新增商品下架
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存商品下架
	 */
	@RequiresPermissions("module:productUnder:add")
	@Log(title = "商品下架", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(ProductUnder productUnder)
	{		
		return toAjax(productUnderService.insertProductUnder(productUnder));
	}

	/**
	 * 修改商品下架
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		ProductUnder productUnder = productUnderService.selectProductUnderById(logid);
		mmap.put("productUnder", productUnder);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存商品下架
	 */
	@RequiresPermissions("module:productUnder:edit")
	@Log(title = "商品下架", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(ProductUnder productUnder)
	{		
		return toAjax(productUnderService.updateProductUnder(productUnder));
	}
	
	/**
	 * 删除商品下架
	 */
	@RequiresPermissions("module:productUnder:remove")
	@Log(title = "商品下架", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(productUnderService.deleteProductUnderByIds(ids));
	}
	
}
