package com.manage.project.module.vendingLanep.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.vendingLanep.mapper.VendingLanepMapper;
import com.manage.project.module.vendingLanep.domain.VendingLanep;
import com.manage.project.module.vendingLanep.service.IVendingLanepService;
import com.manage.common.support.Convert;

/**
 * 售货机货道商品 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class VendingLanepServiceImpl implements IVendingLanepService 
{
	@Autowired
	private VendingLanepMapper vendingLanepMapper;

	/**
     * 查询售货机货道商品信息
     * 
     * @param logid 售货机货道商品ID
     * @return 售货机货道商品信息
     */
    @Override
	public VendingLanep selectVendingLanepById(String logid)
	{
	    return vendingLanepMapper.selectVendingLanepById(logid);
	}
	
	/**
     * 查询售货机货道商品列表
     * 
     * @param vendingLanep 售货机货道商品信息
     * @return 售货机货道商品集合
     */
	@Override
	public List<VendingLanep> selectVendingLanepList(VendingLanep vendingLanep)
	{
	    return vendingLanepMapper.selectVendingLanepList(vendingLanep);
	}
	
    /**
     * 新增售货机货道商品
     * 
     * @param vendingLanep 售货机货道商品信息
     * @return 结果
     */
	@Override
	public int insertVendingLanep(VendingLanep vendingLanep)
	{
	    return vendingLanepMapper.insertVendingLanep(vendingLanep);
	}
	
	/**
     * 修改售货机货道商品
     * 
     * @param vendingLanep 售货机货道商品信息
     * @return 结果
     */
	@Override
	public int updateVendingLanep(VendingLanep vendingLanep)
	{
	    return vendingLanepMapper.updateVendingLanep(vendingLanep);
	}

	/**
     * 删除售货机货道商品对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteVendingLanepByIds(String ids)
	{
		return vendingLanepMapper.deleteVendingLanepByIds(Convert.toStrArray(ids));
	}
	
}
