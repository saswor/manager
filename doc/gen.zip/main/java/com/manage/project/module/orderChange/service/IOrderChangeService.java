package com.manage.project.module.orderChange.service;

import com.manage.project.module.orderChange.domain.OrderChange;
import java.util.List;

/**
 * 订单状态 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IOrderChangeService 
{
	/**
     * 查询订单状态信息
     * 
     * @param logid 订单状态ID
     * @return 订单状态信息
     */
	public OrderChange selectOrderChangeById(String logid);
	
	/**
     * 查询订单状态列表
     * 
     * @param orderChange 订单状态信息
     * @return 订单状态集合
     */
	public List<OrderChange> selectOrderChangeList(OrderChange orderChange);
	
	/**
     * 新增订单状态
     * 
     * @param orderChange 订单状态信息
     * @return 结果
     */
	public int insertOrderChange(OrderChange orderChange);
	
	/**
     * 修改订单状态
     * 
     * @param orderChange 订单状态信息
     * @return 结果
     */
	public int updateOrderChange(OrderChange orderChange);
		
	/**
     * 删除订单状态信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOrderChangeByIds(String ids);
	
}
