package com.manage.project.module.vendingLanep.service;

import com.manage.project.module.vendingLanep.domain.VendingLanep;
import java.util.List;

/**
 * 售货机货道商品 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IVendingLanepService 
{
	/**
     * 查询售货机货道商品信息
     * 
     * @param logid 售货机货道商品ID
     * @return 售货机货道商品信息
     */
	public VendingLanep selectVendingLanepById(String logid);
	
	/**
     * 查询售货机货道商品列表
     * 
     * @param vendingLanep 售货机货道商品信息
     * @return 售货机货道商品集合
     */
	public List<VendingLanep> selectVendingLanepList(VendingLanep vendingLanep);
	
	/**
     * 新增售货机货道商品
     * 
     * @param vendingLanep 售货机货道商品信息
     * @return 结果
     */
	public int insertVendingLanep(VendingLanep vendingLanep);
	
	/**
     * 修改售货机货道商品
     * 
     * @param vendingLanep 售货机货道商品信息
     * @return 结果
     */
	public int updateVendingLanep(VendingLanep vendingLanep);
		
	/**
     * 删除售货机货道商品信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteVendingLanepByIds(String ids);
	
}
