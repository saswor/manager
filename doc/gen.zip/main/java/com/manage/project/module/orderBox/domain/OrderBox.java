package com.manage.project.module.orderBox.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 记录每个商品的货道出库情况表 as_order_box
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class OrderBox extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 商品货道编号 */
	private String proboxId;
	/** 公司编号 */
	private String corpId;
	/** 订单商品编号 */
	private String prodetailId;
	/** 订单编号 */
	private String orderId;
	/** 终端订单编号 */
	private String torderId;
	/** 售货机编号 */
	private String siteId;
	/** 售货机名称 */
	private String siteName;
	/** 货道开始号 */
	private Integer laneSId;
	/** 货道结束号 */
	private Integer laneEId;
	/** 商品编号 */
	private String productId;
	/** 商品名称 */
	private String productName;
	/** 商品采购价 */
	private Float buyPrice;
	/** 商品标准售价 */
	private Float salePrice;
	/** 商品支付价格 */
	private Float payPrice;
	/** 优惠金额(整机优惠采用平均法计算优惠以及支付价格) */
	private Float favPrice;
	/** 退款金额(现支持全额退款，采用平均法计算每件商品退款金额) */
	private Float returnPrice;
	/** 毛利 */
	private Float profitMoney;
	/** 补货单号 */
	private String supplyId;
	/** 出柜状态 1:未出柜(代表商品还在柜子中) 2:正常已出柜(代表商品已存放在出货口) 3:异常已出柜(货道出货失败可以另外货道代替出货) 4:出柜失败 */
	private String outState;
	/** 状态时间 */
	private String stateTime;
	/** 创建时间 */
	private String createTime;
	/**  */
	private Integer outIndex;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setProboxId(String proboxId) 
	{
		this.proboxId = proboxId;
	}

	public String getProboxId() 
	{
		return proboxId;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setProdetailId(String prodetailId) 
	{
		this.prodetailId = prodetailId;
	}

	public String getProdetailId() 
	{
		return prodetailId;
	}
	public void setOrderId(String orderId) 
	{
		this.orderId = orderId;
	}

	public String getOrderId() 
	{
		return orderId;
	}
	public void setTorderId(String torderId) 
	{
		this.torderId = torderId;
	}

	public String getTorderId() 
	{
		return torderId;
	}
	public void setSiteId(String siteId) 
	{
		this.siteId = siteId;
	}

	public String getSiteId() 
	{
		return siteId;
	}
	public void setSiteName(String siteName) 
	{
		this.siteName = siteName;
	}

	public String getSiteName() 
	{
		return siteName;
	}
	public void setLaneSId(Integer laneSId) 
	{
		this.laneSId = laneSId;
	}

	public Integer getLaneSId() 
	{
		return laneSId;
	}
	public void setLaneEId(Integer laneEId) 
	{
		this.laneEId = laneEId;
	}

	public Integer getLaneEId() 
	{
		return laneEId;
	}
	public void setProductId(String productId) 
	{
		this.productId = productId;
	}

	public String getProductId() 
	{
		return productId;
	}
	public void setProductName(String productName) 
	{
		this.productName = productName;
	}

	public String getProductName() 
	{
		return productName;
	}
	public void setBuyPrice(Float buyPrice) 
	{
		this.buyPrice = buyPrice;
	}

	public Float getBuyPrice() 
	{
		return buyPrice;
	}
	public void setSalePrice(Float salePrice) 
	{
		this.salePrice = salePrice;
	}

	public Float getSalePrice() 
	{
		return salePrice;
	}
	public void setPayPrice(Float payPrice) 
	{
		this.payPrice = payPrice;
	}

	public Float getPayPrice() 
	{
		return payPrice;
	}
	public void setFavPrice(Float favPrice) 
	{
		this.favPrice = favPrice;
	}

	public Float getFavPrice() 
	{
		return favPrice;
	}
	public void setReturnPrice(Float returnPrice) 
	{
		this.returnPrice = returnPrice;
	}

	public Float getReturnPrice() 
	{
		return returnPrice;
	}
	public void setProfitMoney(Float profitMoney) 
	{
		this.profitMoney = profitMoney;
	}

	public Float getProfitMoney() 
	{
		return profitMoney;
	}
	public void setSupplyId(String supplyId) 
	{
		this.supplyId = supplyId;
	}

	public String getSupplyId() 
	{
		return supplyId;
	}
	public void setOutState(String outState) 
	{
		this.outState = outState;
	}

	public String getOutState() 
	{
		return outState;
	}
	public void setStateTime(String stateTime) 
	{
		this.stateTime = stateTime;
	}

	public String getStateTime() 
	{
		return stateTime;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}
	public void setOutIndex(Integer outIndex) 
	{
		this.outIndex = outIndex;
	}

	public Integer getOutIndex() 
	{
		return outIndex;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("proboxId", getProboxId())
            .append("corpId", getCorpId())
            .append("prodetailId", getProdetailId())
            .append("orderId", getOrderId())
            .append("torderId", getTorderId())
            .append("siteId", getSiteId())
            .append("siteName", getSiteName())
            .append("laneSId", getLaneSId())
            .append("laneEId", getLaneEId())
            .append("productId", getProductId())
            .append("productName", getProductName())
            .append("buyPrice", getBuyPrice())
            .append("salePrice", getSalePrice())
            .append("payPrice", getPayPrice())
            .append("favPrice", getFavPrice())
            .append("returnPrice", getReturnPrice())
            .append("profitMoney", getProfitMoney())
            .append("supplyId", getSupplyId())
            .append("outState", getOutState())
            .append("stateTime", getStateTime())
            .append("createTime", getCreateTime())
            .append("outIndex", getOutIndex())
            .toString();
    }
}
