package com.manage.project.module.vendingPconfig.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.vendingPconfig.domain.VendingPconfig;
import com.manage.project.module.vendingPconfig.service.IVendingPconfigService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 售货机配货模板 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/vendingPconfig")
public class VendingPconfigController extends BaseController
{
    private String prefix = "module/vendingPconfig";
	
	@Autowired
	private IVendingPconfigService vendingPconfigService;
	
	@RequiresPermissions("module:vendingPconfig:view")
	@GetMapping()
	public String vendingPconfig()
	{
	    return prefix + "/vendingPconfig";
	}
	
	/**
	 * 查询售货机配货模板列表
	 */
	@RequiresPermissions("module:vendingPconfig:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(VendingPconfig vendingPconfig)
	{
		startPage();
        List<VendingPconfig> list = vendingPconfigService.selectVendingPconfigList(vendingPconfig);
		return getDataTable(list);
	}
	
	/**
	 * 新增售货机配货模板
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存售货机配货模板
	 */
	@RequiresPermissions("module:vendingPconfig:add")
	@Log(title = "售货机配货模板", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(VendingPconfig vendingPconfig)
	{		
		return toAjax(vendingPconfigService.insertVendingPconfig(vendingPconfig));
	}

	/**
	 * 修改售货机配货模板
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		VendingPconfig vendingPconfig = vendingPconfigService.selectVendingPconfigById(logid);
		mmap.put("vendingPconfig", vendingPconfig);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存售货机配货模板
	 */
	@RequiresPermissions("module:vendingPconfig:edit")
	@Log(title = "售货机配货模板", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(VendingPconfig vendingPconfig)
	{		
		return toAjax(vendingPconfigService.updateVendingPconfig(vendingPconfig));
	}
	
	/**
	 * 删除售货机配货模板
	 */
	@RequiresPermissions("module:vendingPconfig:remove")
	@Log(title = "售货机配货模板", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(vendingPconfigService.deleteVendingPconfigByIds(ids));
	}
	
}
