package com.manage.project.module.supplyConfig.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.supplyConfig.domain.SupplyConfig;
import com.manage.project.module.supplyConfig.service.ISupplyConfigService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/supplyConfig")
public class SupplyConfigController extends BaseController
{
    private String prefix = "module/supplyConfig";
	
	@Autowired
	private ISupplyConfigService supplyConfigService;
	
	@RequiresPermissions("module:supplyConfig:view")
	@GetMapping()
	public String supplyConfig()
	{
	    return prefix + "/supplyConfig";
	}
	
	/**
	 * 查询商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。列表
	 */
	@RequiresPermissions("module:supplyConfig:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(SupplyConfig supplyConfig)
	{
		startPage();
        List<SupplyConfig> list = supplyConfigService.selectSupplyConfigList(supplyConfig);
		return getDataTable(list);
	}
	
	/**
	 * 新增商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。
	 */
	@RequiresPermissions("module:supplyConfig:add")
	@Log(title = "商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(SupplyConfig supplyConfig)
	{		
		return toAjax(supplyConfigService.insertSupplyConfig(supplyConfig));
	}

	/**
	 * 修改商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		SupplyConfig supplyConfig = supplyConfigService.selectSupplyConfigById(logid);
		mmap.put("supplyConfig", supplyConfig);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。
	 */
	@RequiresPermissions("module:supplyConfig:edit")
	@Log(title = "商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(SupplyConfig supplyConfig)
	{		
		return toAjax(supplyConfigService.updateSupplyConfig(supplyConfig));
	}
	
	/**
	 * 删除商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。
	 */
	@RequiresPermissions("module:supplyConfig:remove")
	@Log(title = "商品补货配置，此补货是按线路补货，一条线路可拥有多个补货配置，一个补货配置可自由删减补货点位。", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(supplyConfigService.deleteSupplyConfigByIds(ids));
	}
	
}
