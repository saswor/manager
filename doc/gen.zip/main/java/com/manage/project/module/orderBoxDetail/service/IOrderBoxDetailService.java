package com.manage.project.module.orderBoxDetail.service;

import com.manage.project.module.orderBoxDetail.domain.OrderBoxDetail;
import java.util.List;

/**
 * 订单商品出货统计基，主要为商品统计提供统计依据。 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IOrderBoxDetailService 
{
	/**
     * 查询订单商品出货统计基，主要为商品统计提供统计依据。信息
     * 
     * @param logid 订单商品出货统计基，主要为商品统计提供统计依据。ID
     * @return 订单商品出货统计基，主要为商品统计提供统计依据。信息
     */
	public OrderBoxDetail selectOrderBoxDetailById(String logid);
	
	/**
     * 查询订单商品出货统计基，主要为商品统计提供统计依据。列表
     * 
     * @param orderBoxDetail 订单商品出货统计基，主要为商品统计提供统计依据。信息
     * @return 订单商品出货统计基，主要为商品统计提供统计依据。集合
     */
	public List<OrderBoxDetail> selectOrderBoxDetailList(OrderBoxDetail orderBoxDetail);
	
	/**
     * 新增订单商品出货统计基，主要为商品统计提供统计依据。
     * 
     * @param orderBoxDetail 订单商品出货统计基，主要为商品统计提供统计依据。信息
     * @return 结果
     */
	public int insertOrderBoxDetail(OrderBoxDetail orderBoxDetail);
	
	/**
     * 修改订单商品出货统计基，主要为商品统计提供统计依据。
     * 
     * @param orderBoxDetail 订单商品出货统计基，主要为商品统计提供统计依据。信息
     * @return 结果
     */
	public int updateOrderBoxDetail(OrderBoxDetail orderBoxDetail);
		
	/**
     * 删除订单商品出货统计基，主要为商品统计提供统计依据。信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOrderBoxDetailByIds(String ids);
	
}
