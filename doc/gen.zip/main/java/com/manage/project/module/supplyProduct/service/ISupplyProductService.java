package com.manage.project.module.supplyProduct.service;

import com.manage.project.module.supplyProduct.domain.SupplyProduct;
import java.util.List;

/**
 * 补货商品记录 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface ISupplyProductService 
{
	/**
     * 查询补货商品记录信息
     * 
     * @param logid 补货商品记录ID
     * @return 补货商品记录信息
     */
	public SupplyProduct selectSupplyProductById(String logid);
	
	/**
     * 查询补货商品记录列表
     * 
     * @param supplyProduct 补货商品记录信息
     * @return 补货商品记录集合
     */
	public List<SupplyProduct> selectSupplyProductList(SupplyProduct supplyProduct);
	
	/**
     * 新增补货商品记录
     * 
     * @param supplyProduct 补货商品记录信息
     * @return 结果
     */
	public int insertSupplyProduct(SupplyProduct supplyProduct);
	
	/**
     * 修改补货商品记录
     * 
     * @param supplyProduct 补货商品记录信息
     * @return 结果
     */
	public int updateSupplyProduct(SupplyProduct supplyProduct);
		
	/**
     * 删除补货商品记录信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteSupplyProductByIds(String ids);
	
}
