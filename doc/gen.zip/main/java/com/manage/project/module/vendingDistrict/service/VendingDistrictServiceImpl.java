package com.manage.project.module.vendingDistrict.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.vendingDistrict.mapper.VendingDistrictMapper;
import com.manage.project.module.vendingDistrict.domain.VendingDistrict;
import com.manage.project.module.vendingDistrict.service.IVendingDistrictService;
import com.manage.common.support.Convert;

/**
 * 管理线路的区域 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class VendingDistrictServiceImpl implements IVendingDistrictService 
{
	@Autowired
	private VendingDistrictMapper vendingDistrictMapper;

	/**
     * 查询管理线路的区域信息
     * 
     * @param logid 管理线路的区域ID
     * @return 管理线路的区域信息
     */
    @Override
	public VendingDistrict selectVendingDistrictById(String logid)
	{
	    return vendingDistrictMapper.selectVendingDistrictById(logid);
	}
	
	/**
     * 查询管理线路的区域列表
     * 
     * @param vendingDistrict 管理线路的区域信息
     * @return 管理线路的区域集合
     */
	@Override
	public List<VendingDistrict> selectVendingDistrictList(VendingDistrict vendingDistrict)
	{
	    return vendingDistrictMapper.selectVendingDistrictList(vendingDistrict);
	}
	
    /**
     * 新增管理线路的区域
     * 
     * @param vendingDistrict 管理线路的区域信息
     * @return 结果
     */
	@Override
	public int insertVendingDistrict(VendingDistrict vendingDistrict)
	{
	    return vendingDistrictMapper.insertVendingDistrict(vendingDistrict);
	}
	
	/**
     * 修改管理线路的区域
     * 
     * @param vendingDistrict 管理线路的区域信息
     * @return 结果
     */
	@Override
	public int updateVendingDistrict(VendingDistrict vendingDistrict)
	{
	    return vendingDistrictMapper.updateVendingDistrict(vendingDistrict);
	}

	/**
     * 删除管理线路的区域对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteVendingDistrictByIds(String ids)
	{
		return vendingDistrictMapper.deleteVendingDistrictByIds(Convert.toStrArray(ids));
	}
	
}
