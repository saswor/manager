package com.manage.project.module.payconfigAlipay.mapper;

import com.manage.project.module.payconfigAlipay.domain.PayconfigAlipay;
import java.util.List;	

/**
 * 微信支付配置 数据层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface PayconfigAlipayMapper 
{
	/**
     * 查询微信支付配置信息
     * 
     * @param logid 微信支付配置ID
     * @return 微信支付配置信息
     */
	public PayconfigAlipay selectPayconfigAlipayById(String logid);
	
	/**
     * 查询微信支付配置列表
     * 
     * @param payconfigAlipay 微信支付配置信息
     * @return 微信支付配置集合
     */
	public List<PayconfigAlipay> selectPayconfigAlipayList(PayconfigAlipay payconfigAlipay);
	
	/**
     * 新增微信支付配置
     * 
     * @param payconfigAlipay 微信支付配置信息
     * @return 结果
     */
	public int insertPayconfigAlipay(PayconfigAlipay payconfigAlipay);
	
	/**
     * 修改微信支付配置
     * 
     * @param payconfigAlipay 微信支付配置信息
     * @return 结果
     */
	public int updatePayconfigAlipay(PayconfigAlipay payconfigAlipay);
	
	/**
     * 删除微信支付配置
     * 
     * @param logid 微信支付配置ID
     * @return 结果
     */
	public int deletePayconfigAlipayById(String logid);
	
	/**
     * 批量删除微信支付配置
     * 
     * @param logids 需要删除的数据ID
     * @return 结果
     */
	public int deletePayconfigAlipayByIds(String[] logids);
	
}