package com.manage.project.module.productInfo.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.productInfo.domain.ProductInfo;
import com.manage.project.module.productInfo.service.IProductInfoService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 记录商品 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/productInfo")
public class ProductInfoController extends BaseController
{
    private String prefix = "module/productInfo";
	
	@Autowired
	private IProductInfoService productInfoService;
	
	@RequiresPermissions("module:productInfo:view")
	@GetMapping()
	public String productInfo()
	{
	    return prefix + "/productInfo";
	}
	
	/**
	 * 查询记录商品列表
	 */
	@RequiresPermissions("module:productInfo:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(ProductInfo productInfo)
	{
		startPage();
        List<ProductInfo> list = productInfoService.selectProductInfoList(productInfo);
		return getDataTable(list);
	}
	
	/**
	 * 新增记录商品
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存记录商品
	 */
	@RequiresPermissions("module:productInfo:add")
	@Log(title = "记录商品", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(ProductInfo productInfo)
	{		
		return toAjax(productInfoService.insertProductInfo(productInfo));
	}

	/**
	 * 修改记录商品
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		ProductInfo productInfo = productInfoService.selectProductInfoById(logid);
		mmap.put("productInfo", productInfo);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存记录商品
	 */
	@RequiresPermissions("module:productInfo:edit")
	@Log(title = "记录商品", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(ProductInfo productInfo)
	{		
		return toAjax(productInfoService.updateProductInfo(productInfo));
	}
	
	/**
	 * 删除记录商品
	 */
	@RequiresPermissions("module:productInfo:remove")
	@Log(title = "记录商品", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(productInfoService.deleteProductInfoByIds(ids));
	}
	
}
