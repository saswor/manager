package com.manage.project.module.productInfo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.productInfo.mapper.ProductInfoMapper;
import com.manage.project.module.productInfo.domain.ProductInfo;
import com.manage.project.module.productInfo.service.IProductInfoService;
import com.manage.common.support.Convert;

/**
 * 记录商品 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class ProductInfoServiceImpl implements IProductInfoService 
{
	@Autowired
	private ProductInfoMapper productInfoMapper;

	/**
     * 查询记录商品信息
     * 
     * @param logid 记录商品ID
     * @return 记录商品信息
     */
    @Override
	public ProductInfo selectProductInfoById(String logid)
	{
	    return productInfoMapper.selectProductInfoById(logid);
	}
	
	/**
     * 查询记录商品列表
     * 
     * @param productInfo 记录商品信息
     * @return 记录商品集合
     */
	@Override
	public List<ProductInfo> selectProductInfoList(ProductInfo productInfo)
	{
	    return productInfoMapper.selectProductInfoList(productInfo);
	}
	
    /**
     * 新增记录商品
     * 
     * @param productInfo 记录商品信息
     * @return 结果
     */
	@Override
	public int insertProductInfo(ProductInfo productInfo)
	{
	    return productInfoMapper.insertProductInfo(productInfo);
	}
	
	/**
     * 修改记录商品
     * 
     * @param productInfo 记录商品信息
     * @return 结果
     */
	@Override
	public int updateProductInfo(ProductInfo productInfo)
	{
	    return productInfoMapper.updateProductInfo(productInfo);
	}

	/**
     * 删除记录商品对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteProductInfoByIds(String ids)
	{
		return productInfoMapper.deleteProductInfoByIds(Convert.toStrArray(ids));
	}
	
}
