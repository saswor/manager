package com.manage.project.module.supplyOrder.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.supplyOrder.domain.SupplyOrder;
import com.manage.project.module.supplyOrder.service.ISupplyOrderService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/supplyOrder")
public class SupplyOrderController extends BaseController
{
    private String prefix = "module/supplyOrder";
	
	@Autowired
	private ISupplyOrderService supplyOrderService;
	
	@RequiresPermissions("module:supplyOrder:view")
	@GetMapping()
	public String supplyOrder()
	{
	    return prefix + "/supplyOrder";
	}
	
	/**
	 * 查询补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。列表
	 */
	@RequiresPermissions("module:supplyOrder:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(SupplyOrder supplyOrder)
	{
		startPage();
        List<SupplyOrder> list = supplyOrderService.selectSupplyOrderList(supplyOrder);
		return getDataTable(list);
	}
	
	/**
	 * 新增补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。
	 */
	@RequiresPermissions("module:supplyOrder:add")
	@Log(title = "补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(SupplyOrder supplyOrder)
	{		
		return toAjax(supplyOrderService.insertSupplyOrder(supplyOrder));
	}

	/**
	 * 修改补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		SupplyOrder supplyOrder = supplyOrderService.selectSupplyOrderById(logid);
		mmap.put("supplyOrder", supplyOrder);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。
	 */
	@RequiresPermissions("module:supplyOrder:edit")
	@Log(title = "补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(SupplyOrder supplyOrder)
	{		
		return toAjax(supplyOrderService.updateSupplyOrder(supplyOrder));
	}
	
	/**
	 * 删除补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。
	 */
	@RequiresPermissions("module:supplyOrder:remove")
	@Log(title = "补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(supplyOrderService.deleteSupplyOrderByIds(ids));
	}
	
}
