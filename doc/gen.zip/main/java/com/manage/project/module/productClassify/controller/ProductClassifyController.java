package com.manage.project.module.productClassify.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.productClassify.domain.ProductClassify;
import com.manage.project.module.productClassify.service.IProductClassifyService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 商品分类 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/productClassify")
public class ProductClassifyController extends BaseController
{
    private String prefix = "module/productClassify";
	
	@Autowired
	private IProductClassifyService productClassifyService;
	
	@RequiresPermissions("module:productClassify:view")
	@GetMapping()
	public String productClassify()
	{
	    return prefix + "/productClassify";
	}
	
	/**
	 * 查询商品分类列表
	 */
	@RequiresPermissions("module:productClassify:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(ProductClassify productClassify)
	{
		startPage();
        List<ProductClassify> list = productClassifyService.selectProductClassifyList(productClassify);
		return getDataTable(list);
	}
	
	/**
	 * 新增商品分类
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存商品分类
	 */
	@RequiresPermissions("module:productClassify:add")
	@Log(title = "商品分类", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(ProductClassify productClassify)
	{		
		return toAjax(productClassifyService.insertProductClassify(productClassify));
	}

	/**
	 * 修改商品分类
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		ProductClassify productClassify = productClassifyService.selectProductClassifyById(logid);
		mmap.put("productClassify", productClassify);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存商品分类
	 */
	@RequiresPermissions("module:productClassify:edit")
	@Log(title = "商品分类", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(ProductClassify productClassify)
	{		
		return toAjax(productClassifyService.updateProductClassify(productClassify));
	}
	
	/**
	 * 删除商品分类
	 */
	@RequiresPermissions("module:productClassify:remove")
	@Log(title = "商品分类", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(productClassifyService.deleteProductClassifyByIds(ids));
	}
	
}
