package com.manage.project.module.stockWarehouse.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 仓库商品库存存量表 as_stock_warehouse
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class StockWarehouse extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 事件编号 */
	private String wstockId;
	/** 仓库编号 */
	private String stockId;
	/** 仓库名称 */
	private String stokcName;
	/** 商品编号 */
	private String productId;
	/** 商品名称 */
	private String productName;
	/** 总库存数量 */
	private Integer totalNum;
	/** 当前库存总数量 */
	private Integer curNum;
	/** 过期总数 */
	private Integer overNum;
	/** 警戒值 */
	private Integer warnNum;
	/** 托管公司编号 */
	private String corpId;
	/** 创建时间 */
	private String createTime;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setWstockId(String wstockId) 
	{
		this.wstockId = wstockId;
	}

	public String getWstockId() 
	{
		return wstockId;
	}
	public void setStockId(String stockId) 
	{
		this.stockId = stockId;
	}

	public String getStockId() 
	{
		return stockId;
	}
	public void setStokcName(String stokcName) 
	{
		this.stokcName = stokcName;
	}

	public String getStokcName() 
	{
		return stokcName;
	}
	public void setProductId(String productId) 
	{
		this.productId = productId;
	}

	public String getProductId() 
	{
		return productId;
	}
	public void setProductName(String productName) 
	{
		this.productName = productName;
	}

	public String getProductName() 
	{
		return productName;
	}
	public void setTotalNum(Integer totalNum) 
	{
		this.totalNum = totalNum;
	}

	public Integer getTotalNum() 
	{
		return totalNum;
	}
	public void setCurNum(Integer curNum) 
	{
		this.curNum = curNum;
	}

	public Integer getCurNum() 
	{
		return curNum;
	}
	public void setOverNum(Integer overNum) 
	{
		this.overNum = overNum;
	}

	public Integer getOverNum() 
	{
		return overNum;
	}
	public void setWarnNum(Integer warnNum) 
	{
		this.warnNum = warnNum;
	}

	public Integer getWarnNum() 
	{
		return warnNum;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("wstockId", getWstockId())
            .append("stockId", getStockId())
            .append("stokcName", getStokcName())
            .append("productId", getProductId())
            .append("productName", getProductName())
            .append("totalNum", getTotalNum())
            .append("curNum", getCurNum())
            .append("overNum", getOverNum())
            .append("warnNum", getWarnNum())
            .append("corpId", getCorpId())
            .append("createTime", getCreateTime())
            .toString();
    }
}
