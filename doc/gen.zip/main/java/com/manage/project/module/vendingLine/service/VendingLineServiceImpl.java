package com.manage.project.module.vendingLine.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.vendingLine.mapper.VendingLineMapper;
import com.manage.project.module.vendingLine.domain.VendingLine;
import com.manage.project.module.vendingLine.service.IVendingLineService;
import com.manage.common.support.Convert;

/**
 * 点位的线路 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class VendingLineServiceImpl implements IVendingLineService 
{
	@Autowired
	private VendingLineMapper vendingLineMapper;

	/**
     * 查询点位的线路信息
     * 
     * @param logid 点位的线路ID
     * @return 点位的线路信息
     */
    @Override
	public VendingLine selectVendingLineById(String logid)
	{
	    return vendingLineMapper.selectVendingLineById(logid);
	}
	
	/**
     * 查询点位的线路列表
     * 
     * @param vendingLine 点位的线路信息
     * @return 点位的线路集合
     */
	@Override
	public List<VendingLine> selectVendingLineList(VendingLine vendingLine)
	{
	    return vendingLineMapper.selectVendingLineList(vendingLine);
	}
	
    /**
     * 新增点位的线路
     * 
     * @param vendingLine 点位的线路信息
     * @return 结果
     */
	@Override
	public int insertVendingLine(VendingLine vendingLine)
	{
	    return vendingLineMapper.insertVendingLine(vendingLine);
	}
	
	/**
     * 修改点位的线路
     * 
     * @param vendingLine 点位的线路信息
     * @return 结果
     */
	@Override
	public int updateVendingLine(VendingLine vendingLine)
	{
	    return vendingLineMapper.updateVendingLine(vendingLine);
	}

	/**
     * 删除点位的线路对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteVendingLineByIds(String ids)
	{
		return vendingLineMapper.deleteVendingLineByIds(Convert.toStrArray(ids));
	}
	
}
