package com.manage.project.module.reportOsale.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.reportOsale.mapper.ReportOsaleMapper;
import com.manage.project.module.reportOsale.domain.ReportOsale;
import com.manage.project.module.reportOsale.service.IReportOsaleService;
import com.manage.common.support.Convert;

/**
 * 每天销量排行统计 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class ReportOsaleServiceImpl implements IReportOsaleService 
{
	@Autowired
	private ReportOsaleMapper reportOsaleMapper;

	/**
     * 查询每天销量排行统计信息
     * 
     * @param logid 每天销量排行统计ID
     * @return 每天销量排行统计信息
     */
    @Override
	public ReportOsale selectReportOsaleById(String logid)
	{
	    return reportOsaleMapper.selectReportOsaleById(logid);
	}
	
	/**
     * 查询每天销量排行统计列表
     * 
     * @param reportOsale 每天销量排行统计信息
     * @return 每天销量排行统计集合
     */
	@Override
	public List<ReportOsale> selectReportOsaleList(ReportOsale reportOsale)
	{
	    return reportOsaleMapper.selectReportOsaleList(reportOsale);
	}
	
    /**
     * 新增每天销量排行统计
     * 
     * @param reportOsale 每天销量排行统计信息
     * @return 结果
     */
	@Override
	public int insertReportOsale(ReportOsale reportOsale)
	{
	    return reportOsaleMapper.insertReportOsale(reportOsale);
	}
	
	/**
     * 修改每天销量排行统计
     * 
     * @param reportOsale 每天销量排行统计信息
     * @return 结果
     */
	@Override
	public int updateReportOsale(ReportOsale reportOsale)
	{
	    return reportOsaleMapper.updateReportOsale(reportOsale);
	}

	/**
     * 删除每天销量排行统计对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteReportOsaleByIds(String ids)
	{
		return reportOsaleMapper.deleteReportOsaleByIds(Convert.toStrArray(ids));
	}
	
}
