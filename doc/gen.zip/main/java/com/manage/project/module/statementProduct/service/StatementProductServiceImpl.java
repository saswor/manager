package com.manage.project.module.statementProduct.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.statementProduct.mapper.StatementProductMapper;
import com.manage.project.module.statementProduct.domain.StatementProduct;
import com.manage.project.module.statementProduct.service.IStatementProductService;
import com.manage.common.support.Convert;

/**
 * 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class StatementProductServiceImpl implements IStatementProductService 
{
	@Autowired
	private StatementProductMapper statementProductMapper;

	/**
     * 查询补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。信息
     * 
     * @param logid 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。ID
     * @return 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。信息
     */
    @Override
	public StatementProduct selectStatementProductById(String logid)
	{
	    return statementProductMapper.selectStatementProductById(logid);
	}
	
	/**
     * 查询补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。列表
     * 
     * @param statementProduct 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。信息
     * @return 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。集合
     */
	@Override
	public List<StatementProduct> selectStatementProductList(StatementProduct statementProduct)
	{
	    return statementProductMapper.selectStatementProductList(statementProduct);
	}
	
    /**
     * 新增补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。
     * 
     * @param statementProduct 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。信息
     * @return 结果
     */
	@Override
	public int insertStatementProduct(StatementProduct statementProduct)
	{
	    return statementProductMapper.insertStatementProduct(statementProduct);
	}
	
	/**
     * 修改补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。
     * 
     * @param statementProduct 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。信息
     * @return 结果
     */
	@Override
	public int updateStatementProduct(StatementProduct statementProduct)
	{
	    return statementProductMapper.updateStatementProduct(statementProduct);
	}

	/**
     * 删除补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteStatementProductByIds(String ids)
	{
		return statementProductMapper.deleteStatementProductByIds(Convert.toStrArray(ids));
	}
	
}
