package com.manage.project.module.productOnline.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.productOnline.domain.ProductOnline;
import com.manage.project.module.productOnline.service.IProductOnlineService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 记录在线购买的商品 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/productOnline")
public class ProductOnlineController extends BaseController
{
    private String prefix = "module/productOnline";
	
	@Autowired
	private IProductOnlineService productOnlineService;
	
	@RequiresPermissions("module:productOnline:view")
	@GetMapping()
	public String productOnline()
	{
	    return prefix + "/productOnline";
	}
	
	/**
	 * 查询记录在线购买的商品列表
	 */
	@RequiresPermissions("module:productOnline:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(ProductOnline productOnline)
	{
		startPage();
        List<ProductOnline> list = productOnlineService.selectProductOnlineList(productOnline);
		return getDataTable(list);
	}
	
	/**
	 * 新增记录在线购买的商品
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存记录在线购买的商品
	 */
	@RequiresPermissions("module:productOnline:add")
	@Log(title = "记录在线购买的商品", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(ProductOnline productOnline)
	{		
		return toAjax(productOnlineService.insertProductOnline(productOnline));
	}

	/**
	 * 修改记录在线购买的商品
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		ProductOnline productOnline = productOnlineService.selectProductOnlineById(logid);
		mmap.put("productOnline", productOnline);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存记录在线购买的商品
	 */
	@RequiresPermissions("module:productOnline:edit")
	@Log(title = "记录在线购买的商品", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(ProductOnline productOnline)
	{		
		return toAjax(productOnlineService.updateProductOnline(productOnline));
	}
	
	/**
	 * 删除记录在线购买的商品
	 */
	@RequiresPermissions("module:productOnline:remove")
	@Log(title = "记录在线购买的商品", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(productOnlineService.deleteProductOnlineByIds(ids));
	}
	
}
