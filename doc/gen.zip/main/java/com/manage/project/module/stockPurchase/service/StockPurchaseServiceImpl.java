package com.manage.project.module.stockPurchase.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.stockPurchase.mapper.StockPurchaseMapper;
import com.manage.project.module.stockPurchase.domain.StockPurchase;
import com.manage.project.module.stockPurchase.service.IStockPurchaseService;
import com.manage.common.support.Convert;

/**
 * 仓库采购记录 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class StockPurchaseServiceImpl implements IStockPurchaseService 
{
	@Autowired
	private StockPurchaseMapper stockPurchaseMapper;

	/**
     * 查询仓库采购记录信息
     * 
     * @param logid 仓库采购记录ID
     * @return 仓库采购记录信息
     */
    @Override
	public StockPurchase selectStockPurchaseById(String logid)
	{
	    return stockPurchaseMapper.selectStockPurchaseById(logid);
	}
	
	/**
     * 查询仓库采购记录列表
     * 
     * @param stockPurchase 仓库采购记录信息
     * @return 仓库采购记录集合
     */
	@Override
	public List<StockPurchase> selectStockPurchaseList(StockPurchase stockPurchase)
	{
	    return stockPurchaseMapper.selectStockPurchaseList(stockPurchase);
	}
	
    /**
     * 新增仓库采购记录
     * 
     * @param stockPurchase 仓库采购记录信息
     * @return 结果
     */
	@Override
	public int insertStockPurchase(StockPurchase stockPurchase)
	{
	    return stockPurchaseMapper.insertStockPurchase(stockPurchase);
	}
	
	/**
     * 修改仓库采购记录
     * 
     * @param stockPurchase 仓库采购记录信息
     * @return 结果
     */
	@Override
	public int updateStockPurchase(StockPurchase stockPurchase)
	{
	    return stockPurchaseMapper.updateStockPurchase(stockPurchase);
	}

	/**
     * 删除仓库采购记录对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteStockPurchaseByIds(String ids)
	{
		return stockPurchaseMapper.deleteStockPurchaseByIds(Convert.toStrArray(ids));
	}
	
}
