package com.manage.project.module.stockPpurchase.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 仓库采购记录表 as_stock_ppurchase
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class StockPpurchase extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 仓采商品购记录编号 */
	private String wPPurchaseId;
	/** 采购单编号 */
	private String purchaseId;
	/** 仓库编号 */
	private String stockId;
	/** 仓库名称 */
	private String stokcName;
	/** 商品编号 */
	private String productId;
	/** 商品名称 */
	private String productName;
	/** 供应商编号 */
	private String supplierId;
	/** 采购数量 */
	private Integer pNum;
	/** 采购单价 */
	private Float buyPrice;
	/** 采购总价 */
	private Float totalPrice;
	/** 托管公司编号 */
	private String corpId;
	/** 创建时间 */
	private String createTime;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setWPPurchaseId(String wPPurchaseId) 
	{
		this.wPPurchaseId = wPPurchaseId;
	}

	public String getWPPurchaseId() 
	{
		return wPPurchaseId;
	}
	public void setPurchaseId(String purchaseId) 
	{
		this.purchaseId = purchaseId;
	}

	public String getPurchaseId() 
	{
		return purchaseId;
	}
	public void setStockId(String stockId) 
	{
		this.stockId = stockId;
	}

	public String getStockId() 
	{
		return stockId;
	}
	public void setStokcName(String stokcName) 
	{
		this.stokcName = stokcName;
	}

	public String getStokcName() 
	{
		return stokcName;
	}
	public void setProductId(String productId) 
	{
		this.productId = productId;
	}

	public String getProductId() 
	{
		return productId;
	}
	public void setProductName(String productName) 
	{
		this.productName = productName;
	}

	public String getProductName() 
	{
		return productName;
	}
	public void setSupplierId(String supplierId) 
	{
		this.supplierId = supplierId;
	}

	public String getSupplierId() 
	{
		return supplierId;
	}
	public void setPNum(Integer pNum) 
	{
		this.pNum = pNum;
	}

	public Integer getPNum() 
	{
		return pNum;
	}
	public void setBuyPrice(Float buyPrice) 
	{
		this.buyPrice = buyPrice;
	}

	public Float getBuyPrice() 
	{
		return buyPrice;
	}
	public void setTotalPrice(Float totalPrice) 
	{
		this.totalPrice = totalPrice;
	}

	public Float getTotalPrice() 
	{
		return totalPrice;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("wPPurchaseId", getWPPurchaseId())
            .append("purchaseId", getPurchaseId())
            .append("stockId", getStockId())
            .append("stokcName", getStokcName())
            .append("productId", getProductId())
            .append("productName", getProductName())
            .append("supplierId", getSupplierId())
            .append("pNum", getPNum())
            .append("buyPrice", getBuyPrice())
            .append("totalPrice", getTotalPrice())
            .append("corpId", getCorpId())
            .append("createTime", getCreateTime())
            .toString();
    }
}
