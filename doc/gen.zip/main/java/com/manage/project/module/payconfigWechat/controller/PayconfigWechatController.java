package com.manage.project.module.payconfigWechat.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.payconfigWechat.domain.PayconfigWechat;
import com.manage.project.module.payconfigWechat.service.IPayconfigWechatService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 微信支付配置 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/payconfigWechat")
public class PayconfigWechatController extends BaseController
{
    private String prefix = "module/payconfigWechat";
	
	@Autowired
	private IPayconfigWechatService payconfigWechatService;
	
	@RequiresPermissions("module:payconfigWechat:view")
	@GetMapping()
	public String payconfigWechat()
	{
	    return prefix + "/payconfigWechat";
	}
	
	/**
	 * 查询微信支付配置列表
	 */
	@RequiresPermissions("module:payconfigWechat:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(PayconfigWechat payconfigWechat)
	{
		startPage();
        List<PayconfigWechat> list = payconfigWechatService.selectPayconfigWechatList(payconfigWechat);
		return getDataTable(list);
	}
	
	/**
	 * 新增微信支付配置
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存微信支付配置
	 */
	@RequiresPermissions("module:payconfigWechat:add")
	@Log(title = "微信支付配置", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(PayconfigWechat payconfigWechat)
	{		
		return toAjax(payconfigWechatService.insertPayconfigWechat(payconfigWechat));
	}

	/**
	 * 修改微信支付配置
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		PayconfigWechat payconfigWechat = payconfigWechatService.selectPayconfigWechatById(logid);
		mmap.put("payconfigWechat", payconfigWechat);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存微信支付配置
	 */
	@RequiresPermissions("module:payconfigWechat:edit")
	@Log(title = "微信支付配置", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(PayconfigWechat payconfigWechat)
	{		
		return toAjax(payconfigWechatService.updatePayconfigWechat(payconfigWechat));
	}
	
	/**
	 * 删除微信支付配置
	 */
	@RequiresPermissions("module:payconfigWechat:remove")
	@Log(title = "微信支付配置", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(payconfigWechatService.deletePayconfigWechatByIds(ids));
	}
	
}
