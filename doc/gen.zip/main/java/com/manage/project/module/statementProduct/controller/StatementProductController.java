package com.manage.project.module.statementProduct.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.statementProduct.domain.StatementProduct;
import com.manage.project.module.statementProduct.service.IStatementProductService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/statementProduct")
public class StatementProductController extends BaseController
{
    private String prefix = "module/statementProduct";
	
	@Autowired
	private IStatementProductService statementProductService;
	
	@RequiresPermissions("module:statementProduct:view")
	@GetMapping()
	public String statementProduct()
	{
	    return prefix + "/statementProduct";
	}
	
	/**
	 * 查询补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。列表
	 */
	@RequiresPermissions("module:statementProduct:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(StatementProduct statementProduct)
	{
		startPage();
        List<StatementProduct> list = statementProductService.selectStatementProductList(statementProduct);
		return getDataTable(list);
	}
	
	/**
	 * 新增补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。
	 */
	@RequiresPermissions("module:statementProduct:add")
	@Log(title = "补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(StatementProduct statementProduct)
	{		
		return toAjax(statementProductService.insertStatementProduct(statementProduct));
	}

	/**
	 * 修改补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		StatementProduct statementProduct = statementProductService.selectStatementProductById(logid);
		mmap.put("statementProduct", statementProduct);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。
	 */
	@RequiresPermissions("module:statementProduct:edit")
	@Log(title = "补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(StatementProduct statementProduct)
	{		
		return toAjax(statementProductService.updateStatementProduct(statementProduct));
	}
	
	/**
	 * 删除补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。
	 */
	@RequiresPermissions("module:statementProduct:remove")
	@Log(title = "补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(statementProductService.deleteStatementProductByIds(ids));
	}
	
}
