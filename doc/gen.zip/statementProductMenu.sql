-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。', '3', '1', '/module/statementProduct', 'C', '0', 'module:statementProduct:view', '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。查询', @parentId, '1',  '#',  'F', '0', 'module:statementProduct:list',         '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');

insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。新增', @parentId, '2',  '#',  'F', '0', 'module:statementProduct:add',          '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');

insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。修改', @parentId, '3',  '#',  'F', '0', 'module:statementProduct:edit',         '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');

insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。删除', @parentId, '4',  '#',  'F', '0', 'module:statementProduct:remove',       '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');
