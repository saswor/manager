package com.manage.project.module.supplyProduct.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.supplyProduct.mapper.SupplyProductMapper;
import com.manage.project.module.supplyProduct.domain.SupplyProduct;
import com.manage.project.module.supplyProduct.service.ISupplyProductService;
import com.manage.common.support.Convert;

/**
 * 补货商品记录 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class SupplyProductServiceImpl implements ISupplyProductService 
{
	@Autowired
	private SupplyProductMapper supplyProductMapper;

	/**
     * 查询补货商品记录信息
     * 
     * @param logid 补货商品记录ID
     * @return 补货商品记录信息
     */
    @Override
	public SupplyProduct selectSupplyProductById(String logid)
	{
	    return supplyProductMapper.selectSupplyProductById(logid);
	}
	
	/**
     * 查询补货商品记录列表
     * 
     * @param supplyProduct 补货商品记录信息
     * @return 补货商品记录集合
     */
	@Override
	public List<SupplyProduct> selectSupplyProductList(SupplyProduct supplyProduct)
	{
	    return supplyProductMapper.selectSupplyProductList(supplyProduct);
	}
	
    /**
     * 新增补货商品记录
     * 
     * @param supplyProduct 补货商品记录信息
     * @return 结果
     */
	@Override
	public int insertSupplyProduct(SupplyProduct supplyProduct)
	{
	    return supplyProductMapper.insertSupplyProduct(supplyProduct);
	}
	
	/**
     * 修改补货商品记录
     * 
     * @param supplyProduct 补货商品记录信息
     * @return 结果
     */
	@Override
	public int updateSupplyProduct(SupplyProduct supplyProduct)
	{
	    return supplyProductMapper.updateSupplyProduct(supplyProduct);
	}

	/**
     * 删除补货商品记录对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteSupplyProductByIds(String ids)
	{
		return supplyProductMapper.deleteSupplyProductByIds(Convert.toStrArray(ids));
	}
	
}
