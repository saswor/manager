package com.manage.project.module.statementSupply.service;

import com.manage.project.module.statementSupply.domain.StatementSupply;
import java.util.List;

/**
 * 对账补货 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IStatementSupplyService 
{
	/**
     * 查询对账补货信息
     * 
     * @param logid 对账补货ID
     * @return 对账补货信息
     */
	public StatementSupply selectStatementSupplyById(String logid);
	
	/**
     * 查询对账补货列表
     * 
     * @param statementSupply 对账补货信息
     * @return 对账补货集合
     */
	public List<StatementSupply> selectStatementSupplyList(StatementSupply statementSupply);
	
	/**
     * 新增对账补货
     * 
     * @param statementSupply 对账补货信息
     * @return 结果
     */
	public int insertStatementSupply(StatementSupply statementSupply);
	
	/**
     * 修改对账补货
     * 
     * @param statementSupply 对账补货信息
     * @return 结果
     */
	public int updateStatementSupply(StatementSupply statementSupply);
		
	/**
     * 删除对账补货信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteStatementSupplyByIds(String ids);
	
}
