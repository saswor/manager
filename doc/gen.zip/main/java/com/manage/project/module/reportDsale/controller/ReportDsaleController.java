package com.manage.project.module.reportDsale.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.reportDsale.domain.ReportDsale;
import com.manage.project.module.reportDsale.service.IReportDsaleService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/reportDsale")
public class ReportDsaleController extends BaseController
{
    private String prefix = "module/reportDsale";
	
	@Autowired
	private IReportDsaleService reportDsaleService;
	
	@RequiresPermissions("module:reportDsale:view")
	@GetMapping()
	public String reportDsale()
	{
	    return prefix + "/reportDsale";
	}
	
	/**
	 * 查询每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新列表
	 */
	@RequiresPermissions("module:reportDsale:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(ReportDsale reportDsale)
	{
		startPage();
        List<ReportDsale> list = reportDsaleService.selectReportDsaleList(reportDsale);
		return getDataTable(list);
	}
	
	/**
	 * 新增每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新
	 */
	@RequiresPermissions("module:reportDsale:add")
	@Log(title = "每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(ReportDsale reportDsale)
	{		
		return toAjax(reportDsaleService.insertReportDsale(reportDsale));
	}

	/**
	 * 修改每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		ReportDsale reportDsale = reportDsaleService.selectReportDsaleById(logid);
		mmap.put("reportDsale", reportDsale);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新
	 */
	@RequiresPermissions("module:reportDsale:edit")
	@Log(title = "每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(ReportDsale reportDsale)
	{		
		return toAjax(reportDsaleService.updateReportDsale(reportDsale));
	}
	
	/**
	 * 删除每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新
	 */
	@RequiresPermissions("module:reportDsale:remove")
	@Log(title = "每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(reportDsaleService.deleteReportDsaleByIds(ids));
	}
	
}
