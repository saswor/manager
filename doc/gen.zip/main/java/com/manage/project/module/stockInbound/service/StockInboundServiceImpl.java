package com.manage.project.module.stockInbound.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.stockInbound.mapper.StockInboundMapper;
import com.manage.project.module.stockInbound.domain.StockInbound;
import com.manage.project.module.stockInbound.service.IStockInboundService;
import com.manage.common.support.Convert;

/**
 * 仓库入库记录 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class StockInboundServiceImpl implements IStockInboundService 
{
	@Autowired
	private StockInboundMapper stockInboundMapper;

	/**
     * 查询仓库入库记录信息
     * 
     * @param logid 仓库入库记录ID
     * @return 仓库入库记录信息
     */
    @Override
	public StockInbound selectStockInboundById(String logid)
	{
	    return stockInboundMapper.selectStockInboundById(logid);
	}
	
	/**
     * 查询仓库入库记录列表
     * 
     * @param stockInbound 仓库入库记录信息
     * @return 仓库入库记录集合
     */
	@Override
	public List<StockInbound> selectStockInboundList(StockInbound stockInbound)
	{
	    return stockInboundMapper.selectStockInboundList(stockInbound);
	}
	
    /**
     * 新增仓库入库记录
     * 
     * @param stockInbound 仓库入库记录信息
     * @return 结果
     */
	@Override
	public int insertStockInbound(StockInbound stockInbound)
	{
	    return stockInboundMapper.insertStockInbound(stockInbound);
	}
	
	/**
     * 修改仓库入库记录
     * 
     * @param stockInbound 仓库入库记录信息
     * @return 结果
     */
	@Override
	public int updateStockInbound(StockInbound stockInbound)
	{
	    return stockInboundMapper.updateStockInbound(stockInbound);
	}

	/**
     * 删除仓库入库记录对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteStockInboundByIds(String ids)
	{
		return stockInboundMapper.deleteStockInboundByIds(Convert.toStrArray(ids));
	}
	
}
