package com.manage.project.module.reportBoard.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.reportBoard.mapper.ReportBoardMapper;
import com.manage.project.module.reportBoard.domain.ReportBoard;
import com.manage.project.module.reportBoard.service.IReportBoardService;
import com.manage.common.support.Convert;

/**
 * 仪盘概要统计报(即时更新) 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class ReportBoardServiceImpl implements IReportBoardService 
{
	@Autowired
	private ReportBoardMapper reportBoardMapper;

	/**
     * 查询仪盘概要统计报(即时更新)信息
     * 
     * @param logid 仪盘概要统计报(即时更新)ID
     * @return 仪盘概要统计报(即时更新)信息
     */
    @Override
	public ReportBoard selectReportBoardById(String logid)
	{
	    return reportBoardMapper.selectReportBoardById(logid);
	}
	
	/**
     * 查询仪盘概要统计报(即时更新)列表
     * 
     * @param reportBoard 仪盘概要统计报(即时更新)信息
     * @return 仪盘概要统计报(即时更新)集合
     */
	@Override
	public List<ReportBoard> selectReportBoardList(ReportBoard reportBoard)
	{
	    return reportBoardMapper.selectReportBoardList(reportBoard);
	}
	
    /**
     * 新增仪盘概要统计报(即时更新)
     * 
     * @param reportBoard 仪盘概要统计报(即时更新)信息
     * @return 结果
     */
	@Override
	public int insertReportBoard(ReportBoard reportBoard)
	{
	    return reportBoardMapper.insertReportBoard(reportBoard);
	}
	
	/**
     * 修改仪盘概要统计报(即时更新)
     * 
     * @param reportBoard 仪盘概要统计报(即时更新)信息
     * @return 结果
     */
	@Override
	public int updateReportBoard(ReportBoard reportBoard)
	{
	    return reportBoardMapper.updateReportBoard(reportBoard);
	}

	/**
     * 删除仪盘概要统计报(即时更新)对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteReportBoardByIds(String ids)
	{
		return reportBoardMapper.deleteReportBoardByIds(Convert.toStrArray(ids));
	}
	
}
