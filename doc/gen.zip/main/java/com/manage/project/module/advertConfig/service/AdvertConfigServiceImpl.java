package com.manage.project.module.advertConfig.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.advertConfig.mapper.AdvertConfigMapper;
import com.manage.project.module.advertConfig.domain.AdvertConfig;
import com.manage.project.module.advertConfig.service.IAdvertConfigService;
import com.manage.common.support.Convert;

/**
 * 广告配置 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class AdvertConfigServiceImpl implements IAdvertConfigService 
{
	@Autowired
	private AdvertConfigMapper advertConfigMapper;

	/**
     * 查询广告配置信息
     * 
     * @param logid 广告配置ID
     * @return 广告配置信息
     */
    @Override
	public AdvertConfig selectAdvertConfigById(String logid)
	{
	    return advertConfigMapper.selectAdvertConfigById(logid);
	}
	
	/**
     * 查询广告配置列表
     * 
     * @param advertConfig 广告配置信息
     * @return 广告配置集合
     */
	@Override
	public List<AdvertConfig> selectAdvertConfigList(AdvertConfig advertConfig)
	{
	    return advertConfigMapper.selectAdvertConfigList(advertConfig);
	}
	
    /**
     * 新增广告配置
     * 
     * @param advertConfig 广告配置信息
     * @return 结果
     */
	@Override
	public int insertAdvertConfig(AdvertConfig advertConfig)
	{
	    return advertConfigMapper.insertAdvertConfig(advertConfig);
	}
	
	/**
     * 修改广告配置
     * 
     * @param advertConfig 广告配置信息
     * @return 结果
     */
	@Override
	public int updateAdvertConfig(AdvertConfig advertConfig)
	{
	    return advertConfigMapper.updateAdvertConfig(advertConfig);
	}

	/**
     * 删除广告配置对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteAdvertConfigByIds(String ids)
	{
		return advertConfigMapper.deleteAdvertConfigByIds(Convert.toStrArray(ids));
	}
	
}
