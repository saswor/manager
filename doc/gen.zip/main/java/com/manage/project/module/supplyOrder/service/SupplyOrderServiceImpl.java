package com.manage.project.module.supplyOrder.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.supplyOrder.mapper.SupplyOrderMapper;
import com.manage.project.module.supplyOrder.domain.SupplyOrder;
import com.manage.project.module.supplyOrder.service.ISupplyOrderService;
import com.manage.common.support.Convert;

/**
 * 补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class SupplyOrderServiceImpl implements ISupplyOrderService 
{
	@Autowired
	private SupplyOrderMapper supplyOrderMapper;

	/**
     * 查询补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。信息
     * 
     * @param logid 补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。ID
     * @return 补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。信息
     */
    @Override
	public SupplyOrder selectSupplyOrderById(String logid)
	{
	    return supplyOrderMapper.selectSupplyOrderById(logid);
	}
	
	/**
     * 查询补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。列表
     * 
     * @param supplyOrder 补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。信息
     * @return 补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。集合
     */
	@Override
	public List<SupplyOrder> selectSupplyOrderList(SupplyOrder supplyOrder)
	{
	    return supplyOrderMapper.selectSupplyOrderList(supplyOrder);
	}
	
    /**
     * 新增补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。
     * 
     * @param supplyOrder 补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。信息
     * @return 结果
     */
	@Override
	public int insertSupplyOrder(SupplyOrder supplyOrder)
	{
	    return supplyOrderMapper.insertSupplyOrder(supplyOrder);
	}
	
	/**
     * 修改补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。
     * 
     * @param supplyOrder 补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。信息
     * @return 结果
     */
	@Override
	public int updateSupplyOrder(SupplyOrder supplyOrder)
	{
	    return supplyOrderMapper.updateSupplyOrder(supplyOrder);
	}

	/**
     * 删除补货记录，由补货配置自动生成或人工生成，相当于仓库领货清单，必须由仓库管理员审核，填写实际的出库数量。对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteSupplyOrderByIds(String ids)
	{
		return supplyOrderMapper.deleteSupplyOrderByIds(Convert.toStrArray(ids));
	}
	
}
