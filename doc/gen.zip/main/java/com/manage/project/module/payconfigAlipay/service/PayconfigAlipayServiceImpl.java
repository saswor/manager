package com.manage.project.module.payconfigAlipay.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.payconfigAlipay.mapper.PayconfigAlipayMapper;
import com.manage.project.module.payconfigAlipay.domain.PayconfigAlipay;
import com.manage.project.module.payconfigAlipay.service.IPayconfigAlipayService;
import com.manage.common.support.Convert;

/**
 * 微信支付配置 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class PayconfigAlipayServiceImpl implements IPayconfigAlipayService 
{
	@Autowired
	private PayconfigAlipayMapper payconfigAlipayMapper;

	/**
     * 查询微信支付配置信息
     * 
     * @param logid 微信支付配置ID
     * @return 微信支付配置信息
     */
    @Override
	public PayconfigAlipay selectPayconfigAlipayById(String logid)
	{
	    return payconfigAlipayMapper.selectPayconfigAlipayById(logid);
	}
	
	/**
     * 查询微信支付配置列表
     * 
     * @param payconfigAlipay 微信支付配置信息
     * @return 微信支付配置集合
     */
	@Override
	public List<PayconfigAlipay> selectPayconfigAlipayList(PayconfigAlipay payconfigAlipay)
	{
	    return payconfigAlipayMapper.selectPayconfigAlipayList(payconfigAlipay);
	}
	
    /**
     * 新增微信支付配置
     * 
     * @param payconfigAlipay 微信支付配置信息
     * @return 结果
     */
	@Override
	public int insertPayconfigAlipay(PayconfigAlipay payconfigAlipay)
	{
	    return payconfigAlipayMapper.insertPayconfigAlipay(payconfigAlipay);
	}
	
	/**
     * 修改微信支付配置
     * 
     * @param payconfigAlipay 微信支付配置信息
     * @return 结果
     */
	@Override
	public int updatePayconfigAlipay(PayconfigAlipay payconfigAlipay)
	{
	    return payconfigAlipayMapper.updatePayconfigAlipay(payconfigAlipay);
	}

	/**
     * 删除微信支付配置对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deletePayconfigAlipayByIds(String ids)
	{
		return payconfigAlipayMapper.deletePayconfigAlipayByIds(Convert.toStrArray(ids));
	}
	
}
