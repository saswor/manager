package com.manage.project.module.supplyVending.mapper;

import com.manage.project.module.supplyVending.domain.SupplyVending;
import java.util.List;	

/**
 * 补货配置的售货机 数据层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface SupplyVendingMapper 
{
	/**
     * 查询补货配置的售货机信息
     * 
     * @param logid 补货配置的售货机ID
     * @return 补货配置的售货机信息
     */
	public SupplyVending selectSupplyVendingById(String logid);
	
	/**
     * 查询补货配置的售货机列表
     * 
     * @param supplyVending 补货配置的售货机信息
     * @return 补货配置的售货机集合
     */
	public List<SupplyVending> selectSupplyVendingList(SupplyVending supplyVending);
	
	/**
     * 新增补货配置的售货机
     * 
     * @param supplyVending 补货配置的售货机信息
     * @return 结果
     */
	public int insertSupplyVending(SupplyVending supplyVending);
	
	/**
     * 修改补货配置的售货机
     * 
     * @param supplyVending 补货配置的售货机信息
     * @return 结果
     */
	public int updateSupplyVending(SupplyVending supplyVending);
	
	/**
     * 删除补货配置的售货机
     * 
     * @param logid 补货配置的售货机ID
     * @return 结果
     */
	public int deleteSupplyVendingById(String logid);
	
	/**
     * 批量删除补货配置的售货机
     * 
     * @param logids 需要删除的数据ID
     * @return 结果
     */
	public int deleteSupplyVendingByIds(String[] logids);
	
}