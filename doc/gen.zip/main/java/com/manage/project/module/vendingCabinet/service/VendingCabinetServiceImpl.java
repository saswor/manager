package com.manage.project.module.vendingCabinet.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.vendingCabinet.mapper.VendingCabinetMapper;
import com.manage.project.module.vendingCabinet.domain.VendingCabinet;
import com.manage.project.module.vendingCabinet.service.IVendingCabinetService;
import com.manage.common.support.Convert;

/**
 * 售货机挂载的货柜，主柜的挂载副柜 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class VendingCabinetServiceImpl implements IVendingCabinetService 
{
	@Autowired
	private VendingCabinetMapper vendingCabinetMapper;

	/**
     * 查询售货机挂载的货柜，主柜的挂载副柜信息
     * 
     * @param logid 售货机挂载的货柜，主柜的挂载副柜ID
     * @return 售货机挂载的货柜，主柜的挂载副柜信息
     */
    @Override
	public VendingCabinet selectVendingCabinetById(String logid)
	{
	    return vendingCabinetMapper.selectVendingCabinetById(logid);
	}
	
	/**
     * 查询售货机挂载的货柜，主柜的挂载副柜列表
     * 
     * @param vendingCabinet 售货机挂载的货柜，主柜的挂载副柜信息
     * @return 售货机挂载的货柜，主柜的挂载副柜集合
     */
	@Override
	public List<VendingCabinet> selectVendingCabinetList(VendingCabinet vendingCabinet)
	{
	    return vendingCabinetMapper.selectVendingCabinetList(vendingCabinet);
	}
	
    /**
     * 新增售货机挂载的货柜，主柜的挂载副柜
     * 
     * @param vendingCabinet 售货机挂载的货柜，主柜的挂载副柜信息
     * @return 结果
     */
	@Override
	public int insertVendingCabinet(VendingCabinet vendingCabinet)
	{
	    return vendingCabinetMapper.insertVendingCabinet(vendingCabinet);
	}
	
	/**
     * 修改售货机挂载的货柜，主柜的挂载副柜
     * 
     * @param vendingCabinet 售货机挂载的货柜，主柜的挂载副柜信息
     * @return 结果
     */
	@Override
	public int updateVendingCabinet(VendingCabinet vendingCabinet)
	{
	    return vendingCabinetMapper.updateVendingCabinet(vendingCabinet);
	}

	/**
     * 删除售货机挂载的货柜，主柜的挂载副柜对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteVendingCabinetByIds(String ids)
	{
		return vendingCabinetMapper.deleteVendingCabinetByIds(Convert.toStrArray(ids));
	}
	
}
