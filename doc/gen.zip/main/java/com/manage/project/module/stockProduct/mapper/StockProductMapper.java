package com.manage.project.module.stockProduct.mapper;

import com.manage.project.module.stockProduct.domain.StockProduct;
import java.util.List;	

/**
 * 商品库存量 数据层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface StockProductMapper 
{
	/**
     * 查询商品库存量信息
     * 
     * @param logid 商品库存量ID
     * @return 商品库存量信息
     */
	public StockProduct selectStockProductById(String logid);
	
	/**
     * 查询商品库存量列表
     * 
     * @param stockProduct 商品库存量信息
     * @return 商品库存量集合
     */
	public List<StockProduct> selectStockProductList(StockProduct stockProduct);
	
	/**
     * 新增商品库存量
     * 
     * @param stockProduct 商品库存量信息
     * @return 结果
     */
	public int insertStockProduct(StockProduct stockProduct);
	
	/**
     * 修改商品库存量
     * 
     * @param stockProduct 商品库存量信息
     * @return 结果
     */
	public int updateStockProduct(StockProduct stockProduct);
	
	/**
     * 删除商品库存量
     * 
     * @param logid 商品库存量ID
     * @return 结果
     */
	public int deleteStockProductById(String logid);
	
	/**
     * 批量删除商品库存量
     * 
     * @param logids 需要删除的数据ID
     * @return 结果
     */
	public int deleteStockProductByIds(String[] logids);
	
}