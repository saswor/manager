package com.manage.project.module.reportMsale.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.reportMsale.mapper.ReportMsaleMapper;
import com.manage.project.module.reportMsale.domain.ReportMsale;
import com.manage.project.module.reportMsale.service.IReportMsaleService;
import com.manage.common.support.Convert;

/**
 * 仪盘概要统计报 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class ReportMsaleServiceImpl implements IReportMsaleService 
{
	@Autowired
	private ReportMsaleMapper reportMsaleMapper;

	/**
     * 查询仪盘概要统计报信息
     * 
     * @param logid 仪盘概要统计报ID
     * @return 仪盘概要统计报信息
     */
    @Override
	public ReportMsale selectReportMsaleById(String logid)
	{
	    return reportMsaleMapper.selectReportMsaleById(logid);
	}
	
	/**
     * 查询仪盘概要统计报列表
     * 
     * @param reportMsale 仪盘概要统计报信息
     * @return 仪盘概要统计报集合
     */
	@Override
	public List<ReportMsale> selectReportMsaleList(ReportMsale reportMsale)
	{
	    return reportMsaleMapper.selectReportMsaleList(reportMsale);
	}
	
    /**
     * 新增仪盘概要统计报
     * 
     * @param reportMsale 仪盘概要统计报信息
     * @return 结果
     */
	@Override
	public int insertReportMsale(ReportMsale reportMsale)
	{
	    return reportMsaleMapper.insertReportMsale(reportMsale);
	}
	
	/**
     * 修改仪盘概要统计报
     * 
     * @param reportMsale 仪盘概要统计报信息
     * @return 结果
     */
	@Override
	public int updateReportMsale(ReportMsale reportMsale)
	{
	    return reportMsaleMapper.updateReportMsale(reportMsale);
	}

	/**
     * 删除仪盘概要统计报对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteReportMsaleByIds(String ids)
	{
		return reportMsaleMapper.deleteReportMsaleByIds(Convert.toStrArray(ids));
	}
	
}
