package com.manage.project.module.vendingModel.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.vendingModel.mapper.VendingModelMapper;
import com.manage.project.module.vendingModel.domain.VendingModel;
import com.manage.project.module.vendingModel.service.IVendingModelService;
import com.manage.common.support.Convert;

/**
 * 售货机机型管理，包括主柜和副柜机型 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class VendingModelServiceImpl implements IVendingModelService 
{
	@Autowired
	private VendingModelMapper vendingModelMapper;

	/**
     * 查询售货机机型管理，包括主柜和副柜机型信息
     * 
     * @param logid 售货机机型管理，包括主柜和副柜机型ID
     * @return 售货机机型管理，包括主柜和副柜机型信息
     */
    @Override
	public VendingModel selectVendingModelById(String logid)
	{
	    return vendingModelMapper.selectVendingModelById(logid);
	}
	
	/**
     * 查询售货机机型管理，包括主柜和副柜机型列表
     * 
     * @param vendingModel 售货机机型管理，包括主柜和副柜机型信息
     * @return 售货机机型管理，包括主柜和副柜机型集合
     */
	@Override
	public List<VendingModel> selectVendingModelList(VendingModel vendingModel)
	{
	    return vendingModelMapper.selectVendingModelList(vendingModel);
	}
	
    /**
     * 新增售货机机型管理，包括主柜和副柜机型
     * 
     * @param vendingModel 售货机机型管理，包括主柜和副柜机型信息
     * @return 结果
     */
	@Override
	public int insertVendingModel(VendingModel vendingModel)
	{
	    return vendingModelMapper.insertVendingModel(vendingModel);
	}
	
	/**
     * 修改售货机机型管理，包括主柜和副柜机型
     * 
     * @param vendingModel 售货机机型管理，包括主柜和副柜机型信息
     * @return 结果
     */
	@Override
	public int updateVendingModel(VendingModel vendingModel)
	{
	    return vendingModelMapper.updateVendingModel(vendingModel);
	}

	/**
     * 删除售货机机型管理，包括主柜和副柜机型对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteVendingModelByIds(String ids)
	{
		return vendingModelMapper.deleteVendingModelByIds(Convert.toStrArray(ids));
	}
	
}
