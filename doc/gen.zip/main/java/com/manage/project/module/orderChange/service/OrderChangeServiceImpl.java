package com.manage.project.module.orderChange.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.orderChange.mapper.OrderChangeMapper;
import com.manage.project.module.orderChange.domain.OrderChange;
import com.manage.project.module.orderChange.service.IOrderChangeService;
import com.manage.common.support.Convert;

/**
 * 订单状态 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class OrderChangeServiceImpl implements IOrderChangeService 
{
	@Autowired
	private OrderChangeMapper orderChangeMapper;

	/**
     * 查询订单状态信息
     * 
     * @param logid 订单状态ID
     * @return 订单状态信息
     */
    @Override
	public OrderChange selectOrderChangeById(String logid)
	{
	    return orderChangeMapper.selectOrderChangeById(logid);
	}
	
	/**
     * 查询订单状态列表
     * 
     * @param orderChange 订单状态信息
     * @return 订单状态集合
     */
	@Override
	public List<OrderChange> selectOrderChangeList(OrderChange orderChange)
	{
	    return orderChangeMapper.selectOrderChangeList(orderChange);
	}
	
    /**
     * 新增订单状态
     * 
     * @param orderChange 订单状态信息
     * @return 结果
     */
	@Override
	public int insertOrderChange(OrderChange orderChange)
	{
	    return orderChangeMapper.insertOrderChange(orderChange);
	}
	
	/**
     * 修改订单状态
     * 
     * @param orderChange 订单状态信息
     * @return 结果
     */
	@Override
	public int updateOrderChange(OrderChange orderChange)
	{
	    return orderChangeMapper.updateOrderChange(orderChange);
	}

	/**
     * 删除订单状态对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteOrderChangeByIds(String ids)
	{
		return orderChangeMapper.deleteOrderChangeByIds(Convert.toStrArray(ids));
	}
	
}
