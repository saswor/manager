package com.manage.project.module.stockPinbound.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 仓库采购记录表 as_stock_pinbound
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class StockPinbound extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 仓库入库商品记录编号 */
	private String wPInboundId;
	/** 仓库入库记录编号 */
	private String wInboundId;
	/** 仓库编号 */
	private String stockId;
	/** 仓库名称 */
	private String stokcName;
	/** 商品编号 */
	private String productId;
	/** 商品名称 */
	private String productName;
	/** 供应商编号 */
	private String supplierId;
	/** 入库数量 */
	private Integer pNum;
	/** 入库采购单价 */
	private Float buyPrice;
	/** 入库采购总价 */
	private Float totalPrice;
	/** 托管公司编号 */
	private String corpId;
	/** 创建时间 */
	private String createTime;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setWPInboundId(String wPInboundId) 
	{
		this.wPInboundId = wPInboundId;
	}

	public String getWPInboundId() 
	{
		return wPInboundId;
	}
	public void setWInboundId(String wInboundId) 
	{
		this.wInboundId = wInboundId;
	}

	public String getWInboundId() 
	{
		return wInboundId;
	}
	public void setStockId(String stockId) 
	{
		this.stockId = stockId;
	}

	public String getStockId() 
	{
		return stockId;
	}
	public void setStokcName(String stokcName) 
	{
		this.stokcName = stokcName;
	}

	public String getStokcName() 
	{
		return stokcName;
	}
	public void setProductId(String productId) 
	{
		this.productId = productId;
	}

	public String getProductId() 
	{
		return productId;
	}
	public void setProductName(String productName) 
	{
		this.productName = productName;
	}

	public String getProductName() 
	{
		return productName;
	}
	public void setSupplierId(String supplierId) 
	{
		this.supplierId = supplierId;
	}

	public String getSupplierId() 
	{
		return supplierId;
	}
	public void setPNum(Integer pNum) 
	{
		this.pNum = pNum;
	}

	public Integer getPNum() 
	{
		return pNum;
	}
	public void setBuyPrice(Float buyPrice) 
	{
		this.buyPrice = buyPrice;
	}

	public Float getBuyPrice() 
	{
		return buyPrice;
	}
	public void setTotalPrice(Float totalPrice) 
	{
		this.totalPrice = totalPrice;
	}

	public Float getTotalPrice() 
	{
		return totalPrice;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("wPInboundId", getWPInboundId())
            .append("wInboundId", getWInboundId())
            .append("stockId", getStockId())
            .append("stokcName", getStokcName())
            .append("productId", getProductId())
            .append("productName", getProductName())
            .append("supplierId", getSupplierId())
            .append("pNum", getPNum())
            .append("buyPrice", getBuyPrice())
            .append("totalPrice", getTotalPrice())
            .append("corpId", getCorpId())
            .append("createTime", getCreateTime())
            .toString();
    }
}
