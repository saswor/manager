package com.manage.project.module.corp.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.corp.mapper.CorpMapper;
import com.manage.project.module.corp.domain.Corp;
import com.manage.project.module.corp.service.ICorpService;
import com.manage.common.support.Convert;

/**
 * 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class CorpServiceImpl implements ICorpService 
{
	@Autowired
	private CorpMapper corpMapper;

	/**
     * 查询商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。信息
     * 
     * @param logid 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。ID
     * @return 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。信息
     */
    @Override
	public Corp selectCorpById(String logid)
	{
	    return corpMapper.selectCorpById(logid);
	}
	
	/**
     * 查询商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。列表
     * 
     * @param corp 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。信息
     * @return 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。集合
     */
	@Override
	public List<Corp> selectCorpList(Corp corp)
	{
	    return corpMapper.selectCorpList(corp);
	}
	
    /**
     * 新增商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。
     * 
     * @param corp 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。信息
     * @return 结果
     */
	@Override
	public int insertCorp(Corp corp)
	{
	    return corpMapper.insertCorp(corp);
	}
	
	/**
     * 修改商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。
     * 
     * @param corp 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。信息
     * @return 结果
     */
	@Override
	public int updateCorp(Corp corp)
	{
	    return corpMapper.updateCorp(corp);
	}

	/**
     * 删除商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteCorpByIds(String ids)
	{
		return corpMapper.deleteCorpByIds(Convert.toStrArray(ids));
	}
	
}
