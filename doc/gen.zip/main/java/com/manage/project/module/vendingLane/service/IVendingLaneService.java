package com.manage.project.module.vendingLane.service;

import com.manage.project.module.vendingLane.domain.VendingLane;
import java.util.List;

/**
 * 售货机货道 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IVendingLaneService 
{
	/**
     * 查询售货机货道信息
     * 
     * @param logid 售货机货道ID
     * @return 售货机货道信息
     */
	public VendingLane selectVendingLaneById(String logid);
	
	/**
     * 查询售货机货道列表
     * 
     * @param vendingLane 售货机货道信息
     * @return 售货机货道集合
     */
	public List<VendingLane> selectVendingLaneList(VendingLane vendingLane);
	
	/**
     * 新增售货机货道
     * 
     * @param vendingLane 售货机货道信息
     * @return 结果
     */
	public int insertVendingLane(VendingLane vendingLane);
	
	/**
     * 修改售货机货道
     * 
     * @param vendingLane 售货机货道信息
     * @return 结果
     */
	public int updateVendingLane(VendingLane vendingLane);
		
	/**
     * 删除售货机货道信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteVendingLaneByIds(String ids);
	
}
