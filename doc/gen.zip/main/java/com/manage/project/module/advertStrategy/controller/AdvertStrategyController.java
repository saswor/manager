package com.manage.project.module.advertStrategy.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.advertStrategy.domain.AdvertStrategy;
import com.manage.project.module.advertStrategy.service.IAdvertStrategyService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 广告配置 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/advertStrategy")
public class AdvertStrategyController extends BaseController
{
    private String prefix = "module/advertStrategy";
	
	@Autowired
	private IAdvertStrategyService advertStrategyService;
	
	@RequiresPermissions("module:advertStrategy:view")
	@GetMapping()
	public String advertStrategy()
	{
	    return prefix + "/advertStrategy";
	}
	
	/**
	 * 查询广告配置列表
	 */
	@RequiresPermissions("module:advertStrategy:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(AdvertStrategy advertStrategy)
	{
		startPage();
        List<AdvertStrategy> list = advertStrategyService.selectAdvertStrategyList(advertStrategy);
		return getDataTable(list);
	}
	
	/**
	 * 新增广告配置
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存广告配置
	 */
	@RequiresPermissions("module:advertStrategy:add")
	@Log(title = "广告配置", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(AdvertStrategy advertStrategy)
	{		
		return toAjax(advertStrategyService.insertAdvertStrategy(advertStrategy));
	}

	/**
	 * 修改广告配置
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		AdvertStrategy advertStrategy = advertStrategyService.selectAdvertStrategyById(logid);
		mmap.put("advertStrategy", advertStrategy);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存广告配置
	 */
	@RequiresPermissions("module:advertStrategy:edit")
	@Log(title = "广告配置", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(AdvertStrategy advertStrategy)
	{		
		return toAjax(advertStrategyService.updateAdvertStrategy(advertStrategy));
	}
	
	/**
	 * 删除广告配置
	 */
	@RequiresPermissions("module:advertStrategy:remove")
	@Log(title = "广告配置", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(advertStrategyService.deleteAdvertStrategyByIds(ids));
	}
	
}
