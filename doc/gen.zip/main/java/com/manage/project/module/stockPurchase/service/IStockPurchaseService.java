package com.manage.project.module.stockPurchase.service;

import com.manage.project.module.stockPurchase.domain.StockPurchase;
import java.util.List;

/**
 * 仓库采购记录 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IStockPurchaseService 
{
	/**
     * 查询仓库采购记录信息
     * 
     * @param logid 仓库采购记录ID
     * @return 仓库采购记录信息
     */
	public StockPurchase selectStockPurchaseById(String logid);
	
	/**
     * 查询仓库采购记录列表
     * 
     * @param stockPurchase 仓库采购记录信息
     * @return 仓库采购记录集合
     */
	public List<StockPurchase> selectStockPurchaseList(StockPurchase stockPurchase);
	
	/**
     * 新增仓库采购记录
     * 
     * @param stockPurchase 仓库采购记录信息
     * @return 结果
     */
	public int insertStockPurchase(StockPurchase stockPurchase);
	
	/**
     * 修改仓库采购记录
     * 
     * @param stockPurchase 仓库采购记录信息
     * @return 结果
     */
	public int updateStockPurchase(StockPurchase stockPurchase);
		
	/**
     * 删除仓库采购记录信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteStockPurchaseByIds(String ids);
	
}
