package com.manage.project.module.corp.mapper;

import com.manage.project.module.corp.domain.Corp;
import java.util.List;	

/**
 * 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。 数据层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface CorpMapper 
{
	/**
     * 查询商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。信息
     * 
     * @param logid 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。ID
     * @return 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。信息
     */
	public Corp selectCorpById(String logid);
	
	/**
     * 查询商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。列表
     * 
     * @param corp 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。信息
     * @return 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。集合
     */
	public List<Corp> selectCorpList(Corp corp);
	
	/**
     * 新增商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。
     * 
     * @param corp 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。信息
     * @return 结果
     */
	public int insertCorp(Corp corp);
	
	/**
     * 修改商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。
     * 
     * @param corp 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。信息
     * @return 结果
     */
	public int updateCorp(Corp corp);
	
	/**
     * 删除商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。
     * 
     * @param logid 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。ID
     * @return 结果
     */
	public int deleteCorpById(String logid);
	
	/**
     * 批量删除商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。
     * 
     * @param logids 需要删除的数据ID
     * @return 结果
     */
	public int deleteCorpByIds(String[] logids);
	
}