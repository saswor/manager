package com.manage.project.module.vendingEvent.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.vendingEvent.domain.VendingEvent;
import com.manage.project.module.vendingEvent.service.IVendingEventService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 售货机的事件列 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/vendingEvent")
public class VendingEventController extends BaseController
{
    private String prefix = "module/vendingEvent";
	
	@Autowired
	private IVendingEventService vendingEventService;
	
	@RequiresPermissions("module:vendingEvent:view")
	@GetMapping()
	public String vendingEvent()
	{
	    return prefix + "/vendingEvent";
	}
	
	/**
	 * 查询售货机的事件列列表
	 */
	@RequiresPermissions("module:vendingEvent:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(VendingEvent vendingEvent)
	{
		startPage();
        List<VendingEvent> list = vendingEventService.selectVendingEventList(vendingEvent);
		return getDataTable(list);
	}
	
	/**
	 * 新增售货机的事件列
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存售货机的事件列
	 */
	@RequiresPermissions("module:vendingEvent:add")
	@Log(title = "售货机的事件列", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(VendingEvent vendingEvent)
	{		
		return toAjax(vendingEventService.insertVendingEvent(vendingEvent));
	}

	/**
	 * 修改售货机的事件列
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		VendingEvent vendingEvent = vendingEventService.selectVendingEventById(logid);
		mmap.put("vendingEvent", vendingEvent);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存售货机的事件列
	 */
	@RequiresPermissions("module:vendingEvent:edit")
	@Log(title = "售货机的事件列", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(VendingEvent vendingEvent)
	{		
		return toAjax(vendingEventService.updateVendingEvent(vendingEvent));
	}
	
	/**
	 * 删除售货机的事件列
	 */
	@RequiresPermissions("module:vendingEvent:remove")
	@Log(title = "售货机的事件列", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(vendingEventService.deleteVendingEventByIds(ids));
	}
	
}
