package com.manage.project.module.stockProduct.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.stockProduct.domain.StockProduct;
import com.manage.project.module.stockProduct.service.IStockProductService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 商品库存量 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/stockProduct")
public class StockProductController extends BaseController
{
    private String prefix = "module/stockProduct";
	
	@Autowired
	private IStockProductService stockProductService;
	
	@RequiresPermissions("module:stockProduct:view")
	@GetMapping()
	public String stockProduct()
	{
	    return prefix + "/stockProduct";
	}
	
	/**
	 * 查询商品库存量列表
	 */
	@RequiresPermissions("module:stockProduct:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(StockProduct stockProduct)
	{
		startPage();
        List<StockProduct> list = stockProductService.selectStockProductList(stockProduct);
		return getDataTable(list);
	}
	
	/**
	 * 新增商品库存量
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存商品库存量
	 */
	@RequiresPermissions("module:stockProduct:add")
	@Log(title = "商品库存量", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(StockProduct stockProduct)
	{		
		return toAjax(stockProductService.insertStockProduct(stockProduct));
	}

	/**
	 * 修改商品库存量
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		StockProduct stockProduct = stockProductService.selectStockProductById(logid);
		mmap.put("stockProduct", stockProduct);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存商品库存量
	 */
	@RequiresPermissions("module:stockProduct:edit")
	@Log(title = "商品库存量", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(StockProduct stockProduct)
	{		
		return toAjax(stockProductService.updateStockProduct(stockProduct));
	}
	
	/**
	 * 删除商品库存量
	 */
	@RequiresPermissions("module:stockProduct:remove")
	@Log(title = "商品库存量", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(stockProductService.deleteStockProductByIds(ids));
	}
	
}
