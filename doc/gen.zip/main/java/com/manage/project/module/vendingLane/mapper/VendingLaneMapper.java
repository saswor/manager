package com.manage.project.module.vendingLane.mapper;

import com.manage.project.module.vendingLane.domain.VendingLane;
import java.util.List;	

/**
 * 售货机货道 数据层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface VendingLaneMapper 
{
	/**
     * 查询售货机货道信息
     * 
     * @param logid 售货机货道ID
     * @return 售货机货道信息
     */
	public VendingLane selectVendingLaneById(String logid);
	
	/**
     * 查询售货机货道列表
     * 
     * @param vendingLane 售货机货道信息
     * @return 售货机货道集合
     */
	public List<VendingLane> selectVendingLaneList(VendingLane vendingLane);
	
	/**
     * 新增售货机货道
     * 
     * @param vendingLane 售货机货道信息
     * @return 结果
     */
	public int insertVendingLane(VendingLane vendingLane);
	
	/**
     * 修改售货机货道
     * 
     * @param vendingLane 售货机货道信息
     * @return 结果
     */
	public int updateVendingLane(VendingLane vendingLane);
	
	/**
     * 删除售货机货道
     * 
     * @param logid 售货机货道ID
     * @return 结果
     */
	public int deleteVendingLaneById(String logid);
	
	/**
     * 批量删除售货机货道
     * 
     * @param logids 需要删除的数据ID
     * @return 结果
     */
	public int deleteVendingLaneByIds(String[] logids);
	
}