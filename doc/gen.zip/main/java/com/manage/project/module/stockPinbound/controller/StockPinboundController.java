package com.manage.project.module.stockPinbound.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.stockPinbound.domain.StockPinbound;
import com.manage.project.module.stockPinbound.service.IStockPinboundService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 仓库采购记录 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/stockPinbound")
public class StockPinboundController extends BaseController
{
    private String prefix = "module/stockPinbound";
	
	@Autowired
	private IStockPinboundService stockPinboundService;
	
	@RequiresPermissions("module:stockPinbound:view")
	@GetMapping()
	public String stockPinbound()
	{
	    return prefix + "/stockPinbound";
	}
	
	/**
	 * 查询仓库采购记录列表
	 */
	@RequiresPermissions("module:stockPinbound:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(StockPinbound stockPinbound)
	{
		startPage();
        List<StockPinbound> list = stockPinboundService.selectStockPinboundList(stockPinbound);
		return getDataTable(list);
	}
	
	/**
	 * 新增仓库采购记录
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存仓库采购记录
	 */
	@RequiresPermissions("module:stockPinbound:add")
	@Log(title = "仓库采购记录", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(StockPinbound stockPinbound)
	{		
		return toAjax(stockPinboundService.insertStockPinbound(stockPinbound));
	}

	/**
	 * 修改仓库采购记录
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		StockPinbound stockPinbound = stockPinboundService.selectStockPinboundById(logid);
		mmap.put("stockPinbound", stockPinbound);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存仓库采购记录
	 */
	@RequiresPermissions("module:stockPinbound:edit")
	@Log(title = "仓库采购记录", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(StockPinbound stockPinbound)
	{		
		return toAjax(stockPinboundService.updateStockPinbound(stockPinbound));
	}
	
	/**
	 * 删除仓库采购记录
	 */
	@RequiresPermissions("module:stockPinbound:remove")
	@Log(title = "仓库采购记录", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(stockPinboundService.deleteStockPinboundByIds(ids));
	}
	
}
