package com.manage.project.module.orderChange.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 订单状态表 as_order_change
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class OrderChange extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 编号 */
	private String changeId;
	/** 公司编号 */
	private String corpId;
	/** 智莱订单编号 */
	private String orderId;
	/** 操作人编号 */
	private String operId;
	/** 操作人名称 */
	private String operName;
	/** 地点编号 */
	private String siteId;
	/** 地点名称 */
	private String siteName;
	/** 当前状态 01:申请 02:支付成功03:支付失败 04:提前取货 05:客户已取货  05:客户取消 06:出货故障 07:已回收08:退款 09:完结 */
	private String operAction;
	/** 操作时间 */
	private String operTime;
	/** 操作内容 */
	private String operCont;
	/** 创建时间 */
	private String createTime;
	/** 推送状态 1:等待推送 2:已推送 3:推送失败 */
	private String pocState;
	/** 推送错误次数 */
	private Integer pocTimes;
	/** 推送结果 success或错误信息 */
	private String pocResult;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setChangeId(String changeId) 
	{
		this.changeId = changeId;
	}

	public String getChangeId() 
	{
		return changeId;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setOrderId(String orderId) 
	{
		this.orderId = orderId;
	}

	public String getOrderId() 
	{
		return orderId;
	}
	public void setOperId(String operId) 
	{
		this.operId = operId;
	}

	public String getOperId() 
	{
		return operId;
	}
	public void setOperName(String operName) 
	{
		this.operName = operName;
	}

	public String getOperName() 
	{
		return operName;
	}
	public void setSiteId(String siteId) 
	{
		this.siteId = siteId;
	}

	public String getSiteId() 
	{
		return siteId;
	}
	public void setSiteName(String siteName) 
	{
		this.siteName = siteName;
	}

	public String getSiteName() 
	{
		return siteName;
	}
	public void setOperAction(String operAction) 
	{
		this.operAction = operAction;
	}

	public String getOperAction() 
	{
		return operAction;
	}
	public void setOperTime(String operTime) 
	{
		this.operTime = operTime;
	}

	public String getOperTime() 
	{
		return operTime;
	}
	public void setOperCont(String operCont) 
	{
		this.operCont = operCont;
	}

	public String getOperCont() 
	{
		return operCont;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}
	public void setPocState(String pocState) 
	{
		this.pocState = pocState;
	}

	public String getPocState() 
	{
		return pocState;
	}
	public void setPocTimes(Integer pocTimes) 
	{
		this.pocTimes = pocTimes;
	}

	public Integer getPocTimes() 
	{
		return pocTimes;
	}
	public void setPocResult(String pocResult) 
	{
		this.pocResult = pocResult;
	}

	public String getPocResult() 
	{
		return pocResult;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("changeId", getChangeId())
            .append("corpId", getCorpId())
            .append("orderId", getOrderId())
            .append("operId", getOperId())
            .append("operName", getOperName())
            .append("siteId", getSiteId())
            .append("siteName", getSiteName())
            .append("operAction", getOperAction())
            .append("operTime", getOperTime())
            .append("operCont", getOperCont())
            .append("createTime", getCreateTime())
            .append("pocState", getPocState())
            .append("pocTimes", getPocTimes())
            .append("pocResult", getPocResult())
            .toString();
    }
}
