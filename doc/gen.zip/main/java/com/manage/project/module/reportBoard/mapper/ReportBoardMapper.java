package com.manage.project.module.reportBoard.mapper;

import com.manage.project.module.reportBoard.domain.ReportBoard;
import java.util.List;	

/**
 * 仪盘概要统计报(即时更新) 数据层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface ReportBoardMapper 
{
	/**
     * 查询仪盘概要统计报(即时更新)信息
     * 
     * @param logid 仪盘概要统计报(即时更新)ID
     * @return 仪盘概要统计报(即时更新)信息
     */
	public ReportBoard selectReportBoardById(String logid);
	
	/**
     * 查询仪盘概要统计报(即时更新)列表
     * 
     * @param reportBoard 仪盘概要统计报(即时更新)信息
     * @return 仪盘概要统计报(即时更新)集合
     */
	public List<ReportBoard> selectReportBoardList(ReportBoard reportBoard);
	
	/**
     * 新增仪盘概要统计报(即时更新)
     * 
     * @param reportBoard 仪盘概要统计报(即时更新)信息
     * @return 结果
     */
	public int insertReportBoard(ReportBoard reportBoard);
	
	/**
     * 修改仪盘概要统计报(即时更新)
     * 
     * @param reportBoard 仪盘概要统计报(即时更新)信息
     * @return 结果
     */
	public int updateReportBoard(ReportBoard reportBoard);
	
	/**
     * 删除仪盘概要统计报(即时更新)
     * 
     * @param logid 仪盘概要统计报(即时更新)ID
     * @return 结果
     */
	public int deleteReportBoardById(String logid);
	
	/**
     * 批量删除仪盘概要统计报(即时更新)
     * 
     * @param logids 需要删除的数据ID
     * @return 结果
     */
	public int deleteReportBoardByIds(String[] logids);
	
}