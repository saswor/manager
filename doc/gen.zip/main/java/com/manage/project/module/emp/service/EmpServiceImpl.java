package com.manage.project.module.emp.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.emp.mapper.EmpMapper;
import com.manage.project.module.emp.domain.Emp;
import com.manage.project.module.emp.service.IEmpService;
import com.manage.common.support.Convert;

/**
 * 系统人员管理 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class EmpServiceImpl implements IEmpService 
{
	@Autowired
	private EmpMapper empMapper;

	/**
     * 查询系统人员管理信息
     * 
     * @param logid 系统人员管理ID
     * @return 系统人员管理信息
     */
    @Override
	public Emp selectEmpById(String logid)
	{
	    return empMapper.selectEmpById(logid);
	}
	
	/**
     * 查询系统人员管理列表
     * 
     * @param emp 系统人员管理信息
     * @return 系统人员管理集合
     */
	@Override
	public List<Emp> selectEmpList(Emp emp)
	{
	    return empMapper.selectEmpList(emp);
	}
	
    /**
     * 新增系统人员管理
     * 
     * @param emp 系统人员管理信息
     * @return 结果
     */
	@Override
	public int insertEmp(Emp emp)
	{
	    return empMapper.insertEmp(emp);
	}
	
	/**
     * 修改系统人员管理
     * 
     * @param emp 系统人员管理信息
     * @return 结果
     */
	@Override
	public int updateEmp(Emp emp)
	{
	    return empMapper.updateEmp(emp);
	}

	/**
     * 删除系统人员管理对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteEmpByIds(String ids)
	{
		return empMapper.deleteEmpByIds(Convert.toStrArray(ids));
	}
	
}
