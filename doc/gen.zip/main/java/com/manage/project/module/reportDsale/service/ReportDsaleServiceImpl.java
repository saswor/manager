package com.manage.project.module.reportDsale.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.reportDsale.mapper.ReportDsaleMapper;
import com.manage.project.module.reportDsale.domain.ReportDsale;
import com.manage.project.module.reportDsale.service.IReportDsaleService;
import com.manage.common.support.Convert;

/**
 * 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class ReportDsaleServiceImpl implements IReportDsaleService 
{
	@Autowired
	private ReportDsaleMapper reportDsaleMapper;

	/**
     * 查询每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新信息
     * 
     * @param logid 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新ID
     * @return 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新信息
     */
    @Override
	public ReportDsale selectReportDsaleById(String logid)
	{
	    return reportDsaleMapper.selectReportDsaleById(logid);
	}
	
	/**
     * 查询每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新列表
     * 
     * @param reportDsale 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新信息
     * @return 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新集合
     */
	@Override
	public List<ReportDsale> selectReportDsaleList(ReportDsale reportDsale)
	{
	    return reportDsaleMapper.selectReportDsaleList(reportDsale);
	}
	
    /**
     * 新增每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新
     * 
     * @param reportDsale 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新信息
     * @return 结果
     */
	@Override
	public int insertReportDsale(ReportDsale reportDsale)
	{
	    return reportDsaleMapper.insertReportDsale(reportDsale);
	}
	
	/**
     * 修改每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新
     * 
     * @param reportDsale 每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新信息
     * @return 结果
     */
	@Override
	public int updateReportDsale(ReportDsale reportDsale)
	{
	    return reportDsaleMapper.updateReportDsale(reportDsale);
	}

	/**
     * 删除每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteReportDsaleByIds(String ids)
	{
		return reportDsaleMapper.deleteReportDsaleByIds(Convert.toStrArray(ids));
	}
	
}
