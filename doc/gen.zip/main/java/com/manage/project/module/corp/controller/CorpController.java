package com.manage.project.module.corp.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.corp.domain.Corp;
import com.manage.project.module.corp.service.ICorpService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/corp")
public class CorpController extends BaseController
{
    private String prefix = "module/corp";
	
	@Autowired
	private ICorpService corpService;
	
	@RequiresPermissions("module:corp:view")
	@GetMapping()
	public String corp()
	{
	    return prefix + "/corp";
	}
	
	/**
	 * 查询商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。列表
	 */
	@RequiresPermissions("module:corp:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(Corp corp)
	{
		startPage();
        List<Corp> list = corpService.selectCorpList(corp);
		return getDataTable(list);
	}
	
	/**
	 * 新增商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。
	 */
	@RequiresPermissions("module:corp:add")
	@Log(title = "商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(Corp corp)
	{		
		return toAjax(corpService.insertCorp(corp));
	}

	/**
	 * 修改商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		Corp corp = corpService.selectCorpById(logid);
		mmap.put("corp", corp);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。
	 */
	@RequiresPermissions("module:corp:edit")
	@Log(title = "商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(Corp corp)
	{		
		return toAjax(corpService.updateCorp(corp));
	}
	
	/**
	 * 删除商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。
	 */
	@RequiresPermissions("module:corp:remove")
	@Log(title = "商户(托管公司，售货机平台可以托管客户从智莱购买的柜子设备)。", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(corpService.deleteCorpByIds(ids));
	}
	
}
