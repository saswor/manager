package com.manage.project.module.productClassify.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.productClassify.mapper.ProductClassifyMapper;
import com.manage.project.module.productClassify.domain.ProductClassify;
import com.manage.project.module.productClassify.service.IProductClassifyService;
import com.manage.common.support.Convert;

/**
 * 商品分类 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class ProductClassifyServiceImpl implements IProductClassifyService 
{
	@Autowired
	private ProductClassifyMapper productClassifyMapper;

	/**
     * 查询商品分类信息
     * 
     * @param logid 商品分类ID
     * @return 商品分类信息
     */
    @Override
	public ProductClassify selectProductClassifyById(String logid)
	{
	    return productClassifyMapper.selectProductClassifyById(logid);
	}
	
	/**
     * 查询商品分类列表
     * 
     * @param productClassify 商品分类信息
     * @return 商品分类集合
     */
	@Override
	public List<ProductClassify> selectProductClassifyList(ProductClassify productClassify)
	{
	    return productClassifyMapper.selectProductClassifyList(productClassify);
	}
	
    /**
     * 新增商品分类
     * 
     * @param productClassify 商品分类信息
     * @return 结果
     */
	@Override
	public int insertProductClassify(ProductClassify productClassify)
	{
	    return productClassifyMapper.insertProductClassify(productClassify);
	}
	
	/**
     * 修改商品分类
     * 
     * @param productClassify 商品分类信息
     * @return 结果
     */
	@Override
	public int updateProductClassify(ProductClassify productClassify)
	{
	    return productClassifyMapper.updateProductClassify(productClassify);
	}

	/**
     * 删除商品分类对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteProductClassifyByIds(String ids)
	{
		return productClassifyMapper.deleteProductClassifyByIds(Convert.toStrArray(ids));
	}
	
}
