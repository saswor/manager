package com.manage.project.module.favourableObject.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.favourableObject.mapper.FavourableObjectMapper;
import com.manage.project.module.favourableObject.domain.FavourableObject;
import com.manage.project.module.favourableObject.service.IFavourableObjectService;
import com.manage.common.support.Convert;

/**
 * 优惠对象列，在下单的时候可通过此方便查询优惠对象的优惠，需根据《优惠 3.2.4.1》和《优惠时间段3.2.4.2》定时更新此，此保存对象的最新优惠。根据优惠时间段更新此最新优惠 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class FavourableObjectServiceImpl implements IFavourableObjectService 
{
	@Autowired
	private FavourableObjectMapper favourableObjectMapper;

	/**
     * 查询优惠对象列，在下单的时候可通过此方便查询优惠对象的优惠，需根据《优惠 3.2.4.1》和《优惠时间段3.2.4.2》定时更新此，此保存对象的最新优惠。根据优惠时间段更新此最新优惠信息
     * 
     * @param logid 优惠对象列，在下单的时候可通过此方便查询优惠对象的优惠，需根据《优惠 3.2.4.1》和《优惠时间段3.2.4.2》定时更新此，此保存对象的最新优惠。根据优惠时间段更新此最新优惠ID
     * @return 优惠对象列，在下单的时候可通过此方便查询优惠对象的优惠，需根据《优惠 3.2.4.1》和《优惠时间段3.2.4.2》定时更新此，此保存对象的最新优惠。根据优惠时间段更新此最新优惠信息
     */
    @Override
	public FavourableObject selectFavourableObjectById(String logid)
	{
	    return favourableObjectMapper.selectFavourableObjectById(logid);
	}
	
	/**
     * 查询优惠对象列，在下单的时候可通过此方便查询优惠对象的优惠，需根据《优惠 3.2.4.1》和《优惠时间段3.2.4.2》定时更新此，此保存对象的最新优惠。根据优惠时间段更新此最新优惠列表
     * 
     * @param favourableObject 优惠对象列，在下单的时候可通过此方便查询优惠对象的优惠，需根据《优惠 3.2.4.1》和《优惠时间段3.2.4.2》定时更新此，此保存对象的最新优惠。根据优惠时间段更新此最新优惠信息
     * @return 优惠对象列，在下单的时候可通过此方便查询优惠对象的优惠，需根据《优惠 3.2.4.1》和《优惠时间段3.2.4.2》定时更新此，此保存对象的最新优惠。根据优惠时间段更新此最新优惠集合
     */
	@Override
	public List<FavourableObject> selectFavourableObjectList(FavourableObject favourableObject)
	{
	    return favourableObjectMapper.selectFavourableObjectList(favourableObject);
	}
	
    /**
     * 新增优惠对象列，在下单的时候可通过此方便查询优惠对象的优惠，需根据《优惠 3.2.4.1》和《优惠时间段3.2.4.2》定时更新此，此保存对象的最新优惠。根据优惠时间段更新此最新优惠
     * 
     * @param favourableObject 优惠对象列，在下单的时候可通过此方便查询优惠对象的优惠，需根据《优惠 3.2.4.1》和《优惠时间段3.2.4.2》定时更新此，此保存对象的最新优惠。根据优惠时间段更新此最新优惠信息
     * @return 结果
     */
	@Override
	public int insertFavourableObject(FavourableObject favourableObject)
	{
	    return favourableObjectMapper.insertFavourableObject(favourableObject);
	}
	
	/**
     * 修改优惠对象列，在下单的时候可通过此方便查询优惠对象的优惠，需根据《优惠 3.2.4.1》和《优惠时间段3.2.4.2》定时更新此，此保存对象的最新优惠。根据优惠时间段更新此最新优惠
     * 
     * @param favourableObject 优惠对象列，在下单的时候可通过此方便查询优惠对象的优惠，需根据《优惠 3.2.4.1》和《优惠时间段3.2.4.2》定时更新此，此保存对象的最新优惠。根据优惠时间段更新此最新优惠信息
     * @return 结果
     */
	@Override
	public int updateFavourableObject(FavourableObject favourableObject)
	{
	    return favourableObjectMapper.updateFavourableObject(favourableObject);
	}

	/**
     * 删除优惠对象列，在下单的时候可通过此方便查询优惠对象的优惠，需根据《优惠 3.2.4.1》和《优惠时间段3.2.4.2》定时更新此，此保存对象的最新优惠。根据优惠时间段更新此最新优惠对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteFavourableObjectByIds(String ids)
	{
		return favourableObjectMapper.deleteFavourableObjectByIds(Convert.toStrArray(ids));
	}
	
}
