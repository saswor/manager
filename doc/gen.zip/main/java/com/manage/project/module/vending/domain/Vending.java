package com.manage.project.module.vending.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 售货机的基本，主柜表 as_vending
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class Vending extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 售货机编号 */
	private String siteId;
	/** 售货机编码 */
	private String siteCode;
	/** 售货机名称 */
	private String siteName;
	/** 厂家编号 */
	private String factoryId;
	/** 货柜类型 01:商店机 02:弹簧机 03:格子机 */
	private String cabinetType;
	/** 机型编码 */
	private String deviceId;
	/** 区域编号 */
	private String districtId;
	/** 线路编号 */
	private String lineId;
	/** 点位编号 */
	private String pointId;
	/** 经度 */
	private String longitude;
	/** 维度 */
	private String latitude;
	/** 支付类型 可多选从左到右每一位代表支持一种。(1支付宝 2:微信 3:百度钱包 ) */
	private String payType;
	/** 播放视频 1:支持 2:无 */
	private String mediaType;
	/** 上线日期 */
	private String onlineTime;
	/** 初始化时间 */
	private String initTime;
	/** 售货机状态 1:已认证售货机 2:未认证售货机 3:已删除售货机 */
	private String curState;
	/** 状态时间 */
	private String stateTime;
	/** 网络制式 1:GPRS  2:网口 */
	private String netWork;
	/** 网络状态(0:在线 1:离线) */
	private String netSate;
	/** 网络状态时间(刷新时间/离线时间) */
	private String netTime;
	/** 售卖状态 1:可售卖 2:不可售卖 */
	private String sellState;
	/** 状态时间 */
	private String sellTime;
	/** 货道数量 */
	private Integer laneNum;
	/** 商品存放最大数 */
	private Integer pMaxNum;
	/** 当前商品数量 */
	private Integer pCurNum;
	/** 库存级别(用于进度条显示分三级) */
	private Integer stockLevel;
	/** 托管公司编号 */
	private String corpId;
	/** 配货模板编号 */
	private String mConfigId;
	/** 售货机配置文件路径 */
	private String configFile;
	/** 创建时间 */
	private String createTime;
	/** 描述 */
	private String description;
	/** 详细地址 */
	private String address;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setSiteId(String siteId) 
	{
		this.siteId = siteId;
	}

	public String getSiteId() 
	{
		return siteId;
	}
	public void setSiteCode(String siteCode) 
	{
		this.siteCode = siteCode;
	}

	public String getSiteCode() 
	{
		return siteCode;
	}
	public void setSiteName(String siteName) 
	{
		this.siteName = siteName;
	}

	public String getSiteName() 
	{
		return siteName;
	}
	public void setFactoryId(String factoryId) 
	{
		this.factoryId = factoryId;
	}

	public String getFactoryId() 
	{
		return factoryId;
	}
	public void setCabinetType(String cabinetType) 
	{
		this.cabinetType = cabinetType;
	}

	public String getCabinetType() 
	{
		return cabinetType;
	}
	public void setDeviceId(String deviceId) 
	{
		this.deviceId = deviceId;
	}

	public String getDeviceId() 
	{
		return deviceId;
	}
	public void setDistrictId(String districtId) 
	{
		this.districtId = districtId;
	}

	public String getDistrictId() 
	{
		return districtId;
	}
	public void setLineId(String lineId) 
	{
		this.lineId = lineId;
	}

	public String getLineId() 
	{
		return lineId;
	}
	public void setPointId(String pointId) 
	{
		this.pointId = pointId;
	}

	public String getPointId() 
	{
		return pointId;
	}
	public void setLongitude(String longitude) 
	{
		this.longitude = longitude;
	}

	public String getLongitude() 
	{
		return longitude;
	}
	public void setLatitude(String latitude) 
	{
		this.latitude = latitude;
	}

	public String getLatitude() 
	{
		return latitude;
	}
	public void setPayType(String payType) 
	{
		this.payType = payType;
	}

	public String getPayType() 
	{
		return payType;
	}
	public void setMediaType(String mediaType) 
	{
		this.mediaType = mediaType;
	}

	public String getMediaType() 
	{
		return mediaType;
	}
	public void setOnlineTime(String onlineTime) 
	{
		this.onlineTime = onlineTime;
	}

	public String getOnlineTime() 
	{
		return onlineTime;
	}
	public void setInitTime(String initTime) 
	{
		this.initTime = initTime;
	}

	public String getInitTime() 
	{
		return initTime;
	}
	public void setCurState(String curState) 
	{
		this.curState = curState;
	}

	public String getCurState() 
	{
		return curState;
	}
	public void setStateTime(String stateTime) 
	{
		this.stateTime = stateTime;
	}

	public String getStateTime() 
	{
		return stateTime;
	}
	public void setNetWork(String netWork) 
	{
		this.netWork = netWork;
	}

	public String getNetWork() 
	{
		return netWork;
	}
	public void setNetSate(String netSate) 
	{
		this.netSate = netSate;
	}

	public String getNetSate() 
	{
		return netSate;
	}
	public void setNetTime(String netTime) 
	{
		this.netTime = netTime;
	}

	public String getNetTime() 
	{
		return netTime;
	}
	public void setSellState(String sellState) 
	{
		this.sellState = sellState;
	}

	public String getSellState() 
	{
		return sellState;
	}
	public void setSellTime(String sellTime) 
	{
		this.sellTime = sellTime;
	}

	public String getSellTime() 
	{
		return sellTime;
	}
	public void setLaneNum(Integer laneNum) 
	{
		this.laneNum = laneNum;
	}

	public Integer getLaneNum() 
	{
		return laneNum;
	}
	public void setPMaxNum(Integer pMaxNum) 
	{
		this.pMaxNum = pMaxNum;
	}

	public Integer getPMaxNum() 
	{
		return pMaxNum;
	}
	public void setPCurNum(Integer pCurNum) 
	{
		this.pCurNum = pCurNum;
	}

	public Integer getPCurNum() 
	{
		return pCurNum;
	}
	public void setStockLevel(Integer stockLevel) 
	{
		this.stockLevel = stockLevel;
	}

	public Integer getStockLevel() 
	{
		return stockLevel;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setMConfigId(String mConfigId) 
	{
		this.mConfigId = mConfigId;
	}

	public String getMConfigId() 
	{
		return mConfigId;
	}
	public void setConfigFile(String configFile) 
	{
		this.configFile = configFile;
	}

	public String getConfigFile() 
	{
		return configFile;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}
	public void setDescription(String description) 
	{
		this.description = description;
	}

	public String getDescription() 
	{
		return description;
	}
	public void setAddress(String address) 
	{
		this.address = address;
	}

	public String getAddress() 
	{
		return address;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("siteId", getSiteId())
            .append("siteCode", getSiteCode())
            .append("siteName", getSiteName())
            .append("factoryId", getFactoryId())
            .append("cabinetType", getCabinetType())
            .append("deviceId", getDeviceId())
            .append("districtId", getDistrictId())
            .append("lineId", getLineId())
            .append("pointId", getPointId())
            .append("longitude", getLongitude())
            .append("latitude", getLatitude())
            .append("payType", getPayType())
            .append("mediaType", getMediaType())
            .append("onlineTime", getOnlineTime())
            .append("initTime", getInitTime())
            .append("curState", getCurState())
            .append("stateTime", getStateTime())
            .append("netWork", getNetWork())
            .append("netSate", getNetSate())
            .append("netTime", getNetTime())
            .append("sellState", getSellState())
            .append("sellTime", getSellTime())
            .append("laneNum", getLaneNum())
            .append("pMaxNum", getPMaxNum())
            .append("pCurNum", getPCurNum())
            .append("stockLevel", getStockLevel())
            .append("corpId", getCorpId())
            .append("mConfigId", getMConfigId())
            .append("configFile", getConfigFile())
            .append("createTime", getCreateTime())
            .append("description", getDescription())
            .append("address", getAddress())
            .toString();
    }
}
