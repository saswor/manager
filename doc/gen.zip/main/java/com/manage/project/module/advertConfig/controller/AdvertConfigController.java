package com.manage.project.module.advertConfig.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.advertConfig.domain.AdvertConfig;
import com.manage.project.module.advertConfig.service.IAdvertConfigService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 广告配置 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/advertConfig")
public class AdvertConfigController extends BaseController
{
    private String prefix = "module/advertConfig";
	
	@Autowired
	private IAdvertConfigService advertConfigService;
	
	@RequiresPermissions("module:advertConfig:view")
	@GetMapping()
	public String advertConfig()
	{
	    return prefix + "/advertConfig";
	}
	
	/**
	 * 查询广告配置列表
	 */
	@RequiresPermissions("module:advertConfig:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(AdvertConfig advertConfig)
	{
		startPage();
        List<AdvertConfig> list = advertConfigService.selectAdvertConfigList(advertConfig);
		return getDataTable(list);
	}
	
	/**
	 * 新增广告配置
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存广告配置
	 */
	@RequiresPermissions("module:advertConfig:add")
	@Log(title = "广告配置", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(AdvertConfig advertConfig)
	{		
		return toAjax(advertConfigService.insertAdvertConfig(advertConfig));
	}

	/**
	 * 修改广告配置
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		AdvertConfig advertConfig = advertConfigService.selectAdvertConfigById(logid);
		mmap.put("advertConfig", advertConfig);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存广告配置
	 */
	@RequiresPermissions("module:advertConfig:edit")
	@Log(title = "广告配置", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(AdvertConfig advertConfig)
	{		
		return toAjax(advertConfigService.updateAdvertConfig(advertConfig));
	}
	
	/**
	 * 删除广告配置
	 */
	@RequiresPermissions("module:advertConfig:remove")
	@Log(title = "广告配置", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(advertConfigService.deleteAdvertConfigByIds(ids));
	}
	
}
