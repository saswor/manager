package com.manage.project.module.favourableTime.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.favourableTime.domain.FavourableTime;
import com.manage.project.module.favourableTime.service.IFavourableTimeService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 优惠售货机列，不管是统一优惠还是分时段优惠都会生成优惠时间段，统一优惠只会有一条记录，分时段可能包含多条记录。 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/favourableTime")
public class FavourableTimeController extends BaseController
{
    private String prefix = "module/favourableTime";
	
	@Autowired
	private IFavourableTimeService favourableTimeService;
	
	@RequiresPermissions("module:favourableTime:view")
	@GetMapping()
	public String favourableTime()
	{
	    return prefix + "/favourableTime";
	}
	
	/**
	 * 查询优惠售货机列，不管是统一优惠还是分时段优惠都会生成优惠时间段，统一优惠只会有一条记录，分时段可能包含多条记录。列表
	 */
	@RequiresPermissions("module:favourableTime:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(FavourableTime favourableTime)
	{
		startPage();
        List<FavourableTime> list = favourableTimeService.selectFavourableTimeList(favourableTime);
		return getDataTable(list);
	}
	
	/**
	 * 新增优惠售货机列，不管是统一优惠还是分时段优惠都会生成优惠时间段，统一优惠只会有一条记录，分时段可能包含多条记录。
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存优惠售货机列，不管是统一优惠还是分时段优惠都会生成优惠时间段，统一优惠只会有一条记录，分时段可能包含多条记录。
	 */
	@RequiresPermissions("module:favourableTime:add")
	@Log(title = "优惠售货机列，不管是统一优惠还是分时段优惠都会生成优惠时间段，统一优惠只会有一条记录，分时段可能包含多条记录。", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(FavourableTime favourableTime)
	{		
		return toAjax(favourableTimeService.insertFavourableTime(favourableTime));
	}

	/**
	 * 修改优惠售货机列，不管是统一优惠还是分时段优惠都会生成优惠时间段，统一优惠只会有一条记录，分时段可能包含多条记录。
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		FavourableTime favourableTime = favourableTimeService.selectFavourableTimeById(logid);
		mmap.put("favourableTime", favourableTime);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存优惠售货机列，不管是统一优惠还是分时段优惠都会生成优惠时间段，统一优惠只会有一条记录，分时段可能包含多条记录。
	 */
	@RequiresPermissions("module:favourableTime:edit")
	@Log(title = "优惠售货机列，不管是统一优惠还是分时段优惠都会生成优惠时间段，统一优惠只会有一条记录，分时段可能包含多条记录。", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(FavourableTime favourableTime)
	{		
		return toAjax(favourableTimeService.updateFavourableTime(favourableTime));
	}
	
	/**
	 * 删除优惠售货机列，不管是统一优惠还是分时段优惠都会生成优惠时间段，统一优惠只会有一条记录，分时段可能包含多条记录。
	 */
	@RequiresPermissions("module:favourableTime:remove")
	@Log(title = "优惠售货机列，不管是统一优惠还是分时段优惠都会生成优惠时间段，统一优惠只会有一条记录，分时段可能包含多条记录。", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(favourableTimeService.deleteFavourableTimeByIds(ids));
	}
	
}
