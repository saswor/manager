package com.manage.project.module.statementBalance.mapper;

import com.manage.project.module.statementBalance.domain.StatementBalance;
import java.util.List;	

/**
 * 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。 数据层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface StatementBalanceMapper 
{
	/**
     * 查询根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。信息
     * 
     * @param logid 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。ID
     * @return 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。信息
     */
	public StatementBalance selectStatementBalanceById(String logid);
	
	/**
     * 查询根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。列表
     * 
     * @param statementBalance 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。信息
     * @return 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。集合
     */
	public List<StatementBalance> selectStatementBalanceList(StatementBalance statementBalance);
	
	/**
     * 新增根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。
     * 
     * @param statementBalance 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。信息
     * @return 结果
     */
	public int insertStatementBalance(StatementBalance statementBalance);
	
	/**
     * 修改根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。
     * 
     * @param statementBalance 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。信息
     * @return 结果
     */
	public int updateStatementBalance(StatementBalance statementBalance);
	
	/**
     * 删除根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。
     * 
     * @param logid 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。ID
     * @return 结果
     */
	public int deleteStatementBalanceById(String logid);
	
	/**
     * 批量删除根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。
     * 
     * @param logids 需要删除的数据ID
     * @return 结果
     */
	public int deleteStatementBalanceByIds(String[] logids);
	
}