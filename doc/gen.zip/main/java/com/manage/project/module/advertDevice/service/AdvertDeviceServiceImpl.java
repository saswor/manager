package com.manage.project.module.advertDevice.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.advertDevice.mapper.AdvertDeviceMapper;
import com.manage.project.module.advertDevice.domain.AdvertDevice;
import com.manage.project.module.advertDevice.service.IAdvertDeviceService;
import com.manage.common.support.Convert;

/**
 * 广告播放对象设置，也叫播放任务列 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class AdvertDeviceServiceImpl implements IAdvertDeviceService 
{
	@Autowired
	private AdvertDeviceMapper advertDeviceMapper;

	/**
     * 查询广告播放对象设置，也叫播放任务列信息
     * 
     * @param logid 广告播放对象设置，也叫播放任务列ID
     * @return 广告播放对象设置，也叫播放任务列信息
     */
    @Override
	public AdvertDevice selectAdvertDeviceById(String logid)
	{
	    return advertDeviceMapper.selectAdvertDeviceById(logid);
	}
	
	/**
     * 查询广告播放对象设置，也叫播放任务列列表
     * 
     * @param advertDevice 广告播放对象设置，也叫播放任务列信息
     * @return 广告播放对象设置，也叫播放任务列集合
     */
	@Override
	public List<AdvertDevice> selectAdvertDeviceList(AdvertDevice advertDevice)
	{
	    return advertDeviceMapper.selectAdvertDeviceList(advertDevice);
	}
	
    /**
     * 新增广告播放对象设置，也叫播放任务列
     * 
     * @param advertDevice 广告播放对象设置，也叫播放任务列信息
     * @return 结果
     */
	@Override
	public int insertAdvertDevice(AdvertDevice advertDevice)
	{
	    return advertDeviceMapper.insertAdvertDevice(advertDevice);
	}
	
	/**
     * 修改广告播放对象设置，也叫播放任务列
     * 
     * @param advertDevice 广告播放对象设置，也叫播放任务列信息
     * @return 结果
     */
	@Override
	public int updateAdvertDevice(AdvertDevice advertDevice)
	{
	    return advertDeviceMapper.updateAdvertDevice(advertDevice);
	}

	/**
     * 删除广告播放对象设置，也叫播放任务列对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteAdvertDeviceByIds(String ids)
	{
		return advertDeviceMapper.deleteAdvertDeviceByIds(Convert.toStrArray(ids));
	}
	
}
