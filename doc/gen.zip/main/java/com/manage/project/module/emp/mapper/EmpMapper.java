package com.manage.project.module.emp.mapper;

import com.manage.project.module.emp.domain.Emp;
import java.util.List;	

/**
 * 系统人员管理 数据层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface EmpMapper 
{
	/**
     * 查询系统人员管理信息
     * 
     * @param logid 系统人员管理ID
     * @return 系统人员管理信息
     */
	public Emp selectEmpById(String logid);
	
	/**
     * 查询系统人员管理列表
     * 
     * @param emp 系统人员管理信息
     * @return 系统人员管理集合
     */
	public List<Emp> selectEmpList(Emp emp);
	
	/**
     * 新增系统人员管理
     * 
     * @param emp 系统人员管理信息
     * @return 结果
     */
	public int insertEmp(Emp emp);
	
	/**
     * 修改系统人员管理
     * 
     * @param emp 系统人员管理信息
     * @return 结果
     */
	public int updateEmp(Emp emp);
	
	/**
     * 删除系统人员管理
     * 
     * @param logid 系统人员管理ID
     * @return 结果
     */
	public int deleteEmpById(String logid);
	
	/**
     * 批量删除系统人员管理
     * 
     * @param logids 需要删除的数据ID
     * @return 结果
     */
	public int deleteEmpByIds(String[] logids);
	
}