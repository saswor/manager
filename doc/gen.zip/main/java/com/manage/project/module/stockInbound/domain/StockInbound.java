package com.manage.project.module.stockInbound.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 仓库入库记录表 as_stock_inbound
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class StockInbound extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 仓库入库记录编号 */
	private String wInboundId;
	/** 仓采购记录编号 */
	private String wPurchaseId;
	/** 仓库编号 */
	private String stockId;
	/** 仓库名称 */
	private String stokcName;
	/** 总入库数量 */
	private Integer pNum;
	/** 入库商品种类数 */
	private Integer tNum;
	/** 入库采购总价 */
	private Float totalPrice;
	/** 当前状态 1:未入库 2:已入库 */
	private String curState;
	/** 当前状态变化时间 */
	private String stateTime;
	/** 入库人编号 */
	private String inboundId;
	/** 托管公司编号 */
	private String corpId;
	/** 创建时间 */
	private String createTime;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setWInboundId(String wInboundId) 
	{
		this.wInboundId = wInboundId;
	}

	public String getWInboundId() 
	{
		return wInboundId;
	}
	public void setWPurchaseId(String wPurchaseId) 
	{
		this.wPurchaseId = wPurchaseId;
	}

	public String getWPurchaseId() 
	{
		return wPurchaseId;
	}
	public void setStockId(String stockId) 
	{
		this.stockId = stockId;
	}

	public String getStockId() 
	{
		return stockId;
	}
	public void setStokcName(String stokcName) 
	{
		this.stokcName = stokcName;
	}

	public String getStokcName() 
	{
		return stokcName;
	}
	public void setPNum(Integer pNum) 
	{
		this.pNum = pNum;
	}

	public Integer getPNum() 
	{
		return pNum;
	}
	public void setTNum(Integer tNum) 
	{
		this.tNum = tNum;
	}

	public Integer getTNum() 
	{
		return tNum;
	}
	public void setTotalPrice(Float totalPrice) 
	{
		this.totalPrice = totalPrice;
	}

	public Float getTotalPrice() 
	{
		return totalPrice;
	}
	public void setCurState(String curState) 
	{
		this.curState = curState;
	}

	public String getCurState() 
	{
		return curState;
	}
	public void setStateTime(String stateTime) 
	{
		this.stateTime = stateTime;
	}

	public String getStateTime() 
	{
		return stateTime;
	}
	public void setInboundId(String inboundId) 
	{
		this.inboundId = inboundId;
	}

	public String getInboundId() 
	{
		return inboundId;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("wInboundId", getWInboundId())
            .append("wPurchaseId", getWPurchaseId())
            .append("stockId", getStockId())
            .append("stokcName", getStokcName())
            .append("pNum", getPNum())
            .append("tNum", getTNum())
            .append("totalPrice", getTotalPrice())
            .append("curState", getCurState())
            .append("stateTime", getStateTime())
            .append("inboundId", getInboundId())
            .append("corpId", getCorpId())
            .append("createTime", getCreateTime())
            .toString();
    }
}
