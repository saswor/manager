package com.manage.project.module.reportMsale.service;

import com.manage.project.module.reportMsale.domain.ReportMsale;
import java.util.List;

/**
 * 仪盘概要统计报 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IReportMsaleService 
{
	/**
     * 查询仪盘概要统计报信息
     * 
     * @param logid 仪盘概要统计报ID
     * @return 仪盘概要统计报信息
     */
	public ReportMsale selectReportMsaleById(String logid);
	
	/**
     * 查询仪盘概要统计报列表
     * 
     * @param reportMsale 仪盘概要统计报信息
     * @return 仪盘概要统计报集合
     */
	public List<ReportMsale> selectReportMsaleList(ReportMsale reportMsale);
	
	/**
     * 新增仪盘概要统计报
     * 
     * @param reportMsale 仪盘概要统计报信息
     * @return 结果
     */
	public int insertReportMsale(ReportMsale reportMsale);
	
	/**
     * 修改仪盘概要统计报
     * 
     * @param reportMsale 仪盘概要统计报信息
     * @return 结果
     */
	public int updateReportMsale(ReportMsale reportMsale);
		
	/**
     * 删除仪盘概要统计报信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteReportMsaleByIds(String ids);
	
}
