package com.manage.project.module.vending.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.vending.mapper.VendingMapper;
import com.manage.project.module.vending.domain.Vending;
import com.manage.project.module.vending.service.IVendingService;
import com.manage.common.support.Convert;

/**
 * 售货机的基本，主柜 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class VendingServiceImpl implements IVendingService 
{
	@Autowired
	private VendingMapper vendingMapper;

	/**
     * 查询售货机的基本，主柜信息
     * 
     * @param logid 售货机的基本，主柜ID
     * @return 售货机的基本，主柜信息
     */
    @Override
	public Vending selectVendingById(String logid)
	{
	    return vendingMapper.selectVendingById(logid);
	}
	
	/**
     * 查询售货机的基本，主柜列表
     * 
     * @param vending 售货机的基本，主柜信息
     * @return 售货机的基本，主柜集合
     */
	@Override
	public List<Vending> selectVendingList(Vending vending)
	{
	    return vendingMapper.selectVendingList(vending);
	}
	
    /**
     * 新增售货机的基本，主柜
     * 
     * @param vending 售货机的基本，主柜信息
     * @return 结果
     */
	@Override
	public int insertVending(Vending vending)
	{
	    return vendingMapper.insertVending(vending);
	}
	
	/**
     * 修改售货机的基本，主柜
     * 
     * @param vending 售货机的基本，主柜信息
     * @return 结果
     */
	@Override
	public int updateVending(Vending vending)
	{
	    return vendingMapper.updateVending(vending);
	}

	/**
     * 删除售货机的基本，主柜对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteVendingByIds(String ids)
	{
		return vendingMapper.deleteVendingByIds(Convert.toStrArray(ids));
	}
	
}
