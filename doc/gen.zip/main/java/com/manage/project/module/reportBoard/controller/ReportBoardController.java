package com.manage.project.module.reportBoard.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.reportBoard.domain.ReportBoard;
import com.manage.project.module.reportBoard.service.IReportBoardService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 仪盘概要统计报(即时更新) 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/reportBoard")
public class ReportBoardController extends BaseController
{
    private String prefix = "module/reportBoard";
	
	@Autowired
	private IReportBoardService reportBoardService;
	
	@RequiresPermissions("module:reportBoard:view")
	@GetMapping()
	public String reportBoard()
	{
	    return prefix + "/reportBoard";
	}
	
	/**
	 * 查询仪盘概要统计报(即时更新)列表
	 */
	@RequiresPermissions("module:reportBoard:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(ReportBoard reportBoard)
	{
		startPage();
        List<ReportBoard> list = reportBoardService.selectReportBoardList(reportBoard);
		return getDataTable(list);
	}
	
	/**
	 * 新增仪盘概要统计报(即时更新)
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存仪盘概要统计报(即时更新)
	 */
	@RequiresPermissions("module:reportBoard:add")
	@Log(title = "仪盘概要统计报(即时更新)", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(ReportBoard reportBoard)
	{		
		return toAjax(reportBoardService.insertReportBoard(reportBoard));
	}

	/**
	 * 修改仪盘概要统计报(即时更新)
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		ReportBoard reportBoard = reportBoardService.selectReportBoardById(logid);
		mmap.put("reportBoard", reportBoard);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存仪盘概要统计报(即时更新)
	 */
	@RequiresPermissions("module:reportBoard:edit")
	@Log(title = "仪盘概要统计报(即时更新)", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(ReportBoard reportBoard)
	{		
		return toAjax(reportBoardService.updateReportBoard(reportBoard));
	}
	
	/**
	 * 删除仪盘概要统计报(即时更新)
	 */
	@RequiresPermissions("module:reportBoard:remove")
	@Log(title = "仪盘概要统计报(即时更新)", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(reportBoardService.deleteReportBoardByIds(ids));
	}
	
}
