package com.manage.project.module.statementSupply.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.statementSupply.mapper.StatementSupplyMapper;
import com.manage.project.module.statementSupply.domain.StatementSupply;
import com.manage.project.module.statementSupply.service.IStatementSupplyService;
import com.manage.common.support.Convert;

/**
 * 对账补货 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class StatementSupplyServiceImpl implements IStatementSupplyService 
{
	@Autowired
	private StatementSupplyMapper statementSupplyMapper;

	/**
     * 查询对账补货信息
     * 
     * @param logid 对账补货ID
     * @return 对账补货信息
     */
    @Override
	public StatementSupply selectStatementSupplyById(String logid)
	{
	    return statementSupplyMapper.selectStatementSupplyById(logid);
	}
	
	/**
     * 查询对账补货列表
     * 
     * @param statementSupply 对账补货信息
     * @return 对账补货集合
     */
	@Override
	public List<StatementSupply> selectStatementSupplyList(StatementSupply statementSupply)
	{
	    return statementSupplyMapper.selectStatementSupplyList(statementSupply);
	}
	
    /**
     * 新增对账补货
     * 
     * @param statementSupply 对账补货信息
     * @return 结果
     */
	@Override
	public int insertStatementSupply(StatementSupply statementSupply)
	{
	    return statementSupplyMapper.insertStatementSupply(statementSupply);
	}
	
	/**
     * 修改对账补货
     * 
     * @param statementSupply 对账补货信息
     * @return 结果
     */
	@Override
	public int updateStatementSupply(StatementSupply statementSupply)
	{
	    return statementSupplyMapper.updateStatementSupply(statementSupply);
	}

	/**
     * 删除对账补货对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteStatementSupplyByIds(String ids)
	{
		return statementSupplyMapper.deleteStatementSupplyByIds(Convert.toStrArray(ids));
	}
	
}
