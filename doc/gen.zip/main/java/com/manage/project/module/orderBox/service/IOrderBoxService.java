package com.manage.project.module.orderBox.service;

import com.manage.project.module.orderBox.domain.OrderBox;
import java.util.List;

/**
 * 记录每个商品的货道出库情况 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IOrderBoxService 
{
	/**
     * 查询记录每个商品的货道出库情况信息
     * 
     * @param logid 记录每个商品的货道出库情况ID
     * @return 记录每个商品的货道出库情况信息
     */
	public OrderBox selectOrderBoxById(String logid);
	
	/**
     * 查询记录每个商品的货道出库情况列表
     * 
     * @param orderBox 记录每个商品的货道出库情况信息
     * @return 记录每个商品的货道出库情况集合
     */
	public List<OrderBox> selectOrderBoxList(OrderBox orderBox);
	
	/**
     * 新增记录每个商品的货道出库情况
     * 
     * @param orderBox 记录每个商品的货道出库情况信息
     * @return 结果
     */
	public int insertOrderBox(OrderBox orderBox);
	
	/**
     * 修改记录每个商品的货道出库情况
     * 
     * @param orderBox 记录每个商品的货道出库情况信息
     * @return 结果
     */
	public int updateOrderBox(OrderBox orderBox);
		
	/**
     * 删除记录每个商品的货道出库情况信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOrderBoxByIds(String ids);
	
}
