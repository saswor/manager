package com.manage.project.module.advertDevice.mapper;

import com.manage.project.module.advertDevice.domain.AdvertDevice;
import java.util.List;	

/**
 * 广告播放对象设置，也叫播放任务列 数据层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface AdvertDeviceMapper 
{
	/**
     * 查询广告播放对象设置，也叫播放任务列信息
     * 
     * @param logid 广告播放对象设置，也叫播放任务列ID
     * @return 广告播放对象设置，也叫播放任务列信息
     */
	public AdvertDevice selectAdvertDeviceById(String logid);
	
	/**
     * 查询广告播放对象设置，也叫播放任务列列表
     * 
     * @param advertDevice 广告播放对象设置，也叫播放任务列信息
     * @return 广告播放对象设置，也叫播放任务列集合
     */
	public List<AdvertDevice> selectAdvertDeviceList(AdvertDevice advertDevice);
	
	/**
     * 新增广告播放对象设置，也叫播放任务列
     * 
     * @param advertDevice 广告播放对象设置，也叫播放任务列信息
     * @return 结果
     */
	public int insertAdvertDevice(AdvertDevice advertDevice);
	
	/**
     * 修改广告播放对象设置，也叫播放任务列
     * 
     * @param advertDevice 广告播放对象设置，也叫播放任务列信息
     * @return 结果
     */
	public int updateAdvertDevice(AdvertDevice advertDevice);
	
	/**
     * 删除广告播放对象设置，也叫播放任务列
     * 
     * @param logid 广告播放对象设置，也叫播放任务列ID
     * @return 结果
     */
	public int deleteAdvertDeviceById(String logid);
	
	/**
     * 批量删除广告播放对象设置，也叫播放任务列
     * 
     * @param logids 需要删除的数据ID
     * @return 结果
     */
	public int deleteAdvertDeviceByIds(String[] logids);
	
}