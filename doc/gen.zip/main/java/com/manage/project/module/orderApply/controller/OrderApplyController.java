package com.manage.project.module.orderApply.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.orderApply.domain.OrderApply;
import com.manage.project.module.orderApply.service.IOrderApplyService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 记录客户购买的商品 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/orderApply")
public class OrderApplyController extends BaseController
{
    private String prefix = "module/orderApply";
	
	@Autowired
	private IOrderApplyService orderApplyService;
	
	@RequiresPermissions("module:orderApply:view")
	@GetMapping()
	public String orderApply()
	{
	    return prefix + "/orderApply";
	}
	
	/**
	 * 查询记录客户购买的商品列表
	 */
	@RequiresPermissions("module:orderApply:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(OrderApply orderApply)
	{
		startPage();
        List<OrderApply> list = orderApplyService.selectOrderApplyList(orderApply);
		return getDataTable(list);
	}
	
	/**
	 * 新增记录客户购买的商品
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存记录客户购买的商品
	 */
	@RequiresPermissions("module:orderApply:add")
	@Log(title = "记录客户购买的商品", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(OrderApply orderApply)
	{		
		return toAjax(orderApplyService.insertOrderApply(orderApply));
	}

	/**
	 * 修改记录客户购买的商品
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		OrderApply orderApply = orderApplyService.selectOrderApplyById(logid);
		mmap.put("orderApply", orderApply);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存记录客户购买的商品
	 */
	@RequiresPermissions("module:orderApply:edit")
	@Log(title = "记录客户购买的商品", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(OrderApply orderApply)
	{		
		return toAjax(orderApplyService.updateOrderApply(orderApply));
	}
	
	/**
	 * 删除记录客户购买的商品
	 */
	@RequiresPermissions("module:orderApply:remove")
	@Log(title = "记录客户购买的商品", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(orderApplyService.deleteOrderApplyByIds(ids));
	}
	
}
