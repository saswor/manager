package com.manage.project.module.stockInbound.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.stockInbound.domain.StockInbound;
import com.manage.project.module.stockInbound.service.IStockInboundService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 仓库入库记录 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/stockInbound")
public class StockInboundController extends BaseController
{
    private String prefix = "module/stockInbound";
	
	@Autowired
	private IStockInboundService stockInboundService;
	
	@RequiresPermissions("module:stockInbound:view")
	@GetMapping()
	public String stockInbound()
	{
	    return prefix + "/stockInbound";
	}
	
	/**
	 * 查询仓库入库记录列表
	 */
	@RequiresPermissions("module:stockInbound:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(StockInbound stockInbound)
	{
		startPage();
        List<StockInbound> list = stockInboundService.selectStockInboundList(stockInbound);
		return getDataTable(list);
	}
	
	/**
	 * 新增仓库入库记录
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存仓库入库记录
	 */
	@RequiresPermissions("module:stockInbound:add")
	@Log(title = "仓库入库记录", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(StockInbound stockInbound)
	{		
		return toAjax(stockInboundService.insertStockInbound(stockInbound));
	}

	/**
	 * 修改仓库入库记录
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		StockInbound stockInbound = stockInboundService.selectStockInboundById(logid);
		mmap.put("stockInbound", stockInbound);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存仓库入库记录
	 */
	@RequiresPermissions("module:stockInbound:edit")
	@Log(title = "仓库入库记录", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(StockInbound stockInbound)
	{		
		return toAjax(stockInboundService.updateStockInbound(stockInbound));
	}
	
	/**
	 * 删除仓库入库记录
	 */
	@RequiresPermissions("module:stockInbound:remove")
	@Log(title = "仓库入库记录", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(stockInboundService.deleteStockInboundByIds(ids));
	}
	
}
