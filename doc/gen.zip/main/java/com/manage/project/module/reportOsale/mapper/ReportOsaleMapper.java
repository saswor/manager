package com.manage.project.module.reportOsale.mapper;

import com.manage.project.module.reportOsale.domain.ReportOsale;
import java.util.List;	

/**
 * 每天销量排行统计 数据层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface ReportOsaleMapper 
{
	/**
     * 查询每天销量排行统计信息
     * 
     * @param logid 每天销量排行统计ID
     * @return 每天销量排行统计信息
     */
	public ReportOsale selectReportOsaleById(String logid);
	
	/**
     * 查询每天销量排行统计列表
     * 
     * @param reportOsale 每天销量排行统计信息
     * @return 每天销量排行统计集合
     */
	public List<ReportOsale> selectReportOsaleList(ReportOsale reportOsale);
	
	/**
     * 新增每天销量排行统计
     * 
     * @param reportOsale 每天销量排行统计信息
     * @return 结果
     */
	public int insertReportOsale(ReportOsale reportOsale);
	
	/**
     * 修改每天销量排行统计
     * 
     * @param reportOsale 每天销量排行统计信息
     * @return 结果
     */
	public int updateReportOsale(ReportOsale reportOsale);
	
	/**
     * 删除每天销量排行统计
     * 
     * @param logid 每天销量排行统计ID
     * @return 结果
     */
	public int deleteReportOsaleById(String logid);
	
	/**
     * 批量删除每天销量排行统计
     * 
     * @param logids 需要删除的数据ID
     * @return 结果
     */
	public int deleteReportOsaleByIds(String[] logids);
	
}