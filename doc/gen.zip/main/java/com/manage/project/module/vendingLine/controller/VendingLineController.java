package com.manage.project.module.vendingLine.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.vendingLine.domain.VendingLine;
import com.manage.project.module.vendingLine.service.IVendingLineService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 点位的线路 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/vendingLine")
public class VendingLineController extends BaseController
{
    private String prefix = "module/vendingLine";
	
	@Autowired
	private IVendingLineService vendingLineService;
	
	@RequiresPermissions("module:vendingLine:view")
	@GetMapping()
	public String vendingLine()
	{
	    return prefix + "/vendingLine";
	}
	
	/**
	 * 查询点位的线路列表
	 */
	@RequiresPermissions("module:vendingLine:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(VendingLine vendingLine)
	{
		startPage();
        List<VendingLine> list = vendingLineService.selectVendingLineList(vendingLine);
		return getDataTable(list);
	}
	
	/**
	 * 新增点位的线路
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存点位的线路
	 */
	@RequiresPermissions("module:vendingLine:add")
	@Log(title = "点位的线路", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(VendingLine vendingLine)
	{		
		return toAjax(vendingLineService.insertVendingLine(vendingLine));
	}

	/**
	 * 修改点位的线路
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		VendingLine vendingLine = vendingLineService.selectVendingLineById(logid);
		mmap.put("vendingLine", vendingLine);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存点位的线路
	 */
	@RequiresPermissions("module:vendingLine:edit")
	@Log(title = "点位的线路", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(VendingLine vendingLine)
	{		
		return toAjax(vendingLineService.updateVendingLine(vendingLine));
	}
	
	/**
	 * 删除点位的线路
	 */
	@RequiresPermissions("module:vendingLine:remove")
	@Log(title = "点位的线路", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(vendingLineService.deleteVendingLineByIds(ids));
	}
	
}
