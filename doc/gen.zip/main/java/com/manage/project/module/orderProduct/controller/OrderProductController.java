package com.manage.project.module.orderProduct.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.orderProduct.domain.OrderProduct;
import com.manage.project.module.orderProduct.service.IOrderProductService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 记录客户购买的商品 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/orderProduct")
public class OrderProductController extends BaseController
{
    private String prefix = "module/orderProduct";
	
	@Autowired
	private IOrderProductService orderProductService;
	
	@RequiresPermissions("module:orderProduct:view")
	@GetMapping()
	public String orderProduct()
	{
	    return prefix + "/orderProduct";
	}
	
	/**
	 * 查询记录客户购买的商品列表
	 */
	@RequiresPermissions("module:orderProduct:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(OrderProduct orderProduct)
	{
		startPage();
        List<OrderProduct> list = orderProductService.selectOrderProductList(orderProduct);
		return getDataTable(list);
	}
	
	/**
	 * 新增记录客户购买的商品
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存记录客户购买的商品
	 */
	@RequiresPermissions("module:orderProduct:add")
	@Log(title = "记录客户购买的商品", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(OrderProduct orderProduct)
	{		
		return toAjax(orderProductService.insertOrderProduct(orderProduct));
	}

	/**
	 * 修改记录客户购买的商品
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		OrderProduct orderProduct = orderProductService.selectOrderProductById(logid);
		mmap.put("orderProduct", orderProduct);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存记录客户购买的商品
	 */
	@RequiresPermissions("module:orderProduct:edit")
	@Log(title = "记录客户购买的商品", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(OrderProduct orderProduct)
	{		
		return toAjax(orderProductService.updateOrderProduct(orderProduct));
	}
	
	/**
	 * 删除记录客户购买的商品
	 */
	@RequiresPermissions("module:orderProduct:remove")
	@Log(title = "记录客户购买的商品", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(orderProductService.deleteOrderProductByIds(ids));
	}
	
}
