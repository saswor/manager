-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。', '3', '1', '/module/statementBalance', 'C', '0', 'module:statementBalance:view', '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。查询', @parentId, '1',  '#',  'F', '0', 'module:statementBalance:list',         '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');

insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。新增', @parentId, '2',  '#',  'F', '0', 'module:statementBalance:add',          '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');

insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。修改', @parentId, '3',  '#',  'F', '0', 'module:statementBalance:edit',         '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');

insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。删除', @parentId, '4',  '#',  'F', '0', 'module:statementBalance:remove',       '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');
