package com.manage.project.module.orderBox.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.orderBox.domain.OrderBox;
import com.manage.project.module.orderBox.service.IOrderBoxService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 记录每个商品的货道出库情况 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/orderBox")
public class OrderBoxController extends BaseController
{
    private String prefix = "module/orderBox";
	
	@Autowired
	private IOrderBoxService orderBoxService;
	
	@RequiresPermissions("module:orderBox:view")
	@GetMapping()
	public String orderBox()
	{
	    return prefix + "/orderBox";
	}
	
	/**
	 * 查询记录每个商品的货道出库情况列表
	 */
	@RequiresPermissions("module:orderBox:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(OrderBox orderBox)
	{
		startPage();
        List<OrderBox> list = orderBoxService.selectOrderBoxList(orderBox);
		return getDataTable(list);
	}
	
	/**
	 * 新增记录每个商品的货道出库情况
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存记录每个商品的货道出库情况
	 */
	@RequiresPermissions("module:orderBox:add")
	@Log(title = "记录每个商品的货道出库情况", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(OrderBox orderBox)
	{		
		return toAjax(orderBoxService.insertOrderBox(orderBox));
	}

	/**
	 * 修改记录每个商品的货道出库情况
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		OrderBox orderBox = orderBoxService.selectOrderBoxById(logid);
		mmap.put("orderBox", orderBox);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存记录每个商品的货道出库情况
	 */
	@RequiresPermissions("module:orderBox:edit")
	@Log(title = "记录每个商品的货道出库情况", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(OrderBox orderBox)
	{		
		return toAjax(orderBoxService.updateOrderBox(orderBox));
	}
	
	/**
	 * 删除记录每个商品的货道出库情况
	 */
	@RequiresPermissions("module:orderBox:remove")
	@Log(title = "记录每个商品的货道出库情况", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(orderBoxService.deleteOrderBoxByIds(ids));
	}
	
}
