package com.manage.project.module.stockProduct.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 商品库存量表 as_stock_product
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class StockProduct extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 商品库存编号 */
	private String pstockId;
	/** 商品编号 */
	private String productId;
	/** 商品名称 */
	private String productName;
	/** 总库存数量 */
	private Integer totalNum;
	/** 当前库存总数量 */
	private Integer curNum;
	/** 过期总数 */
	private Integer overNum;
	/** 托管公司编号 */
	private String corpId;
	/** 创建时间 */
	private String createTime;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setPstockId(String pstockId) 
	{
		this.pstockId = pstockId;
	}

	public String getPstockId() 
	{
		return pstockId;
	}
	public void setProductId(String productId) 
	{
		this.productId = productId;
	}

	public String getProductId() 
	{
		return productId;
	}
	public void setProductName(String productName) 
	{
		this.productName = productName;
	}

	public String getProductName() 
	{
		return productName;
	}
	public void setTotalNum(Integer totalNum) 
	{
		this.totalNum = totalNum;
	}

	public Integer getTotalNum() 
	{
		return totalNum;
	}
	public void setCurNum(Integer curNum) 
	{
		this.curNum = curNum;
	}

	public Integer getCurNum() 
	{
		return curNum;
	}
	public void setOverNum(Integer overNum) 
	{
		this.overNum = overNum;
	}

	public Integer getOverNum() 
	{
		return overNum;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("pstockId", getPstockId())
            .append("productId", getProductId())
            .append("productName", getProductName())
            .append("totalNum", getTotalNum())
            .append("curNum", getCurNum())
            .append("overNum", getOverNum())
            .append("corpId", getCorpId())
            .append("createTime", getCreateTime())
            .toString();
    }
}
