package com.manage.project.module.vendingLanep.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.vendingLanep.domain.VendingLanep;
import com.manage.project.module.vendingLanep.service.IVendingLanepService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 售货机货道商品 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/vendingLanep")
public class VendingLanepController extends BaseController
{
    private String prefix = "module/vendingLanep";
	
	@Autowired
	private IVendingLanepService vendingLanepService;
	
	@RequiresPermissions("module:vendingLanep:view")
	@GetMapping()
	public String vendingLanep()
	{
	    return prefix + "/vendingLanep";
	}
	
	/**
	 * 查询售货机货道商品列表
	 */
	@RequiresPermissions("module:vendingLanep:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(VendingLanep vendingLanep)
	{
		startPage();
        List<VendingLanep> list = vendingLanepService.selectVendingLanepList(vendingLanep);
		return getDataTable(list);
	}
	
	/**
	 * 新增售货机货道商品
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存售货机货道商品
	 */
	@RequiresPermissions("module:vendingLanep:add")
	@Log(title = "售货机货道商品", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(VendingLanep vendingLanep)
	{		
		return toAjax(vendingLanepService.insertVendingLanep(vendingLanep));
	}

	/**
	 * 修改售货机货道商品
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		VendingLanep vendingLanep = vendingLanepService.selectVendingLanepById(logid);
		mmap.put("vendingLanep", vendingLanep);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存售货机货道商品
	 */
	@RequiresPermissions("module:vendingLanep:edit")
	@Log(title = "售货机货道商品", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(VendingLanep vendingLanep)
	{		
		return toAjax(vendingLanepService.updateVendingLanep(vendingLanep));
	}
	
	/**
	 * 删除售货机货道商品
	 */
	@RequiresPermissions("module:vendingLanep:remove")
	@Log(title = "售货机货道商品", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(vendingLanepService.deleteVendingLanepByIds(ids));
	}
	
}
