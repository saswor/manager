package com.manage.project.module.orderBoxDetail.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.orderBoxDetail.mapper.OrderBoxDetailMapper;
import com.manage.project.module.orderBoxDetail.domain.OrderBoxDetail;
import com.manage.project.module.orderBoxDetail.service.IOrderBoxDetailService;
import com.manage.common.support.Convert;

/**
 * 订单商品出货统计基，主要为商品统计提供统计依据。 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class OrderBoxDetailServiceImpl implements IOrderBoxDetailService 
{
	@Autowired
	private OrderBoxDetailMapper orderBoxDetailMapper;

	/**
     * 查询订单商品出货统计基，主要为商品统计提供统计依据。信息
     * 
     * @param logid 订单商品出货统计基，主要为商品统计提供统计依据。ID
     * @return 订单商品出货统计基，主要为商品统计提供统计依据。信息
     */
    @Override
	public OrderBoxDetail selectOrderBoxDetailById(String logid)
	{
	    return orderBoxDetailMapper.selectOrderBoxDetailById(logid);
	}
	
	/**
     * 查询订单商品出货统计基，主要为商品统计提供统计依据。列表
     * 
     * @param orderBoxDetail 订单商品出货统计基，主要为商品统计提供统计依据。信息
     * @return 订单商品出货统计基，主要为商品统计提供统计依据。集合
     */
	@Override
	public List<OrderBoxDetail> selectOrderBoxDetailList(OrderBoxDetail orderBoxDetail)
	{
	    return orderBoxDetailMapper.selectOrderBoxDetailList(orderBoxDetail);
	}
	
    /**
     * 新增订单商品出货统计基，主要为商品统计提供统计依据。
     * 
     * @param orderBoxDetail 订单商品出货统计基，主要为商品统计提供统计依据。信息
     * @return 结果
     */
	@Override
	public int insertOrderBoxDetail(OrderBoxDetail orderBoxDetail)
	{
	    return orderBoxDetailMapper.insertOrderBoxDetail(orderBoxDetail);
	}
	
	/**
     * 修改订单商品出货统计基，主要为商品统计提供统计依据。
     * 
     * @param orderBoxDetail 订单商品出货统计基，主要为商品统计提供统计依据。信息
     * @return 结果
     */
	@Override
	public int updateOrderBoxDetail(OrderBoxDetail orderBoxDetail)
	{
	    return orderBoxDetailMapper.updateOrderBoxDetail(orderBoxDetail);
	}

	/**
     * 删除订单商品出货统计基，主要为商品统计提供统计依据。对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteOrderBoxDetailByIds(String ids)
	{
		return orderBoxDetailMapper.deleteOrderBoxDetailByIds(Convert.toStrArray(ids));
	}
	
}
