package com.manage.project.module.vendingCabinet.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.vendingCabinet.domain.VendingCabinet;
import com.manage.project.module.vendingCabinet.service.IVendingCabinetService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 售货机挂载的货柜，主柜的挂载副柜 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/vendingCabinet")
public class VendingCabinetController extends BaseController
{
    private String prefix = "module/vendingCabinet";
	
	@Autowired
	private IVendingCabinetService vendingCabinetService;
	
	@RequiresPermissions("module:vendingCabinet:view")
	@GetMapping()
	public String vendingCabinet()
	{
	    return prefix + "/vendingCabinet";
	}
	
	/**
	 * 查询售货机挂载的货柜，主柜的挂载副柜列表
	 */
	@RequiresPermissions("module:vendingCabinet:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(VendingCabinet vendingCabinet)
	{
		startPage();
        List<VendingCabinet> list = vendingCabinetService.selectVendingCabinetList(vendingCabinet);
		return getDataTable(list);
	}
	
	/**
	 * 新增售货机挂载的货柜，主柜的挂载副柜
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存售货机挂载的货柜，主柜的挂载副柜
	 */
	@RequiresPermissions("module:vendingCabinet:add")
	@Log(title = "售货机挂载的货柜，主柜的挂载副柜", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(VendingCabinet vendingCabinet)
	{		
		return toAjax(vendingCabinetService.insertVendingCabinet(vendingCabinet));
	}

	/**
	 * 修改售货机挂载的货柜，主柜的挂载副柜
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		VendingCabinet vendingCabinet = vendingCabinetService.selectVendingCabinetById(logid);
		mmap.put("vendingCabinet", vendingCabinet);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存售货机挂载的货柜，主柜的挂载副柜
	 */
	@RequiresPermissions("module:vendingCabinet:edit")
	@Log(title = "售货机挂载的货柜，主柜的挂载副柜", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(VendingCabinet vendingCabinet)
	{		
		return toAjax(vendingCabinetService.updateVendingCabinet(vendingCabinet));
	}
	
	/**
	 * 删除售货机挂载的货柜，主柜的挂载副柜
	 */
	@RequiresPermissions("module:vendingCabinet:remove")
	@Log(title = "售货机挂载的货柜，主柜的挂载副柜", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(vendingCabinetService.deleteVendingCabinetByIds(ids));
	}
	
}
