package com.manage.project.module.productInfo.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 记录商品表 as_product_info
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class ProductInfo extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 商品编号 */
	private String productId;
	/** 商品编码 */
	private String productCode;
	/** 商品名称 */
	private String name;
	/** 商品全名 */
	private String fullName;
	/** 分类编号 */
	private String typeId;
	/** 售卖价 */
	private Float salePrice;
	/** 过期时间(天) */
	private Integer validTime;
	/** 包装类型1:瓶装 2:灌装 3:袋装 4:盒装 5:杯装 */
	private String bagType;
	/** 图片json格式 */
	private String picJson;
	/** 生产厂家 */
	private String factoryName;
	/**  产品规格 格式:190g*24瓶/箱 */
	private String spec;
	/** 营养成分json 格式[{“nape”:”能量”,”every”:”每100ML”,”value”:”1mg”},…] */
	private String nutrition;
	/** 描述1 */
	private String desOne;
	/** 描述2 */
	private String desTwo;
	/** 描述3(图片地址，上传图片) */
	private String desThree;
	/** 托管公司编号 */
	private String corpId;
	/** 创建时间 */
	private String createTime;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setProductId(String productId) 
	{
		this.productId = productId;
	}

	public String getProductId() 
	{
		return productId;
	}
	public void setProductCode(String productCode) 
	{
		this.productCode = productCode;
	}

	public String getProductCode() 
	{
		return productCode;
	}
	public void setName(String name) 
	{
		this.name = name;
	}

	public String getName() 
	{
		return name;
	}
	public void setFullName(String fullName) 
	{
		this.fullName = fullName;
	}

	public String getFullName() 
	{
		return fullName;
	}
	public void setTypeId(String typeId) 
	{
		this.typeId = typeId;
	}

	public String getTypeId() 
	{
		return typeId;
	}
	public void setSalePrice(Float salePrice) 
	{
		this.salePrice = salePrice;
	}

	public Float getSalePrice() 
	{
		return salePrice;
	}
	public void setValidTime(Integer validTime) 
	{
		this.validTime = validTime;
	}

	public Integer getValidTime() 
	{
		return validTime;
	}
	public void setBagType(String bagType) 
	{
		this.bagType = bagType;
	}

	public String getBagType() 
	{
		return bagType;
	}
	public void setPicJson(String picJson) 
	{
		this.picJson = picJson;
	}

	public String getPicJson() 
	{
		return picJson;
	}
	public void setFactoryName(String factoryName) 
	{
		this.factoryName = factoryName;
	}

	public String getFactoryName() 
	{
		return factoryName;
	}
	public void setSpec(String spec) 
	{
		this.spec = spec;
	}

	public String getSpec() 
	{
		return spec;
	}
	public void setNutrition(String nutrition) 
	{
		this.nutrition = nutrition;
	}

	public String getNutrition() 
	{
		return nutrition;
	}
	public void setDesOne(String desOne) 
	{
		this.desOne = desOne;
	}

	public String getDesOne() 
	{
		return desOne;
	}
	public void setDesTwo(String desTwo) 
	{
		this.desTwo = desTwo;
	}

	public String getDesTwo() 
	{
		return desTwo;
	}
	public void setDesThree(String desThree) 
	{
		this.desThree = desThree;
	}

	public String getDesThree() 
	{
		return desThree;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("productId", getProductId())
            .append("productCode", getProductCode())
            .append("name", getName())
            .append("fullName", getFullName())
            .append("typeId", getTypeId())
            .append("salePrice", getSalePrice())
            .append("validTime", getValidTime())
            .append("bagType", getBagType())
            .append("picJson", getPicJson())
            .append("factoryName", getFactoryName())
            .append("spec", getSpec())
            .append("nutrition", getNutrition())
            .append("desOne", getDesOne())
            .append("desTwo", getDesTwo())
            .append("desThree", getDesThree())
            .append("corpId", getCorpId())
            .append("createTime", getCreateTime())
            .toString();
    }
}
