-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新', '3', '1', '/module/reportDsale', 'C', '0', 'module:reportDsale:view', '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新查询', @parentId, '1',  '#',  'F', '0', 'module:reportDsale:list',         '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');

insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新新增', @parentId, '2',  '#',  'F', '0', 'module:reportDsale:add',          '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');

insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新修改', @parentId, '3',  '#',  'F', '0', 'module:reportDsale:edit',         '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');

insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('每天销售统计情况，可从售货机时间段统计统计出来每隔一段时间统计一次，即时更新删除', @parentId, '4',  '#',  'F', '0', 'module:reportDsale:remove',       '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');
