package com.manage.project.module.vendingCmd.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.vendingCmd.domain.VendingCmd;
import com.manage.project.module.vendingCmd.service.IVendingCmdService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 售货机命令，按站点队列执行 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/vendingCmd")
public class VendingCmdController extends BaseController
{
    private String prefix = "module/vendingCmd";
	
	@Autowired
	private IVendingCmdService vendingCmdService;
	
	@RequiresPermissions("module:vendingCmd:view")
	@GetMapping()
	public String vendingCmd()
	{
	    return prefix + "/vendingCmd";
	}
	
	/**
	 * 查询售货机命令，按站点队列执行列表
	 */
	@RequiresPermissions("module:vendingCmd:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(VendingCmd vendingCmd)
	{
		startPage();
        List<VendingCmd> list = vendingCmdService.selectVendingCmdList(vendingCmd);
		return getDataTable(list);
	}
	
	/**
	 * 新增售货机命令，按站点队列执行
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存售货机命令，按站点队列执行
	 */
	@RequiresPermissions("module:vendingCmd:add")
	@Log(title = "售货机命令，按站点队列执行", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(VendingCmd vendingCmd)
	{		
		return toAjax(vendingCmdService.insertVendingCmd(vendingCmd));
	}

	/**
	 * 修改售货机命令，按站点队列执行
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		VendingCmd vendingCmd = vendingCmdService.selectVendingCmdById(logid);
		mmap.put("vendingCmd", vendingCmd);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存售货机命令，按站点队列执行
	 */
	@RequiresPermissions("module:vendingCmd:edit")
	@Log(title = "售货机命令，按站点队列执行", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(VendingCmd vendingCmd)
	{		
		return toAjax(vendingCmdService.updateVendingCmd(vendingCmd));
	}
	
	/**
	 * 删除售货机命令，按站点队列执行
	 */
	@RequiresPermissions("module:vendingCmd:remove")
	@Log(title = "售货机命令，按站点队列执行", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(vendingCmdService.deleteVendingCmdByIds(ids));
	}
	
}
