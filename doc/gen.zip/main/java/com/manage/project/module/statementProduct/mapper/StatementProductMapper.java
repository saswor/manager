package com.manage.project.module.statementProduct.mapper;

import com.manage.project.module.statementProduct.domain.StatementProduct;
import java.util.List;	

/**
 * 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。 数据层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface StatementProductMapper 
{
	/**
     * 查询补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。信息
     * 
     * @param logid 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。ID
     * @return 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。信息
     */
	public StatementProduct selectStatementProductById(String logid);
	
	/**
     * 查询补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。列表
     * 
     * @param statementProduct 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。信息
     * @return 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。集合
     */
	public List<StatementProduct> selectStatementProductList(StatementProduct statementProduct);
	
	/**
     * 新增补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。
     * 
     * @param statementProduct 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。信息
     * @return 结果
     */
	public int insertStatementProduct(StatementProduct statementProduct);
	
	/**
     * 修改补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。
     * 
     * @param statementProduct 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。信息
     * @return 结果
     */
	public int updateStatementProduct(StatementProduct statementProduct);
	
	/**
     * 删除补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。
     * 
     * @param logid 补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。ID
     * @return 结果
     */
	public int deleteStatementProductById(String logid);
	
	/**
     * 批量删除补货对账售出明细，此记录站点补货单中每个货道中每个商品的出库情况，可补货后自动生成商品，商品下架或购买后及时更新此。
     * 
     * @param logids 需要删除的数据ID
     * @return 结果
     */
	public int deleteStatementProductByIds(String[] logids);
	
}