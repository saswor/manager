package com.manage.project.module.orderBoxDetail.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 订单商品出货统计基，主要为商品统计提供统计依据。表 as_order_box_detail
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class OrderBoxDetail extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 详细编号 */
	private String detailId;
	/** 订单编号 */
	private String orderId;
	/** 售货机编号 */
	private String siteId;
	/** 地点名称 */
	private String siteName;
	/** 业主公司编号 */
	private String corpId;
	/** 货道号 */
	private String laneSId;
	/** 商品编号 */
	private String productId;
	/** 商品分类编号 */
	private String productTypeId;
	/** 商品采购价 */
	private Float buyPrice;
	/** 商品标准售价 */
	private Float salePrice;
	/** 商品支付价格 */
	private Float payPrice;
	/** 优惠金额(整机优惠采用平均法计算优惠以及支付价格) */
	private Float favPrice;
	/** 退款金额(现支持全额退款，采用平均法计算每件商品退款金额) */
	private Float returnPrice;
	/** 毛利 */
	private Float profitMoney;
	/** 出柜状态 1:未出柜(代表商品还在柜子中) 2:正常已出柜(代表商品已存放在出货口) 3:异常已出柜(货道出货失败可以另外货道代替出货) 4:出柜失败 */
	private String outState;
	/** 报表分钟(一天中的分钟数) */
	private Integer rptTime;
	/** 报表日期 */
	private String rptDate;
	/** 报表日期(交易日期) */
	private String rptDay;
	/** 报表周数 */
	private String rptWeek;
	/** 报表月份 */
	private String rptMonth;
	/** 报表年份 */
	private String rptYear;
	/** 创建时间 */
	private String createTime;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setDetailId(String detailId) 
	{
		this.detailId = detailId;
	}

	public String getDetailId() 
	{
		return detailId;
	}
	public void setOrderId(String orderId) 
	{
		this.orderId = orderId;
	}

	public String getOrderId() 
	{
		return orderId;
	}
	public void setSiteId(String siteId) 
	{
		this.siteId = siteId;
	}

	public String getSiteId() 
	{
		return siteId;
	}
	public void setSiteName(String siteName) 
	{
		this.siteName = siteName;
	}

	public String getSiteName() 
	{
		return siteName;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setLaneSId(String laneSId) 
	{
		this.laneSId = laneSId;
	}

	public String getLaneSId() 
	{
		return laneSId;
	}
	public void setProductId(String productId) 
	{
		this.productId = productId;
	}

	public String getProductId() 
	{
		return productId;
	}
	public void setProductTypeId(String productTypeId) 
	{
		this.productTypeId = productTypeId;
	}

	public String getProductTypeId() 
	{
		return productTypeId;
	}
	public void setBuyPrice(Float buyPrice) 
	{
		this.buyPrice = buyPrice;
	}

	public Float getBuyPrice() 
	{
		return buyPrice;
	}
	public void setSalePrice(Float salePrice) 
	{
		this.salePrice = salePrice;
	}

	public Float getSalePrice() 
	{
		return salePrice;
	}
	public void setPayPrice(Float payPrice) 
	{
		this.payPrice = payPrice;
	}

	public Float getPayPrice() 
	{
		return payPrice;
	}
	public void setFavPrice(Float favPrice) 
	{
		this.favPrice = favPrice;
	}

	public Float getFavPrice() 
	{
		return favPrice;
	}
	public void setReturnPrice(Float returnPrice) 
	{
		this.returnPrice = returnPrice;
	}

	public Float getReturnPrice() 
	{
		return returnPrice;
	}
	public void setProfitMoney(Float profitMoney) 
	{
		this.profitMoney = profitMoney;
	}

	public Float getProfitMoney() 
	{
		return profitMoney;
	}
	public void setOutState(String outState) 
	{
		this.outState = outState;
	}

	public String getOutState() 
	{
		return outState;
	}
	public void setRptTime(Integer rptTime) 
	{
		this.rptTime = rptTime;
	}

	public Integer getRptTime() 
	{
		return rptTime;
	}
	public void setRptDate(String rptDate) 
	{
		this.rptDate = rptDate;
	}

	public String getRptDate() 
	{
		return rptDate;
	}
	public void setRptDay(String rptDay) 
	{
		this.rptDay = rptDay;
	}

	public String getRptDay() 
	{
		return rptDay;
	}
	public void setRptWeek(String rptWeek) 
	{
		this.rptWeek = rptWeek;
	}

	public String getRptWeek() 
	{
		return rptWeek;
	}
	public void setRptMonth(String rptMonth) 
	{
		this.rptMonth = rptMonth;
	}

	public String getRptMonth() 
	{
		return rptMonth;
	}
	public void setRptYear(String rptYear) 
	{
		this.rptYear = rptYear;
	}

	public String getRptYear() 
	{
		return rptYear;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("detailId", getDetailId())
            .append("orderId", getOrderId())
            .append("siteId", getSiteId())
            .append("siteName", getSiteName())
            .append("corpId", getCorpId())
            .append("laneSId", getLaneSId())
            .append("productId", getProductId())
            .append("productTypeId", getProductTypeId())
            .append("buyPrice", getBuyPrice())
            .append("salePrice", getSalePrice())
            .append("payPrice", getPayPrice())
            .append("favPrice", getFavPrice())
            .append("returnPrice", getReturnPrice())
            .append("profitMoney", getProfitMoney())
            .append("outState", getOutState())
            .append("rptTime", getRptTime())
            .append("rptDate", getRptDate())
            .append("rptDay", getRptDay())
            .append("rptWeek", getRptWeek())
            .append("rptMonth", getRptMonth())
            .append("rptYear", getRptYear())
            .append("createTime", getCreateTime())
            .toString();
    }
}
