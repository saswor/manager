package com.manage.project.module.statementBalance.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.statementBalance.mapper.StatementBalanceMapper;
import com.manage.project.module.statementBalance.domain.StatementBalance;
import com.manage.project.module.statementBalance.service.IStatementBalanceService;
import com.manage.common.support.Convert;

/**
 * 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class StatementBalanceServiceImpl implements IStatementBalanceService 
{
	@Autowired
	private StatementBalanceMapper statementBalanceMapper;

	/**
     * 查询根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。信息
     * 
     * @param logid 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。ID
     * @return 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。信息
     */
    @Override
	public StatementBalance selectStatementBalanceById(String logid)
	{
	    return statementBalanceMapper.selectStatementBalanceById(logid);
	}
	
	/**
     * 查询根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。列表
     * 
     * @param statementBalance 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。信息
     * @return 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。集合
     */
	@Override
	public List<StatementBalance> selectStatementBalanceList(StatementBalance statementBalance)
	{
	    return statementBalanceMapper.selectStatementBalanceList(statementBalance);
	}
	
    /**
     * 新增根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。
     * 
     * @param statementBalance 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。信息
     * @return 结果
     */
	@Override
	public int insertStatementBalance(StatementBalance statementBalance)
	{
	    return statementBalanceMapper.insertStatementBalance(statementBalance);
	}
	
	/**
     * 修改根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。
     * 
     * @param statementBalance 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。信息
     * @return 结果
     */
	@Override
	public int updateStatementBalance(StatementBalance statementBalance)
	{
	    return statementBalanceMapper.updateStatementBalance(statementBalance);
	}

	/**
     * 删除根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteStatementBalanceByIds(String ids)
	{
		return statementBalanceMapper.deleteStatementBalanceByIds(Convert.toStrArray(ids));
	}
	
}
