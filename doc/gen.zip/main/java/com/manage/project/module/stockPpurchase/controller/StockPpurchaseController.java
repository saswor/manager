package com.manage.project.module.stockPpurchase.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.stockPpurchase.domain.StockPpurchase;
import com.manage.project.module.stockPpurchase.service.IStockPpurchaseService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 仓库采购记录 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/stockPpurchase")
public class StockPpurchaseController extends BaseController
{
    private String prefix = "module/stockPpurchase";
	
	@Autowired
	private IStockPpurchaseService stockPpurchaseService;
	
	@RequiresPermissions("module:stockPpurchase:view")
	@GetMapping()
	public String stockPpurchase()
	{
	    return prefix + "/stockPpurchase";
	}
	
	/**
	 * 查询仓库采购记录列表
	 */
	@RequiresPermissions("module:stockPpurchase:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(StockPpurchase stockPpurchase)
	{
		startPage();
        List<StockPpurchase> list = stockPpurchaseService.selectStockPpurchaseList(stockPpurchase);
		return getDataTable(list);
	}
	
	/**
	 * 新增仓库采购记录
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存仓库采购记录
	 */
	@RequiresPermissions("module:stockPpurchase:add")
	@Log(title = "仓库采购记录", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(StockPpurchase stockPpurchase)
	{		
		return toAjax(stockPpurchaseService.insertStockPpurchase(stockPpurchase));
	}

	/**
	 * 修改仓库采购记录
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		StockPpurchase stockPpurchase = stockPpurchaseService.selectStockPpurchaseById(logid);
		mmap.put("stockPpurchase", stockPpurchase);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存仓库采购记录
	 */
	@RequiresPermissions("module:stockPpurchase:edit")
	@Log(title = "仓库采购记录", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(StockPpurchase stockPpurchase)
	{		
		return toAjax(stockPpurchaseService.updateStockPpurchase(stockPpurchase));
	}
	
	/**
	 * 删除仓库采购记录
	 */
	@RequiresPermissions("module:stockPpurchase:remove")
	@Log(title = "仓库采购记录", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(stockPpurchaseService.deleteStockPpurchaseByIds(ids));
	}
	
}
