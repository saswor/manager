package com.manage.project.module.stockPurchase.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 仓库采购记录表 as_stock_purchase
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class StockPurchase extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 仓采购记录编号 */
	private String wPurchaseId;
	/** 仓库编号 */
	private String stockId;
	/** 仓库名称 */
	private String stokcName;
	/** 商品编号 */
	private String productId;
	/** 商品名称 */
	private String productName;
	/** 总采购数量 */
	private Integer pNum;
	/** 采购商品种类数 */
	private Integer tNum;
	/** 总采购价 */
	private Float totalPrice;
	/** 采购状态 1:正常 2:删除 */
	private String curState;
	/** 采购状态变化时间 */
	private String stateTime;
	/** 审核状态 1:未审核 2:审核通过 3:审核失败 */
	private String checkState;
	/** 审核状态变化时间 */
	private String checkTime;
	/** 审核人编号 */
	private String checkId;
	/** 库存状态 1:未入库 2:已入库 */
	private String stockState;
	/** 库存状态变化时间 */
	private String stockSTime;
	/** 描述 */
	private String description;
	/** 托管公司编号 */
	private String corpId;
	/** 创建时间 */
	private String createTime;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setWPurchaseId(String wPurchaseId) 
	{
		this.wPurchaseId = wPurchaseId;
	}

	public String getWPurchaseId() 
	{
		return wPurchaseId;
	}
	public void setStockId(String stockId) 
	{
		this.stockId = stockId;
	}

	public String getStockId() 
	{
		return stockId;
	}
	public void setStokcName(String stokcName) 
	{
		this.stokcName = stokcName;
	}

	public String getStokcName() 
	{
		return stokcName;
	}
	public void setProductId(String productId) 
	{
		this.productId = productId;
	}

	public String getProductId() 
	{
		return productId;
	}
	public void setProductName(String productName) 
	{
		this.productName = productName;
	}

	public String getProductName() 
	{
		return productName;
	}
	public void setPNum(Integer pNum) 
	{
		this.pNum = pNum;
	}

	public Integer getPNum() 
	{
		return pNum;
	}
	public void setTNum(Integer tNum) 
	{
		this.tNum = tNum;
	}

	public Integer getTNum() 
	{
		return tNum;
	}
	public void setTotalPrice(Float totalPrice) 
	{
		this.totalPrice = totalPrice;
	}

	public Float getTotalPrice() 
	{
		return totalPrice;
	}
	public void setCurState(String curState) 
	{
		this.curState = curState;
	}

	public String getCurState() 
	{
		return curState;
	}
	public void setStateTime(String stateTime) 
	{
		this.stateTime = stateTime;
	}

	public String getStateTime() 
	{
		return stateTime;
	}
	public void setCheckState(String checkState) 
	{
		this.checkState = checkState;
	}

	public String getCheckState() 
	{
		return checkState;
	}
	public void setCheckTime(String checkTime) 
	{
		this.checkTime = checkTime;
	}

	public String getCheckTime() 
	{
		return checkTime;
	}
	public void setCheckId(String checkId) 
	{
		this.checkId = checkId;
	}

	public String getCheckId() 
	{
		return checkId;
	}
	public void setStockState(String stockState) 
	{
		this.stockState = stockState;
	}

	public String getStockState() 
	{
		return stockState;
	}
	public void setStockSTime(String stockSTime) 
	{
		this.stockSTime = stockSTime;
	}

	public String getStockSTime() 
	{
		return stockSTime;
	}
	public void setDescription(String description) 
	{
		this.description = description;
	}

	public String getDescription() 
	{
		return description;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("wPurchaseId", getWPurchaseId())
            .append("stockId", getStockId())
            .append("stokcName", getStokcName())
            .append("productId", getProductId())
            .append("productName", getProductName())
            .append("pNum", getPNum())
            .append("tNum", getTNum())
            .append("totalPrice", getTotalPrice())
            .append("curState", getCurState())
            .append("stateTime", getStateTime())
            .append("checkState", getCheckState())
            .append("checkTime", getCheckTime())
            .append("checkId", getCheckId())
            .append("stockState", getStockState())
            .append("stockSTime", getStockSTime())
            .append("description", getDescription())
            .append("corpId", getCorpId())
            .append("createTime", getCreateTime())
            .toString();
    }
}
