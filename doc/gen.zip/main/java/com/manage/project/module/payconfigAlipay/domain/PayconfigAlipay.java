package com.manage.project.module.payconfigAlipay.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 微信支付配置表 as_payconfig_alipay
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class PayconfigAlipay extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 配置编号 */
	private String payConfigId;
	/** 是否开启 1:是 2:否 */
	private String payAccept;
	/** 公司编号 */
	private String corpId;
	/** 自动退款 1:支持 2:否 */
	private String autoReturn;
	/** 支付方式 1:扫码支付 2:生活号支付 */
	private String payType;
	/** 支付宝版本 1:1.0 2:2.0 */
	private String alipayVersion;
	/** 加密方式1:rsa 2:rsa2 */
	private String enType;
	/** pid */
	private String pid;
	/** 支付宝密匙 */
	private String key;
	/** 是否入住 1:是 2:否 */
	private String isCheckIn;
	/** 费率% */
	private Integer rate;
	/** 创建时间 */
	private String createTime;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setPayConfigId(String payConfigId) 
	{
		this.payConfigId = payConfigId;
	}

	public String getPayConfigId() 
	{
		return payConfigId;
	}
	public void setPayAccept(String payAccept) 
	{
		this.payAccept = payAccept;
	}

	public String getPayAccept() 
	{
		return payAccept;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setAutoReturn(String autoReturn) 
	{
		this.autoReturn = autoReturn;
	}

	public String getAutoReturn() 
	{
		return autoReturn;
	}
	public void setPayType(String payType) 
	{
		this.payType = payType;
	}

	public String getPayType() 
	{
		return payType;
	}
	public void setAlipayVersion(String alipayVersion) 
	{
		this.alipayVersion = alipayVersion;
	}

	public String getAlipayVersion() 
	{
		return alipayVersion;
	}
	public void setEnType(String enType) 
	{
		this.enType = enType;
	}

	public String getEnType() 
	{
		return enType;
	}
	public void setPid(String pid) 
	{
		this.pid = pid;
	}

	public String getPid() 
	{
		return pid;
	}
	public void setKey(String key) 
	{
		this.key = key;
	}

	public String getKey() 
	{
		return key;
	}
	public void setIsCheckIn(String isCheckIn) 
	{
		this.isCheckIn = isCheckIn;
	}

	public String getIsCheckIn() 
	{
		return isCheckIn;
	}
	public void setRate(Integer rate) 
	{
		this.rate = rate;
	}

	public Integer getRate() 
	{
		return rate;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("payConfigId", getPayConfigId())
            .append("payAccept", getPayAccept())
            .append("corpId", getCorpId())
            .append("autoReturn", getAutoReturn())
            .append("payType", getPayType())
            .append("alipayVersion", getAlipayVersion())
            .append("enType", getEnType())
            .append("pid", getPid())
            .append("key", getKey())
            .append("isCheckIn", getIsCheckIn())
            .append("rate", getRate())
            .append("createTime", getCreateTime())
            .toString();
    }
}
