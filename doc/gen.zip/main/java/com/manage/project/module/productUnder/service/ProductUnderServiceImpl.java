package com.manage.project.module.productUnder.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.productUnder.mapper.ProductUnderMapper;
import com.manage.project.module.productUnder.domain.ProductUnder;
import com.manage.project.module.productUnder.service.IProductUnderService;
import com.manage.common.support.Convert;

/**
 * 商品下架 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class ProductUnderServiceImpl implements IProductUnderService 
{
	@Autowired
	private ProductUnderMapper productUnderMapper;

	/**
     * 查询商品下架信息
     * 
     * @param logid 商品下架ID
     * @return 商品下架信息
     */
    @Override
	public ProductUnder selectProductUnderById(String logid)
	{
	    return productUnderMapper.selectProductUnderById(logid);
	}
	
	/**
     * 查询商品下架列表
     * 
     * @param productUnder 商品下架信息
     * @return 商品下架集合
     */
	@Override
	public List<ProductUnder> selectProductUnderList(ProductUnder productUnder)
	{
	    return productUnderMapper.selectProductUnderList(productUnder);
	}
	
    /**
     * 新增商品下架
     * 
     * @param productUnder 商品下架信息
     * @return 结果
     */
	@Override
	public int insertProductUnder(ProductUnder productUnder)
	{
	    return productUnderMapper.insertProductUnder(productUnder);
	}
	
	/**
     * 修改商品下架
     * 
     * @param productUnder 商品下架信息
     * @return 结果
     */
	@Override
	public int updateProductUnder(ProductUnder productUnder)
	{
	    return productUnderMapper.updateProductUnder(productUnder);
	}

	/**
     * 删除商品下架对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteProductUnderByIds(String ids)
	{
		return productUnderMapper.deleteProductUnderByIds(Convert.toStrArray(ids));
	}
	
}
