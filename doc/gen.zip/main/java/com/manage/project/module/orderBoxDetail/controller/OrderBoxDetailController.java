package com.manage.project.module.orderBoxDetail.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.orderBoxDetail.domain.OrderBoxDetail;
import com.manage.project.module.orderBoxDetail.service.IOrderBoxDetailService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 订单商品出货统计基，主要为商品统计提供统计依据。 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/orderBoxDetail")
public class OrderBoxDetailController extends BaseController
{
    private String prefix = "module/orderBoxDetail";
	
	@Autowired
	private IOrderBoxDetailService orderBoxDetailService;
	
	@RequiresPermissions("module:orderBoxDetail:view")
	@GetMapping()
	public String orderBoxDetail()
	{
	    return prefix + "/orderBoxDetail";
	}
	
	/**
	 * 查询订单商品出货统计基，主要为商品统计提供统计依据。列表
	 */
	@RequiresPermissions("module:orderBoxDetail:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(OrderBoxDetail orderBoxDetail)
	{
		startPage();
        List<OrderBoxDetail> list = orderBoxDetailService.selectOrderBoxDetailList(orderBoxDetail);
		return getDataTable(list);
	}
	
	/**
	 * 新增订单商品出货统计基，主要为商品统计提供统计依据。
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存订单商品出货统计基，主要为商品统计提供统计依据。
	 */
	@RequiresPermissions("module:orderBoxDetail:add")
	@Log(title = "订单商品出货统计基，主要为商品统计提供统计依据。", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(OrderBoxDetail orderBoxDetail)
	{		
		return toAjax(orderBoxDetailService.insertOrderBoxDetail(orderBoxDetail));
	}

	/**
	 * 修改订单商品出货统计基，主要为商品统计提供统计依据。
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		OrderBoxDetail orderBoxDetail = orderBoxDetailService.selectOrderBoxDetailById(logid);
		mmap.put("orderBoxDetail", orderBoxDetail);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存订单商品出货统计基，主要为商品统计提供统计依据。
	 */
	@RequiresPermissions("module:orderBoxDetail:edit")
	@Log(title = "订单商品出货统计基，主要为商品统计提供统计依据。", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(OrderBoxDetail orderBoxDetail)
	{		
		return toAjax(orderBoxDetailService.updateOrderBoxDetail(orderBoxDetail));
	}
	
	/**
	 * 删除订单商品出货统计基，主要为商品统计提供统计依据。
	 */
	@RequiresPermissions("module:orderBoxDetail:remove")
	@Log(title = "订单商品出货统计基，主要为商品统计提供统计依据。", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(orderBoxDetailService.deleteOrderBoxDetailByIds(ids));
	}
	
}
