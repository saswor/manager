package com.manage.project.module.statementBalance.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.statementBalance.domain.StatementBalance;
import com.manage.project.module.statementBalance.service.IStatementBalanceService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/statementBalance")
public class StatementBalanceController extends BaseController
{
    private String prefix = "module/statementBalance";
	
	@Autowired
	private IStatementBalanceService statementBalanceService;
	
	@RequiresPermissions("module:statementBalance:view")
	@GetMapping()
	public String statementBalance()
	{
	    return prefix + "/statementBalance";
	}
	
	/**
	 * 查询根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。列表
	 */
	@RequiresPermissions("module:statementBalance:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(StatementBalance statementBalance)
	{
		startPage();
        List<StatementBalance> list = statementBalanceService.selectStatementBalanceList(statementBalance);
		return getDataTable(list);
	}
	
	/**
	 * 新增根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。
	 */
	@RequiresPermissions("module:statementBalance:add")
	@Log(title = "根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(StatementBalance statementBalance)
	{		
		return toAjax(statementBalanceService.insertStatementBalance(statementBalance));
	}

	/**
	 * 修改根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		StatementBalance statementBalance = statementBalanceService.selectStatementBalanceById(logid);
		mmap.put("statementBalance", statementBalance);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。
	 */
	@RequiresPermissions("module:statementBalance:edit")
	@Log(title = "根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(StatementBalance statementBalance)
	{		
		return toAjax(statementBalanceService.updateStatementBalance(statementBalance));
	}
	
	/**
	 * 删除根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。
	 */
	@RequiresPermissions("module:statementBalance:remove")
	@Log(title = "根据补货账单里提交后生成结算费用,此结算是针对于采购人员的，区域下的负责人。", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(statementBalanceService.deleteStatementBalanceByIds(ids));
	}
	
}
