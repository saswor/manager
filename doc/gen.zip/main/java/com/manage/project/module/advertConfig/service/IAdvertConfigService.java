package com.manage.project.module.advertConfig.service;

import com.manage.project.module.advertConfig.domain.AdvertConfig;
import java.util.List;

/**
 * 广告配置 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IAdvertConfigService 
{
	/**
     * 查询广告配置信息
     * 
     * @param logid 广告配置ID
     * @return 广告配置信息
     */
	public AdvertConfig selectAdvertConfigById(String logid);
	
	/**
     * 查询广告配置列表
     * 
     * @param advertConfig 广告配置信息
     * @return 广告配置集合
     */
	public List<AdvertConfig> selectAdvertConfigList(AdvertConfig advertConfig);
	
	/**
     * 新增广告配置
     * 
     * @param advertConfig 广告配置信息
     * @return 结果
     */
	public int insertAdvertConfig(AdvertConfig advertConfig);
	
	/**
     * 修改广告配置
     * 
     * @param advertConfig 广告配置信息
     * @return 结果
     */
	public int updateAdvertConfig(AdvertConfig advertConfig);
		
	/**
     * 删除广告配置信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteAdvertConfigByIds(String ids);
	
}
