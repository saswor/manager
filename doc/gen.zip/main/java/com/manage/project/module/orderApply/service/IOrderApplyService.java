package com.manage.project.module.orderApply.service;

import com.manage.project.module.orderApply.domain.OrderApply;
import java.util.List;

/**
 * 记录客户购买的商品 服务层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface IOrderApplyService 
{
	/**
     * 查询记录客户购买的商品信息
     * 
     * @param logid 记录客户购买的商品ID
     * @return 记录客户购买的商品信息
     */
	public OrderApply selectOrderApplyById(String logid);
	
	/**
     * 查询记录客户购买的商品列表
     * 
     * @param orderApply 记录客户购买的商品信息
     * @return 记录客户购买的商品集合
     */
	public List<OrderApply> selectOrderApplyList(OrderApply orderApply);
	
	/**
     * 新增记录客户购买的商品
     * 
     * @param orderApply 记录客户购买的商品信息
     * @return 结果
     */
	public int insertOrderApply(OrderApply orderApply);
	
	/**
     * 修改记录客户购买的商品
     * 
     * @param orderApply 记录客户购买的商品信息
     * @return 结果
     */
	public int updateOrderApply(OrderApply orderApply);
		
	/**
     * 删除记录客户购买的商品信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOrderApplyByIds(String ids);
	
}
