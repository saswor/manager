package com.manage.project.module.vendingPconfig.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.vendingPconfig.mapper.VendingPconfigMapper;
import com.manage.project.module.vendingPconfig.domain.VendingPconfig;
import com.manage.project.module.vendingPconfig.service.IVendingPconfigService;
import com.manage.common.support.Convert;

/**
 * 售货机配货模板 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class VendingPconfigServiceImpl implements IVendingPconfigService 
{
	@Autowired
	private VendingPconfigMapper vendingPconfigMapper;

	/**
     * 查询售货机配货模板信息
     * 
     * @param logid 售货机配货模板ID
     * @return 售货机配货模板信息
     */
    @Override
	public VendingPconfig selectVendingPconfigById(String logid)
	{
	    return vendingPconfigMapper.selectVendingPconfigById(logid);
	}
	
	/**
     * 查询售货机配货模板列表
     * 
     * @param vendingPconfig 售货机配货模板信息
     * @return 售货机配货模板集合
     */
	@Override
	public List<VendingPconfig> selectVendingPconfigList(VendingPconfig vendingPconfig)
	{
	    return vendingPconfigMapper.selectVendingPconfigList(vendingPconfig);
	}
	
    /**
     * 新增售货机配货模板
     * 
     * @param vendingPconfig 售货机配货模板信息
     * @return 结果
     */
	@Override
	public int insertVendingPconfig(VendingPconfig vendingPconfig)
	{
	    return vendingPconfigMapper.insertVendingPconfig(vendingPconfig);
	}
	
	/**
     * 修改售货机配货模板
     * 
     * @param vendingPconfig 售货机配货模板信息
     * @return 结果
     */
	@Override
	public int updateVendingPconfig(VendingPconfig vendingPconfig)
	{
	    return vendingPconfigMapper.updateVendingPconfig(vendingPconfig);
	}

	/**
     * 删除售货机配货模板对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteVendingPconfigByIds(String ids)
	{
		return vendingPconfigMapper.deleteVendingPconfigByIds(Convert.toStrArray(ids));
	}
	
}
