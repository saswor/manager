package com.manage.project.module.orderProduct.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 记录客户购买的商品表 as_order_product
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class OrderProduct extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 订单商品编号 */
	private String prodetailId;
	/** 公司编号 */
	private String corpId;
	/** 订单编号 */
	private String orderId;
	/** 终端订单编号 */
	private String torderId;
	/** 商品编号 */
	private String productId;
	/** 商品名称 */
	private String productName;
	/** 商品分类编号 */
	private String productTypeId;
	/** 生产厂家 */
	private String factoryId;
	/** 商品售卖价 */
	private Float normalPrice;
	/** 支付单价 */
	private Float salePrice;
	/** 售卖数量 */
	private Integer saleNum;
	/** 出库数量 */
	private Integer outNum;
	/** 回收数量 */
	private Integer reNum;
	/** 创建时间 */
	private String createTime;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setProdetailId(String prodetailId) 
	{
		this.prodetailId = prodetailId;
	}

	public String getProdetailId() 
	{
		return prodetailId;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setOrderId(String orderId) 
	{
		this.orderId = orderId;
	}

	public String getOrderId() 
	{
		return orderId;
	}
	public void setTorderId(String torderId) 
	{
		this.torderId = torderId;
	}

	public String getTorderId() 
	{
		return torderId;
	}
	public void setProductId(String productId) 
	{
		this.productId = productId;
	}

	public String getProductId() 
	{
		return productId;
	}
	public void setProductName(String productName) 
	{
		this.productName = productName;
	}

	public String getProductName() 
	{
		return productName;
	}
	public void setProductTypeId(String productTypeId) 
	{
		this.productTypeId = productTypeId;
	}

	public String getProductTypeId() 
	{
		return productTypeId;
	}
	public void setFactoryId(String factoryId) 
	{
		this.factoryId = factoryId;
	}

	public String getFactoryId() 
	{
		return factoryId;
	}
	public void setNormalPrice(Float normalPrice) 
	{
		this.normalPrice = normalPrice;
	}

	public Float getNormalPrice() 
	{
		return normalPrice;
	}
	public void setSalePrice(Float salePrice) 
	{
		this.salePrice = salePrice;
	}

	public Float getSalePrice() 
	{
		return salePrice;
	}
	public void setSaleNum(Integer saleNum) 
	{
		this.saleNum = saleNum;
	}

	public Integer getSaleNum() 
	{
		return saleNum;
	}
	public void setOutNum(Integer outNum) 
	{
		this.outNum = outNum;
	}

	public Integer getOutNum() 
	{
		return outNum;
	}
	public void setReNum(Integer reNum) 
	{
		this.reNum = reNum;
	}

	public Integer getReNum() 
	{
		return reNum;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("prodetailId", getProdetailId())
            .append("corpId", getCorpId())
            .append("orderId", getOrderId())
            .append("torderId", getTorderId())
            .append("productId", getProductId())
            .append("productName", getProductName())
            .append("productTypeId", getProductTypeId())
            .append("factoryId", getFactoryId())
            .append("normalPrice", getNormalPrice())
            .append("salePrice", getSalePrice())
            .append("saleNum", getSaleNum())
            .append("outNum", getOutNum())
            .append("reNum", getReNum())
            .append("createTime", getCreateTime())
            .toString();
    }
}
