package com.manage.project.module.vendingCmd.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.manage.project.module.vendingCmd.mapper.VendingCmdMapper;
import com.manage.project.module.vendingCmd.domain.VendingCmd;
import com.manage.project.module.vendingCmd.service.IVendingCmdService;
import com.manage.common.support.Convert;

/**
 * 售货机命令，按站点队列执行 服务层实现
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Service
public class VendingCmdServiceImpl implements IVendingCmdService 
{
	@Autowired
	private VendingCmdMapper vendingCmdMapper;

	/**
     * 查询售货机命令，按站点队列执行信息
     * 
     * @param logid 售货机命令，按站点队列执行ID
     * @return 售货机命令，按站点队列执行信息
     */
    @Override
	public VendingCmd selectVendingCmdById(String logid)
	{
	    return vendingCmdMapper.selectVendingCmdById(logid);
	}
	
	/**
     * 查询售货机命令，按站点队列执行列表
     * 
     * @param vendingCmd 售货机命令，按站点队列执行信息
     * @return 售货机命令，按站点队列执行集合
     */
	@Override
	public List<VendingCmd> selectVendingCmdList(VendingCmd vendingCmd)
	{
	    return vendingCmdMapper.selectVendingCmdList(vendingCmd);
	}
	
    /**
     * 新增售货机命令，按站点队列执行
     * 
     * @param vendingCmd 售货机命令，按站点队列执行信息
     * @return 结果
     */
	@Override
	public int insertVendingCmd(VendingCmd vendingCmd)
	{
	    return vendingCmdMapper.insertVendingCmd(vendingCmd);
	}
	
	/**
     * 修改售货机命令，按站点队列执行
     * 
     * @param vendingCmd 售货机命令，按站点队列执行信息
     * @return 结果
     */
	@Override
	public int updateVendingCmd(VendingCmd vendingCmd)
	{
	    return vendingCmdMapper.updateVendingCmd(vendingCmd);
	}

	/**
     * 删除售货机命令，按站点队列执行对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteVendingCmdByIds(String ids)
	{
		return vendingCmdMapper.deleteVendingCmdByIds(Convert.toStrArray(ids));
	}
	
}
