package com.manage.project.module.vendingDistrict.mapper;

import com.manage.project.module.vendingDistrict.domain.VendingDistrict;
import java.util.List;	

/**
 * 管理线路的区域 数据层
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public interface VendingDistrictMapper 
{
	/**
     * 查询管理线路的区域信息
     * 
     * @param logid 管理线路的区域ID
     * @return 管理线路的区域信息
     */
	public VendingDistrict selectVendingDistrictById(String logid);
	
	/**
     * 查询管理线路的区域列表
     * 
     * @param vendingDistrict 管理线路的区域信息
     * @return 管理线路的区域集合
     */
	public List<VendingDistrict> selectVendingDistrictList(VendingDistrict vendingDistrict);
	
	/**
     * 新增管理线路的区域
     * 
     * @param vendingDistrict 管理线路的区域信息
     * @return 结果
     */
	public int insertVendingDistrict(VendingDistrict vendingDistrict);
	
	/**
     * 修改管理线路的区域
     * 
     * @param vendingDistrict 管理线路的区域信息
     * @return 结果
     */
	public int updateVendingDistrict(VendingDistrict vendingDistrict);
	
	/**
     * 删除管理线路的区域
     * 
     * @param logid 管理线路的区域ID
     * @return 结果
     */
	public int deleteVendingDistrictById(String logid);
	
	/**
     * 批量删除管理线路的区域
     * 
     * @param logids 需要删除的数据ID
     * @return 结果
     */
	public int deleteVendingDistrictByIds(String[] logids);
	
}