package com.manage.project.module.supplyVproduct.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.supplyVproduct.domain.SupplyVproduct;
import com.manage.project.module.supplyVproduct.service.ISupplyVproductService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 补货站点需要补货的货道商品，根据流水可检查商品的过期时间 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/supplyVproduct")
public class SupplyVproductController extends BaseController
{
    private String prefix = "module/supplyVproduct";
	
	@Autowired
	private ISupplyVproductService supplyVproductService;
	
	@RequiresPermissions("module:supplyVproduct:view")
	@GetMapping()
	public String supplyVproduct()
	{
	    return prefix + "/supplyVproduct";
	}
	
	/**
	 * 查询补货站点需要补货的货道商品，根据流水可检查商品的过期时间列表
	 */
	@RequiresPermissions("module:supplyVproduct:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(SupplyVproduct supplyVproduct)
	{
		startPage();
        List<SupplyVproduct> list = supplyVproductService.selectSupplyVproductList(supplyVproduct);
		return getDataTable(list);
	}
	
	/**
	 * 新增补货站点需要补货的货道商品，根据流水可检查商品的过期时间
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存补货站点需要补货的货道商品，根据流水可检查商品的过期时间
	 */
	@RequiresPermissions("module:supplyVproduct:add")
	@Log(title = "补货站点需要补货的货道商品，根据流水可检查商品的过期时间", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(SupplyVproduct supplyVproduct)
	{		
		return toAjax(supplyVproductService.insertSupplyVproduct(supplyVproduct));
	}

	/**
	 * 修改补货站点需要补货的货道商品，根据流水可检查商品的过期时间
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		SupplyVproduct supplyVproduct = supplyVproductService.selectSupplyVproductById(logid);
		mmap.put("supplyVproduct", supplyVproduct);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存补货站点需要补货的货道商品，根据流水可检查商品的过期时间
	 */
	@RequiresPermissions("module:supplyVproduct:edit")
	@Log(title = "补货站点需要补货的货道商品，根据流水可检查商品的过期时间", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(SupplyVproduct supplyVproduct)
	{		
		return toAjax(supplyVproductService.updateSupplyVproduct(supplyVproduct));
	}
	
	/**
	 * 删除补货站点需要补货的货道商品，根据流水可检查商品的过期时间
	 */
	@RequiresPermissions("module:supplyVproduct:remove")
	@Log(title = "补货站点需要补货的货道商品，根据流水可检查商品的过期时间", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(supplyVproductService.deleteSupplyVproductByIds(ids));
	}
	
}
