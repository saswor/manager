package com.manage.project.module.vending.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.vending.domain.Vending;
import com.manage.project.module.vending.service.IVendingService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 售货机的基本，主柜 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/vending")
public class VendingController extends BaseController
{
    private String prefix = "module/vending";
	
	@Autowired
	private IVendingService vendingService;
	
	@RequiresPermissions("module:vending:view")
	@GetMapping()
	public String vending()
	{
	    return prefix + "/vending";
	}
	
	/**
	 * 查询售货机的基本，主柜列表
	 */
	@RequiresPermissions("module:vending:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(Vending vending)
	{
		startPage();
        List<Vending> list = vendingService.selectVendingList(vending);
		return getDataTable(list);
	}
	
	/**
	 * 新增售货机的基本，主柜
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存售货机的基本，主柜
	 */
	@RequiresPermissions("module:vending:add")
	@Log(title = "售货机的基本，主柜", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(Vending vending)
	{		
		return toAjax(vendingService.insertVending(vending));
	}

	/**
	 * 修改售货机的基本，主柜
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		Vending vending = vendingService.selectVendingById(logid);
		mmap.put("vending", vending);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存售货机的基本，主柜
	 */
	@RequiresPermissions("module:vending:edit")
	@Log(title = "售货机的基本，主柜", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(Vending vending)
	{		
		return toAjax(vendingService.updateVending(vending));
	}
	
	/**
	 * 删除售货机的基本，主柜
	 */
	@RequiresPermissions("module:vending:remove")
	@Log(title = "售货机的基本，主柜", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(vendingService.deleteVendingByIds(ids));
	}
	
}
