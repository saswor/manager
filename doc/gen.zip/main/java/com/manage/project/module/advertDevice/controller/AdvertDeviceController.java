package com.manage.project.module.advertDevice.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.manage.framework.aspectj.lang.annotation.Log;
import com.manage.framework.aspectj.lang.constant.BusinessType;
import com.manage.project.module.advertDevice.domain.AdvertDevice;
import com.manage.project.module.advertDevice.service.IAdvertDeviceService;
import com.manage.framework.web.controller.BaseController;
import com.manage.framework.web.page.TableDataInfo;
import com.manage.framework.web.domain.AjaxResult;

/**
 * 广告播放对象设置，也叫播放任务列 信息操作处理
 * 
 * @author xufeng
 * @date 2018-09-02
 */
@Controller
@RequestMapping("/module/advertDevice")
public class AdvertDeviceController extends BaseController
{
    private String prefix = "module/advertDevice";
	
	@Autowired
	private IAdvertDeviceService advertDeviceService;
	
	@RequiresPermissions("module:advertDevice:view")
	@GetMapping()
	public String advertDevice()
	{
	    return prefix + "/advertDevice";
	}
	
	/**
	 * 查询广告播放对象设置，也叫播放任务列列表
	 */
	@RequiresPermissions("module:advertDevice:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(AdvertDevice advertDevice)
	{
		startPage();
        List<AdvertDevice> list = advertDeviceService.selectAdvertDeviceList(advertDevice);
		return getDataTable(list);
	}
	
	/**
	 * 新增广告播放对象设置，也叫播放任务列
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存广告播放对象设置，也叫播放任务列
	 */
	@RequiresPermissions("module:advertDevice:add")
	@Log(title = "广告播放对象设置，也叫播放任务列", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(AdvertDevice advertDevice)
	{		
		return toAjax(advertDeviceService.insertAdvertDevice(advertDevice));
	}

	/**
	 * 修改广告播放对象设置，也叫播放任务列
	 */
	@GetMapping("/edit/{logid}")
	public String edit(@PathVariable("logid") String logid, ModelMap mmap)
	{
		AdvertDevice advertDevice = advertDeviceService.selectAdvertDeviceById(logid);
		mmap.put("advertDevice", advertDevice);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存广告播放对象设置，也叫播放任务列
	 */
	@RequiresPermissions("module:advertDevice:edit")
	@Log(title = "广告播放对象设置，也叫播放任务列", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(AdvertDevice advertDevice)
	{		
		return toAjax(advertDeviceService.updateAdvertDevice(advertDevice));
	}
	
	/**
	 * 删除广告播放对象设置，也叫播放任务列
	 */
	@RequiresPermissions("module:advertDevice:remove")
	@Log(title = "广告播放对象设置，也叫播放任务列", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(advertDeviceService.deleteAdvertDeviceByIds(ids));
	}
	
}
