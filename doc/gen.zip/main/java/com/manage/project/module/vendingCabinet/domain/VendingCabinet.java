package com.manage.project.module.vendingCabinet.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 售货机挂载的货柜，主柜的挂载副柜表 as_vending_cabinet
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class VendingCabinet extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 售货机编号 */
	private String siteId;
	/** 售货机名称 */
	private String siteName;
	/** 货柜排列(从左到右) 1:开始递增 */
	private Integer seqId;
	/** 机型编码 */
	private String deviceId;
	/** 工控机编号 */
	private String vmcId;
	/** 外挂类型 1:是 2:否 */
	private String hangType;
	/** 串口号 */
	private String pointCode;
	/** 厂家编号 */
	private String factoryId;
	/** 货柜类型 01:商店机 02:弹簧机 03:格子机 */
	private String cabinetType;
	/** 创建时间 */
	private String createTime;
	/** 描述 */
	private String description;
	/** 托管公司编号 */
	private String corpId;
	/** 上报时间 */
	private String reportTime;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setSiteId(String siteId) 
	{
		this.siteId = siteId;
	}

	public String getSiteId() 
	{
		return siteId;
	}
	public void setSiteName(String siteName) 
	{
		this.siteName = siteName;
	}

	public String getSiteName() 
	{
		return siteName;
	}
	public void setSeqId(Integer seqId) 
	{
		this.seqId = seqId;
	}

	public Integer getSeqId() 
	{
		return seqId;
	}
	public void setDeviceId(String deviceId) 
	{
		this.deviceId = deviceId;
	}

	public String getDeviceId() 
	{
		return deviceId;
	}
	public void setVmcId(String vmcId) 
	{
		this.vmcId = vmcId;
	}

	public String getVmcId() 
	{
		return vmcId;
	}
	public void setHangType(String hangType) 
	{
		this.hangType = hangType;
	}

	public String getHangType() 
	{
		return hangType;
	}
	public void setPointCode(String pointCode) 
	{
		this.pointCode = pointCode;
	}

	public String getPointCode() 
	{
		return pointCode;
	}
	public void setFactoryId(String factoryId) 
	{
		this.factoryId = factoryId;
	}

	public String getFactoryId() 
	{
		return factoryId;
	}
	public void setCabinetType(String cabinetType) 
	{
		this.cabinetType = cabinetType;
	}

	public String getCabinetType() 
	{
		return cabinetType;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}
	public void setDescription(String description) 
	{
		this.description = description;
	}

	public String getDescription() 
	{
		return description;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setReportTime(String reportTime) 
	{
		this.reportTime = reportTime;
	}

	public String getReportTime() 
	{
		return reportTime;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("siteId", getSiteId())
            .append("siteName", getSiteName())
            .append("seqId", getSeqId())
            .append("deviceId", getDeviceId())
            .append("vmcId", getVmcId())
            .append("hangType", getHangType())
            .append("pointCode", getPointCode())
            .append("factoryId", getFactoryId())
            .append("cabinetType", getCabinetType())
            .append("createTime", getCreateTime())
            .append("description", getDescription())
            .append("corpId", getCorpId())
            .append("reportTime", getReportTime())
            .toString();
    }
}
