package com.manage.project.module.vendingDistrict.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 管理线路的区域表 as_vending_district
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class VendingDistrict extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 区域编号 */
	private String districtId;
	/** 区域名称 */
	private String name;
	/** 区域编码 */
	private String code;
	/** 负责人名称 */
	private String manager;
	/** 负责人联系方式 */
	private String mobile;
	/** 描述 */
	private String description;
	/** 创建时间 */
	private String createTime;
	/** 托管公司编号 */
	private String corpId;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setDistrictId(String districtId) 
	{
		this.districtId = districtId;
	}

	public String getDistrictId() 
	{
		return districtId;
	}
	public void setName(String name) 
	{
		this.name = name;
	}

	public String getName() 
	{
		return name;
	}
	public void setCode(String code) 
	{
		this.code = code;
	}

	public String getCode() 
	{
		return code;
	}
	public void setManager(String manager) 
	{
		this.manager = manager;
	}

	public String getManager() 
	{
		return manager;
	}
	public void setMobile(String mobile) 
	{
		this.mobile = mobile;
	}

	public String getMobile() 
	{
		return mobile;
	}
	public void setDescription(String description) 
	{
		this.description = description;
	}

	public String getDescription() 
	{
		return description;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("districtId", getDistrictId())
            .append("name", getName())
            .append("code", getCode())
            .append("manager", getManager())
            .append("mobile", getMobile())
            .append("description", getDescription())
            .append("createTime", getCreateTime())
            .append("corpId", getCorpId())
            .toString();
    }
}
