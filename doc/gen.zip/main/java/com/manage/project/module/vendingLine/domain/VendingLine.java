package com.manage.project.module.vendingLine.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.manage.framework.web.domain.BaseEntity;

/**
 * 点位的线路表 as_vending_line
 * 
 * @author xufeng
 * @date 2018-09-02
 */
public class VendingLine extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 记录编号 */
	private String logid;
	/** 线路编号 */
	private String lineId;
	/** 区域编号 */
	private String districtId;
	/** 线路名称 */
	private String name;
	/** 描述 */
	private String description;
	/** 点位数量 */
	private Integer lineNum;
	/** 点位在线数量 */
	private Integer onlineNum;
	/** 托管公司编号 */
	private String corpId;
	/** 创建时间 */
	private String createTime;

	public void setLogid(String logid) 
	{
		this.logid = logid;
	}

	public String getLogid() 
	{
		return logid;
	}
	public void setLineId(String lineId) 
	{
		this.lineId = lineId;
	}

	public String getLineId() 
	{
		return lineId;
	}
	public void setDistrictId(String districtId) 
	{
		this.districtId = districtId;
	}

	public String getDistrictId() 
	{
		return districtId;
	}
	public void setName(String name) 
	{
		this.name = name;
	}

	public String getName() 
	{
		return name;
	}
	public void setDescription(String description) 
	{
		this.description = description;
	}

	public String getDescription() 
	{
		return description;
	}
	public void setLineNum(Integer lineNum) 
	{
		this.lineNum = lineNum;
	}

	public Integer getLineNum() 
	{
		return lineNum;
	}
	public void setOnlineNum(Integer onlineNum) 
	{
		this.onlineNum = onlineNum;
	}

	public Integer getOnlineNum() 
	{
		return onlineNum;
	}
	public void setCorpId(String corpId) 
	{
		this.corpId = corpId;
	}

	public String getCorpId() 
	{
		return corpId;
	}
	public void setCreateTime(String createTime) 
	{
		this.createTime = createTime;
	}

	public String getCreateTime() 
	{
		return createTime;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logid", getLogid())
            .append("lineId", getLineId())
            .append("districtId", getDistrictId())
            .append("name", getName())
            .append("description", getDescription())
            .append("lineNum", getLineNum())
            .append("onlineNum", getOnlineNum())
            .append("corpId", getCorpId())
            .append("createTime", getCreateTime())
            .toString();
    }
}
